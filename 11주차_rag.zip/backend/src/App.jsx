import React, { useState, useEffect, useRef } from 'react'
import ChatInterface from './components/ChatInterface'
import InitializePanel from './components/InitializePanel'
import './App.css'

function App() {
  const [isInitialized, setIsInitialized] = useState(false)
  const [isInitializing, setIsInitializing] = useState(false)
  const [initStatus, setInitStatus] = useState(null)

  useEffect(() => {
    // 서버 상태 확인
    checkServerHealth()
  }, [])

  const checkServerHealth = async () => {
    try {
      const response = await fetch('http://localhost:8000/health')
      const data = await response.json()
      setIsInitialized(data.vector_store_initialized)
    } catch (error) {
      console.error('서버 연결 실패:', error)
    }
  }

  const handleInitialize = async (pdfDirectory, force = false) => {
    setIsInitializing(true)
    setInitStatus(null)
    
    // 재초기화 시에도 챗 화면에 남아있음 (초기화 화면으로 전환하지 않음)

    let pollProgress = null
    let timeoutId = null

    try {
      // 초기화 시작 (비동기)
      const initResponse = await fetch('http://localhost:8000/initialize', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          pdf_directory: pdfDirectory || 'pdfs',
          force: force || false,
        }),
      })
      
      if (!initResponse.ok) {
        const error = await initResponse.json()
        throw new Error(error.detail || '초기화 요청 실패')
      }

      const initData = await initResponse.json()
      
      // force=true이면 재초기화 진행이므로 skip_initialization 체크 무시
      // force=false이고 기존 벡터 DB가 있으면 polling 생략하고 바로 완료 처리
      if (initData.skip_initialization && !force) {
        setInitStatus({
          success: true,
          message: initData.message,
          progress: 100,
          currentStep: '완료',
        })
        setIsInitialized(true)
        setIsInitializing(false)
        return
      }

      // 진행 상황 polling
      pollProgress = setInterval(async () => {
        try {
          const progressResponse = await fetch('http://localhost:8000/initialize/progress')
          if (!progressResponse.ok) return
          
          const progressData = await progressResponse.json()
          
          setInitStatus({
            progress: progressData.progress,
            total: progressData.total,
            currentStep: progressData.current_step,
            message: progressData.message,
            status: progressData.status,
          })

          // 완료 또는 오류 시 polling 중지
          if (progressData.status === 'done') {
            clearInterval(pollProgress)
            if (timeoutId) clearTimeout(timeoutId)
            
            // 최종 결과 가져오기
            try {
              const response = await fetch('http://localhost:8000/health')
              const healthData = await response.json()
              if (healthData.vector_store_initialized) {
                setInitStatus({
                  success: true,
                  message: progressData.message,
                  progress: 100,
                  currentStep: '완료',
                  status: 'done',
                })
                setIsInitialized(true)
                
                // 재초기화 완료 후 2초 뒤에 상태 메시지 숨김
                setTimeout(() => {
                  setIsInitializing(false)
                  setInitStatus(null)
                }, 2000)
              }
            } catch (err) {
              console.error('상태 확인 오류:', err)
              setIsInitializing(false)
            }
          } else if (progressData.status === 'error') {
            clearInterval(pollProgress)
            if (timeoutId) clearTimeout(timeoutId)
            setInitStatus({
              success: false,
              message: progressData.message,
              status: 'error',
            })
            setIsInitializing(false)
          }
        } catch (err) {
          console.error('진행 상황 조회 오류:', err)
        }
      }, 500) // 0.5초마다 조회

      // 최대 10분 후 타임아웃
      timeoutId = setTimeout(() => {
        if (pollProgress) clearInterval(pollProgress)
        setIsInitializing(false)
        setInitStatus({
          success: false,
          message: '초기화가 너무 오래 걸려 타임아웃되었습니다.',
        })
      }, 600000)
    } catch (error) {
      if (pollProgress) clearInterval(pollProgress)
      if (timeoutId) clearTimeout(timeoutId)
      setInitStatus({
        success: false,
        message: error.message,
      })
      setIsInitializing(false)
    }
  }

  return (
    <div className="app">
      <header className="app-header">
        <h1>🚂 Korail 법령검색 챗봇</h1>
        <p>사규 및 내규 문서 기반 AI 검색 서비스</p>
      </header>

      {!isInitialized && !isInitializing ? (
        <InitializePanel
          onInitialize={handleInitialize}
          isInitializing={isInitializing}
          status={initStatus}
        />
      ) : (
        <>
          <ChatInterface 
            onReinitialize={handleInitialize} 
            isInitializing={isInitializing}
            initStatus={initStatus}
          />
          {isInitializing && isInitialized && (
            <div className="reinit-overlay">
              <div className="reinit-panel">
                <InitializePanel
                  onInitialize={handleInitialize}
                  isInitializing={isInitializing}
                  status={initStatus}
                />
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}

export default App

