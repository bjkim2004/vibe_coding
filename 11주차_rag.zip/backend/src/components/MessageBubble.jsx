import React from 'react'
import './MessageBubble.css'

function MessageBubble({ message }) {
  const { role, content, sources, isError } = message

  return (
    <div className={`message-bubble ${role} ${isError ? 'error' : ''}`}>
      <div className="message-content">
        <div className="message-text">{content}</div>
        {sources && sources.length > 0 && (
          <div className="message-sources">
            <strong>참고 문서:</strong>
            <ul>
              {sources.map((source, idx) => (
                <li key={idx}>
                  [{source.document_type}] {source.source}
                  {source.article_title !== '조항 없음' && ` - ${source.article_title}`}
                  <span className="similarity-score">
                    (유사도: {(source.similarity_score * 100).toFixed(1)}%)
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  )
}

export default MessageBubble






