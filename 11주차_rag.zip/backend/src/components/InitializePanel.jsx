import React, { useState } from 'react'
import './InitializePanel.css'

function InitializePanel({ onInitialize, isInitializing, status }) {
  const [pdfDirectory, setPdfDirectory] = useState('pdfs')

  const handleSubmit = (e) => {
    e.preventDefault()
    onInitialize(pdfDirectory)
  }

  return (
    <div className="initialize-panel">
      <div className="panel-content">
        <h2>시스템 초기화</h2>
        <p>PDF 문서를 로드하고 벡터 스토어를 구축하세요.</p>

        {(status || isInitializing) && (
          <div className={`status-message ${status?.success ? 'success' : status?.success === false ? 'error' : 'info'}`}>
            {isInitializing && status?.status !== 'done' && (
              <>
                <h3>🔄 초기화 진행 중...</h3>
                <div className="progress-container">
                  <div className="progress-bar-wrapper">
                    <div 
                      className="progress-bar" 
                      style={{ width: `${status?.progress || 0}%` }}
                    ></div>
                  </div>
                  <div className="progress-info">
                    <span className="progress-percentage">{status?.progress || 0}%</span>
                    <span className="progress-step">{status?.currentStep || '준비 중...'}</span>
                  </div>
                  <p className="progress-message">{status?.message || '초기화를 시작합니다...'}</p>
                  {status?.total > 0 && (
                    <p className="progress-detail">
                      처리 중: {Math.floor((status.progress / 100) * status.total)} / {status.total}
                    </p>
                  )}
                </div>
              </>
            )}
            {status?.success === true && (
              <>
                <h3>✅ 초기화 성공!</h3>
                <p>{status.message}</p>
                {status.num_documents && (
                  <ul>
                    <li>로드된 문서 수: {status.num_documents}개</li>
                    <li>생성된 청크 수: {status.num_chunks}개</li>
                  </ul>
                )}
              </>
            )}
            {status?.success === false && (
              <>
                <h3>❌ 초기화 실패</h3>
                <p>{status.message}</p>
              </>
            )}
          </div>
        )}

        <form onSubmit={handleSubmit} className="initialize-form">
          <div className="form-group">
            <label htmlFor="pdf-directory">PDF 디렉토리 경로:</label>
            <input
              type="text"
              id="pdf-directory"
              value={pdfDirectory}
              onChange={(e) => setPdfDirectory(e.target.value)}
              placeholder="pdfs"
              disabled={isInitializing}
            />
          </div>
          <button
            type="submit"
            disabled={isInitializing}
            className="initialize-button"
          >
            {isInitializing ? '초기화 중...' : '초기화 시작'}
          </button>
        </form>
      </div>
    </div>
  )
}

export default InitializePanel

