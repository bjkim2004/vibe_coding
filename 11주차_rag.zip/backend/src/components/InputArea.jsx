import React, { useState } from 'react'
import './InputArea.css'

function InputArea({ onSendMessage, disabled }) {
  const [question, setQuestion] = useState('')
  const [similarityThreshold, setSimilarityThreshold] = useState(0.5)
  const [maxK, setMaxK] = useState(5)
  const [temperature, setTemperature] = useState(0.05)
  const [showAdvanced, setShowAdvanced] = useState(false)

  const handleSubmit = (e) => {
    e.preventDefault()
    if (question.trim() && !disabled) {
      onSendMessage(question, similarityThreshold, maxK, temperature)
      setQuestion('')
    }
  }

  return (
    <div className="input-area">
      {showAdvanced && (
        <div className="advanced-settings">
          <div className="setting-item">
            <label>
              유사도 임계값: {similarityThreshold}
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={similarityThreshold}
                onChange={(e) => setSimilarityThreshold(parseFloat(e.target.value))}
              />
            </label>
          </div>
          <div className="setting-item">
            <label>
              최대 검색 문서 수: {maxK}
              <input
                type="number"
                min="1"
                max="20"
                value={maxK}
                onChange={(e) => setMaxK(parseInt(e.target.value))}
              />
            </label>
          </div>
          <div className="setting-item">
            <label>
              Temperature (창의성): {temperature}
              <input
                type="range"
                min="0"
                max="2"
                step="0.05"
                value={temperature}
                onChange={(e) => setTemperature(parseFloat(e.target.value))}
              />
              <span className="temperature-hint">(낮을수록 일관적, 높을수록 창의적)</span>
            </label>
          </div>
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="input-form">
        <button
          type="button"
          className="advanced-toggle"
          onClick={() => setShowAdvanced(!showAdvanced)}
        >
          {showAdvanced ? '⚙️ 설정 숨기기' : '⚙️ 고급 설정'}
        </button>
        <div className="input-wrapper">
          <input
            type="text"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="법령 검색 질문을 입력하세요..."
            disabled={disabled}
            className="question-input"
          />
          <button
            type="submit"
            disabled={disabled || !question.trim()}
            className="send-button"
          >
            {disabled ? '전송 중...' : '전송'}
          </button>
        </div>
      </form>
    </div>
  )
}

export default InputArea

