import React, { useState, useRef, useEffect } from 'react'
import MessageList from './MessageList'
import InputArea from './InputArea'
import './ChatInterface.css'

function ChatInterface({ onReinitialize, isInitializing, initStatus }) {
  const [messages, setMessages] = useState([
    {
      id: 1,
      role: 'assistant',
      content: '안녕하세요! Korail 사규 및 내규에 대한 질문을 해주세요. 법령 검색을 도와드리겠습니다.',
    },
  ])
  const [isLoading, setIsLoading] = useState(false)
  const [showReinitConfirm, setShowReinitConfirm] = useState(false)
  const messagesEndRef = useRef(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = async (question, similarityThreshold, maxK, temperature) => {
    if (!question.trim() || isLoading) return

    // 사용자 메시지 추가
    const userMessage = {
      id: Date.now(),
      role: 'user',
      content: question,
    }
    setMessages((prev) => [...prev, userMessage])
    setIsLoading(true)

    try {
      const response = await fetch('http://localhost:8000/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          question: question,
          similarity_threshold: similarityThreshold || 0.5,
          max_k: maxK || 5,
          temperature: temperature || 0.05,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.detail || '응답 생성 실패')
      }

      const data = await response.json()

      // AI 응답 추가
      const assistantMessage = {
        id: Date.now() + 1,
        role: 'assistant',
        content: data.answer,
        sources: data.sources,
      }
      setMessages((prev) => [...prev, assistantMessage])
    } catch (error) {
      const errorMessage = {
        id: Date.now() + 1,
        role: 'assistant',
        content: `오류가 발생했습니다: ${error.message}`,
        isError: true,
      }
      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const handleClearChat = () => {
    setMessages([
      {
        id: 1,
        role: 'assistant',
        content: '대화가 초기화되었습니다. 새로운 질문을 해주세요.',
      },
    ])
  }

  const handleReinitialize = () => {
    if (showReinitConfirm) {
      setShowReinitConfirm(false)
      onReinitialize('pdfs', true)  // force=true로 재초기화
    } else {
      setShowReinitConfirm(true)
    }
  }

  const cancelReinitialize = () => {
    setShowReinitConfirm(false)
  }

  return (
    <div className="chat-interface">
      <div className="chat-container">
        <div className="chat-header">
          <h2>법령 검색 채팅</h2>
          <div className="header-buttons">
            <button className="clear-btn" onClick={handleClearChat}>
              대화 초기화
            </button>
            <button className="reinit-btn" onClick={handleReinitialize}>
              시스템 재초기화
            </button>
          </div>
        </div>
        {showReinitConfirm && (
          <div className="reinit-confirm-dialog">
            <div className="reinit-confirm-content">
              <h3>시스템 재초기화 확인</h3>
              <p>벡터 DB를 재초기화하면 기존 데이터가 삭제되고 새로운 문서로 다시 구축됩니다.</p>
              <p>계속하시겠습니까?</p>
              <div className="reinit-confirm-buttons">
                <button className="confirm-btn" onClick={handleReinitialize}>
                  예, 재초기화 진행
                </button>
                <button className="cancel-btn" onClick={cancelReinitialize}>
                  취소
                </button>
              </div>
            </div>
          </div>
        )}
        <MessageList messages={messages} isLoading={isLoading} />
        <InputArea onSendMessage={handleSendMessage} disabled={isLoading} />
        <div ref={messagesEndRef} />
      </div>
    </div>
  )
}

export default ChatInterface

