"""
벡터 DB에 저장된 청크 문서 10개를 샘플로 출력하는 스크립트
"""
import os
import sys

# backend 디렉토리 경로 추가
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from embeddings import CustomHuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma
from huggingface_hub import snapshot_download

def show_sample_chunks(num_chunks=10):
    """벡터 DB에서 샘플 청크를 가져와 출력합니다."""
    
    print("=" * 80)
    print("벡터 DB에서 청크 샘플 가져오기")
    print("=" * 80)
    
    try:
        # 모델 경로 결정
        MODEL_ID = "BM-K/KoSimCSE-roberta-multitask"
        print(f"\n1. 임베딩 모델 로드 중: {MODEL_ID}")
        model_path = snapshot_download(repo_id=MODEL_ID)
        print(f"   모델 경로: {model_path}")
        
        # 임베딩 모델 초기화
        print("\n2. 임베딩 모델 초기화 중...")
        embeddings = CustomHuggingFaceEmbeddings(model_path=model_path, device='cpu')
        
        # backend 디렉토리 기준으로 chroma_db 경로 설정
        current_dir = os.path.dirname(os.path.abspath(__file__))
        chroma_db_path = os.path.join(current_dir, "chroma_db")
        
        print(f"\n3. 벡터 DB 연결 중: {chroma_db_path}")
        
        # ChromaDB 연결
        vector_store = Chroma(
            collection_name="regulations_collection",
            embedding_function=embeddings,
            collection_metadata={"hnsw:space": "cosine"},
            persist_directory=chroma_db_path
        )
        
        # 컬렉션에서 문서 수 확인
        collection = vector_store._collection
        total_count = collection.count()
        print(f"   전체 청크 수: {total_count}개")
        
        if total_count == 0:
            print("\n⚠️  벡터 DB에 저장된 청크가 없습니다.")
            print("   먼저 /initialize를 실행하여 문서를 로드하세요.")
            return
        
        # 샘플 개수 조정
        sample_count = min(num_chunks, total_count)
        print(f"\n4. {sample_count}개의 청크 샘플 가져오기...")
        
        # 컬렉션에서 직접 데이터 가져오기
        results = collection.get(limit=sample_count)
        
        if not results or not results.get('ids'):
            print("\n⚠️  청크를 가져올 수 없습니다.")
            return
        
        print("\n" + "=" * 80)
        print(f"청크 샘플 {sample_count}개 출력")
        print("=" * 80)
        
        # 각 청크 출력
        for idx, chunk_id in enumerate(results['ids'], 1):
            print(f"\n{'='*80}")
            print(f"청크 #{idx} (ID: {chunk_id})")
            print(f"{'='*80}")
            
            # 해당 ID의 인덱스 찾기
            chunk_idx = results['ids'].index(chunk_id)
            
            # 메타데이터 가져오기
            if results.get('metadatas') and chunk_idx < len(results['metadatas']):
                metadata = results['metadatas'][chunk_idx]
                print("\n[메타데이터]")
                for key, value in metadata.items():
                    print(f"  {key}: {value}")
            
            # 문서 내용 가져오기
            if results.get('documents') and chunk_idx < len(results['documents']):
                document = results['documents'][chunk_idx]
                print(f"\n[원문 내용]")
                print(f"길이: {len(document)} 문자")
                print(f"\n{document}")
            
            # 임베딩 벡터 정보 (선택적)
            if results.get('embeddings') and chunk_idx < len(results['embeddings']):
                embedding = results['embeddings'][chunk_idx]
                print(f"\n[임베딩 벡터]")
                print(f"  차원: {len(embedding)}")
                print(f"  처음 5개 값: {embedding[:5]}")
            
            print(f"\n{'='*80}\n")
        
        print(f"\n총 {sample_count}개의 청크 샘플을 출력했습니다.")
        print(f"(전체 {total_count}개 중 {sample_count}개 샘플)")
        
    except Exception as e:
        print(f"\n❌ 오류 발생: {str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='벡터 DB에서 청크 샘플을 출력합니다.')
    parser.add_argument(
        '--num',
        type=int,
        default=10,
        help='출력할 청크 개수 (기본값: 10)'
    )
    
    args = parser.parse_args()
    show_sample_chunks(args.num)






