"""
문서 처리 모듈
PDF 로드, 전처리, 구조 인식 텍스트 분할
"""
import os
import re
from typing import List
from langchain_core.documents import Document
from langchain_community.document_loaders import UnstructuredFileLoader
from langchain_text_splitters import MarkdownHeaderTextSplitter, RecursiveCharacterTextSplitter


class DocumentProcessor:
    """문서 로드 및 처리 클래스"""
    
    # 정규식 패턴
    # 줄 시작이나 문서 시작에서만 매칭하도록 수정 (본문 중간의 패턴은 무시)
    COMPILED_REGEX_PATTERNS = {
        # 제N조는 줄 시작(\n)이나 문서 시작(^)에서만 매칭
        # 본문 중간의 '제3조' 같은 텍스트는 매칭하지 않음
        # 그룹 1: 제N조 부분만 캡처
        "article_title": re.compile(r"(?:^|\n\s*)(제\s*\d+\s*조\s*(?:\([^\)]+\))?)(?:\s|\.|:|：|$)", re.MULTILINE),
        # 항목 번호도 줄 시작에서만 매칭
        "item_numbering": re.compile(r"(\n\s*\d+\.\d+\.?\s|\n\s*\d+\.\s)"),
        # 한글 항목도 줄 시작에서만 매칭
        "hangeul_item": re.compile(r"(\n\s*\(?[가-힣]\)\s)"),
    }

    def load_single_document(self, path: str) -> Document:
        """단일 PDF 문서를 로드합니다."""
        if not os.path.exists(path):
            print(f"[경고] 파일을 찾을 수 없습니다: {path}")
            return None
        
        try:
            loader = UnstructuredFileLoader(path, mode="single", languages=["kor"])
            documents = loader.load()
            
            if documents:
                doc = documents[0]
                doc.metadata["source"] = path
                
                # 문서 타입 결정
                doc_type = "regulation"
                keywords = ["시행령", "법", "시행규칙"]
                if any(keyword in path for keyword in keywords):
                    doc_type = "raw"
                
                doc.metadata["Document_Type"] = doc_type
                print(f"  -> 파일 로드 및 구조화 완료: {os.path.basename(path)} (타입: {doc_type})")
                return doc
                
        except Exception as e:
            print(f"[오류] 파일 로드 중 오류 발생: {path}. 오류: {e}")
            return None

    def load_pdf_documents(self, file_paths: List[str]) -> List[Document]:
        """지정된 경로의 PDF 문서들을 로드합니다."""
        print(f"--- 문서 로드 시작: {len(file_paths)}개의 파일 ---")
        all_documents = []
        
        for path in file_paths:
            doc = self.load_single_document(path)
            if doc:
                all_documents.append(doc)
        
        print(f"--- 문서 로드 완료. 총 {len(all_documents)}개의 통합 문서 로드됨. ---")
        return all_documents

    def preprocess_to_markdown(self, documents: List[Document]) -> List[Document]:
        """로드된 문서 텍스트의 사규 패턴을 마크다운 헤더로 변환합니다.
        본문 중간에 포함된 '제3조' 같은 패턴은 헤더로 변환하지 않습니다."""
        print("\n--- 텍스트를 구조 인식용 마크다운으로 전처리 시작 ---")
        processed_documents = []
        
        for doc in documents:
            content = doc.page_content
            
            # 줄 시작이나 문서 시작에서만 매칭되는 패턴으로 헤더 변환
            # 본문 중간의 '제3조' 같은 텍스트는 건드리지 않음
            
            # 제N조 패턴: 줄 시작 또는 문서 시작에서만 매칭
            def replace_article_title(match):
                # 매칭된 전체를 헤더로 변환 (줄바꿈 포함)
                matched_text = match.group(1)  # '제3조' 같은 부분
                # 줄 시작의 공백 제거 후 헤더로 변환
                return f"\n# {matched_text.strip()}"
            
            content = self.COMPILED_REGEX_PATTERNS["article_title"].sub(
                replace_article_title, content
            )
            
            # 항목 번호 패턴: 줄 시작에서만 매칭 (이미 정규식에서 처리됨)
            content = self.COMPILED_REGEX_PATTERNS["item_numbering"].sub(
                lambda m: f"\n## {m.group(1).strip()}", content
            )
            
            # 한글 항목 패턴: 줄 시작에서만 매칭 (이미 정규식에서 처리됨)
            content = self.COMPILED_REGEX_PATTERNS["hangeul_item"].sub(
                lambda m: f"\n### {m.group(1).strip()}", content
            )
            
            # 여러 줄바꿈 정리
            content = re.sub(r"\n\s*\n", "\n\n", content).strip()
            
            processed_documents.append(
                Document(page_content=content, metadata=doc.metadata)
            )
        
        print("--- 전처리 완료 ---")
        return processed_documents

    def split_text_with_structure_awareness(self, documents: List[Document], chunk_size: int = 1000, chunk_overlap: int = 200) -> List[Document]:
        """전처리된 마크다운 기반 텍스트를 구조 인식 분할기로 청킹합니다.
        
        Args:
            documents: 전처리된 문서 리스트
            chunk_size: 조 단위로 나눈 후 내용이 길 경우 분할할 최대 글자수 (기본값: 1000)
            chunk_overlap: 분할 시 겹치는 글자수 (기본값: 200)
        """
        print("\n--- 구조 인식 텍스트 분할 시작 (조 단위 + 글자수 제한) ---")
        
        # 1단계: 조 단위로만 분할 (# 헤더만 사용)
        headers_to_split_on = [
            ("#", "Article_Title"),  # 조 단위만 분할
        ]
        
        markdown_splitter = MarkdownHeaderTextSplitter(
            headers_to_split_on=headers_to_split_on,
            strip_headers=False
        )
        
        # 2단계: 긴 조 내용을 글자수 제한으로 추가 분할
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            length_function=len,
            separators=["\n\n", "\n", "。", " ", ""]  # 한글 문장 구분자 포함
        )
        
        all_chunks = []
        
        for doc in documents:
            # 조 단위로 먼저 분할
            article_chunks = markdown_splitter.split_text(doc.page_content)
            
            print(f"  -> 문서: {os.path.basename(doc.metadata.get('source', '알 수 없음'))}")
            print(f"     조 단위 분할 결과: {len(article_chunks)}개 조")
            
            for article_chunk in article_chunks:
                combined_metadata = {**doc.metadata, **article_chunk.metadata}
                
                # 조의 내용 길이 확인
                article_content = article_chunk.page_content
                article_length = len(article_content)
                
                if article_length > chunk_size:
                    # 긴 조의 경우 추가 분할
                    sub_chunks = text_splitter.split_text(article_content)
                    print(f"     조 '{combined_metadata.get('Article_Title', '알 수 없음')}': {article_length}자 → {len(sub_chunks)}개 서브청크로 분할")
                    
                    for idx, sub_chunk in enumerate(sub_chunks):
                        # 서브청크도 원본 메타데이터 유지
                        sub_chunk_doc = Document(
                            page_content=sub_chunk,
                            metadata={
                                **combined_metadata,
                                "chunk_index": idx,  # 같은 조 내에서의 인덱스
                                "total_chunks": len(sub_chunks)  # 같은 조 내 전체 청크 수
                            }
                        )
                        all_chunks.append(sub_chunk_doc)
                else:
                    # 짧은 조는 그대로 유지
                    article_chunk.metadata = combined_metadata
                    all_chunks.append(article_chunk)
        
        print(f"--- 구조 인식 분할 완료. 총 {len(all_chunks)}개의 청크 생성됨. ---")
        return all_chunks

