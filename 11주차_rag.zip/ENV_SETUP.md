# 환경 변수 설정 가이드

## API 키 설정

이 프로젝트는 Google Gemini API 키를 환경 변수로 관리합니다.

### 1. .env 파일 생성

프로젝트 루트 디렉토리 (`G:\sync\New_Project\vibe_coding\korail\`)에 `.env` 파일을 생성하세요.

### 2. .env 파일 내용

`.env` 파일에 다음 내용을 추가하세요:

```
GOOGLE_API_KEY=your_actual_api_key_here
```

**예시:**
```
GOOGLE_API_KEY=AIzaSyCPeHe4VSXawGN9ocudEwy_T1XipTT2xSk
```

### 3. 선택사항: LLM Temperature 설정

Temperature를 환경 변수로 설정할 수도 있습니다:

```
GOOGLE_API_KEY=your_actual_api_key_here
LLM_TEMPERATURE=0.05
```

### 4. 확인

서버를 시작하면 자동으로 `.env` 파일에서 환경 변수를 로드합니다.

### 주의사항

- `.env` 파일은 `.gitignore`에 포함되어 있어 Git에 커밋되지 않습니다.
- API 키를 절대 공개 저장소에 업로드하지 마세요.
- 프로덕션 환경에서는 시스템 환경 변수를 사용하는 것을 권장합니다.

