import React from 'react'
import MessageBubble from './MessageBubble'
import './MessageList.css'

function MessageList({ messages, isLoading }) {
  return (
    <div className="message-list">
      {messages.map((message) => (
        <MessageBubble key={message.id} message={message} />
      ))}
      {isLoading && (
        <div className="message-bubble assistant loading">
          <div className="loading-dots">
            <span></span>
            <span></span>
            <span></span>
          </div>
        </div>
      )}
    </div>
  )
}

export default MessageList





