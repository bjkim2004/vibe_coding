"""
커스텀 임베딩 클래스
로컬 경로에서 Hugging Face 모델을 로드하고 Mean Pooling을 적용
"""
import os
import torch
from typing import List
from transformers import AutoModel, AutoTokenizer


class CustomHuggingFaceEmbeddings:
    """
    Hugging Face Hub 대신 로컬 경로에서 임베딩 모델을 로드하고 Mean Pooling을 적용합니다.
    (모델: BM-K/KoSimCSE-roberta-multitask)
    """
    def __init__(self, model_path: str, device: str = 'cpu'):
        print(f"  -> 로컬 임베딩 모델 '{model_path}' 로딩 중...")
        self.device = device
        self.model_path = model_path

        if not os.path.exists(model_path):
            raise FileNotFoundError(f"지정된 로컬 경로에 모델 파일이 없습니다: {model_path}")

        try:
            # 로컬 경로에서 토크나이저 및 모델 로드
            self.tokenizer = AutoTokenizer.from_pretrained(model_path)
            self.model = AutoModel.from_pretrained(model_path, trust_remote_code=True).to(device)
            self.model.eval()
            print(f"  -> 로컬 모델 로드 성공: {model_path}")

        except Exception as e:
            raise Exception(f"로컬 모델 로드 실패. 파일 구조를 확인하세요: {e}")

    def _mean_pooling(self, model_output, attention_mask):
        """출력 벡터에 Mean Pooling을 적용하여 문장 임베딩을 생성합니다."""
        token_embeddings = model_output[0]
        input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
        sum_embeddings = torch.sum(token_embeddings * input_mask_expanded, 1)
        sum_mask = torch.clamp(input_mask_expanded.sum(1), min=1e-9)
        return sum_embeddings / sum_mask

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """문서 리스트를 받아 임베딩 벡터 리스트를 반환합니다."""
        return [self.embed_query(text) for text in texts]

    def embed_query(self, text: str) -> List[float]:
        """단일 쿼리 텍스트를 임베딩 벡터로 변환합니다."""
        with torch.no_grad():
            encoded_input = self.tokenizer(
                text, padding=True, truncation=True, return_tensors='pt'
            ).to(self.device)
            model_output = self.model(**encoded_input)
            sentence_embedding = self._mean_pooling(
                model_output, encoded_input['attention_mask']
            )
            return sentence_embedding.cpu().tolist()[0]





