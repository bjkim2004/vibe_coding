@echo off
echo ========================================
echo Korail 법령검색 챗봇 서버 시작
echo ========================================
echo.

REM 백엔드 서버를 새 창에서 시작
echo [1/2] 백엔드 서버 시작 중...
start "Korail Backend Server" cmd /k "cd backend && python main.py"

REM 잠시 대기 (백엔드가 시작될 시간 확보)
timeout /t 3 /nobreak > nul

REM 프론트엔드 서버를 새 창에서 시작
echo [2/2] 프론트엔드 서버 시작 중...
echo     (의존성 확인 중...)
if not exist "frontend\node_modules" (
    echo     node_modules가 없어 npm install을 실행합니다...
    start "Korail Frontend Setup" cmd /k "cd frontend && npm install && echo. && echo 의존성 설치 완료! 이 창을 닫고 프론트엔드 서버를 시작하세요. && pause"
    timeout /t 5 /nobreak > nul
)
start "Korail Frontend Server" cmd /k "cd frontend && npm run dev"

echo.
echo ========================================
echo 서버가 시작되었습니다!
echo ========================================
echo.
echo 백엔드: http://localhost:8000
echo 프론트엔드: http://localhost:3000
echo.
echo 두 개의 새 창이 열립니다.
echo 서버를 종료하려면 각 창을 닫으세요.
echo.
pause

