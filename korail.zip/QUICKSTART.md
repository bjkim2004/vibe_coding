# 빠른 시작 가이드

## 1단계: 환경 설정

```bash
# Python 가상환경 생성 (Windows)
python -m venv venv
venv\Scripts\activate

# 의존성 설치
pip install -r requirements.txt
```

## 2단계: 환경 변수 설정

`.env` 파일을 생성하고 OpenAI API 키를 설정하세요:

```
OPENAI_API_KEY=sk-your-key-here
```

## 3단계: 백엔드 실행

```bash
# 방법 1: 배치 파일 사용 (Windows)
start_backend.bat

# 방법 2: 직접 실행
cd backend
python main.py
```

백엔드 서버가 `http://localhost:8000`에서 실행됩니다.

## 4단계: 프론트엔드 실행

새 터미널에서:

```bash
# 방법 1: 배치 파일 사용 (Windows)
start_frontend.bat

# 방법 2: 직접 실행
cd frontend
npm install
npm run dev
```

프론트엔드가 `http://localhost:3000`에서 실행됩니다.

## 5단계: 초기화 및 사용

1. 브라우저에서 `http://localhost:3000` 접속
2. "초기화 시작" 버튼 클릭
   - 첫 실행 시 임베딩 모델이 자동 다운로드됩니다 (약 500MB)
   - PDF 문서가 로드되고 벡터 스토어가 구축됩니다
3. 초기화 완료 후 질문 입력하여 사용

## 문제 해결

### 백엔드가 시작되지 않을 때
- Python 3.8 이상인지 확인
- `requirements.txt`의 모든 패키지가 설치되었는지 확인
- 포트 8000이 사용 중인지 확인

### 프론트엔드가 시작되지 않을 때
- Node.js 16 이상이 설치되었는지 확인
- `npm install`이 완료되었는지 확인
- 포트 3000이 사용 중인지 확인

### 초기화 실패 시
- `pdfs` 디렉토리에 PDF 파일이 있는지 확인
- OpenAI API 키가 올바른지 확인
- 인터넷 연결 상태 확인 (모델 다운로드 필요)





