# Korail 법령검색 챗봇

사규 및 내규 PDF 문서를 기반으로 한 RAG (Retrieval-Augmented Generation) 챗봇 시스템입니다.

## 주요 기능

- 📄 PDF 문서 자동 로드 및 구조 인식 처리
- 🔍 의미 기반 검색 (KoSimCSE-roberta-multitask 모델 사용)
- 💬 실시간 채팅 인터페이스
- 📚 참고 문서 출처 표시
- ⚙️ 유사도 임계값 및 검색 문서 수 조정

## 프로젝트 구조

```
korail/
├── backend/              # FastAPI 백엔드 서버
│   ├── main.py          # 메인 서버 및 API 엔드포인트
│   ├── embeddings.py    # 커스텀 임베딩 클래스
│   └── document_processor.py  # 문서 처리 모듈
├── frontend/            # React 프론트엔드
│   ├── src/
│   │   ├── App.jsx
│   │   └── components/
│   └── package.json
├── pdfs/               # PDF 문서 디렉토리
├── requirements.txt    # Python 의존성
└── README.md
```

## 설치 및 실행

> 💡 **빠른 시작**: 자세한 단계별 가이드는 [QUICKSTART.md](QUICKSTART.md)를 참조하세요.

### 1. 환경 설정

```bash
# Python 가상환경 생성 및 활성화
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Python 의존성 설치
pip install -r requirements.txt

# 환경 변수 설정
# .env 파일을 생성하고 OPENAI_API_KEY를 설정하세요
# Windows에서 .env.example을 .env로 복사하여 수정
```

### 2. 백엔드 서버 실행

```bash
# Windows
start_backend.bat

# 또는 직접 실행
cd backend
python main.py
```

서버는 `http://localhost:8000`에서 실행됩니다.

### 3. 프론트엔드 실행

새 터미널에서:

```bash
# Windows
start_frontend.bat

# 또는 직접 실행
cd frontend
npm install
npm run dev
```

프론트엔드는 `http://localhost:3000`에서 실행됩니다.

## 사용 방법

1. **초기화**: 프론트엔드에서 PDF 디렉토리 경로(`pdfs`)를 입력하고 "초기화 시작" 버튼을 클릭합니다.
   - 첫 실행 시 임베딩 모델이 자동으로 다운로드됩니다.
   - PDF 문서가 로드되고 벡터 스토어가 구축됩니다.

2. **채팅**: 초기화가 완료되면 질문을 입력하여 법령을 검색할 수 있습니다.

3. **고급 설정**: 
   - 유사도 임계값: 검색 결과의 최소 유사도 (0.0 ~ 1.0)
   - 최대 검색 문서 수: 각 문서 유형별로 반환할 최대 문서 수

## API 엔드포인트

### `GET /health`
서버 상태 확인

### `POST /initialize`
PDF 문서를 로드하고 벡터 스토어를 초기화합니다.

```json
{
  "pdf_directory": "pdfs",
  "model_path": null  // 선택사항
}
```

### `POST /chat`
질문을 처리하고 답변을 반환합니다.

```json
{
  "question": "보선장비 검수 절차는?",
  "similarity_threshold": 0.5,
  "max_k": 5
}
```

응답:
```json
{
  "answer": "답변 내용...",
  "sources": [
    {
      "source": "파일명.pdf",
      "article_title": "제1조",
      "document_type": "regulation",
      "similarity_score": 0.85
    }
  ]
}
```

## 기술 스택

### Backend
- FastAPI: REST API 서버
- LangChain: RAG 파이프라인
- ChromaDB: 벡터 데이터베이스
- Transformers: 임베딩 모델
- OpenAI GPT-4o: LLM

### Frontend
- React: UI 프레임워크
- Vite: 빌드 도구
- Axios: HTTP 클라이언트

## 주의사항

1. **OpenAI API 키**: `.env` 파일에 유효한 OpenAI API 키를 설정해야 합니다.
2. **모델 다운로드**: 첫 실행 시 약 500MB의 임베딩 모델이 다운로드됩니다.
3. **PDF 처리**: PDF 파일이 많거나 크기가 큰 경우 초기화에 시간이 걸릴 수 있습니다.
4. **메모리**: GPU를 사용하지 않을 경우 CPU 모드로 실행되며, 처리 시간이 길어질 수 있습니다.

## 문제 해결

### 모델 다운로드 실패
- 인터넷 연결을 확인하세요.
- Hugging Face 계정이 필요한 경우 로그인하세요.

### PDF 로드 실패
- PDF 파일 경로를 확인하세요.
- `unstructured` 라이브러리의 의존성 설치를 확인하세요.

### API 연결 오류
- 백엔드 서버가 실행 중인지 확인하세요.
- CORS 설정을 확인하세요.

## 라이선스

이 프로젝트는 내부 사용을 위한 것입니다.

