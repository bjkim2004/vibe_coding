# 생산 데이터 분석 대시보드 UI/UX 설계서

**프로젝트명**: Production Data Analysis Dashboard
**버전**: 1.1.0
**작성일**: 2025-10-30
**문서 유형**: UI/UX 설계 명세서

---

## 📋 목차

1. [프로젝트 개요](#1-프로젝트-개요)
2. [사용자 플로우](#2-사용자-플로우)
3. [화면 구조](#3-화면-구조)
4. [컴포넌트 명세](#4-컴포넌트-명세)
5. [디자인 시스템](#5-디자인-시스템)
6. [인터랙션 정의](#6-인터랙션-정의)
7. [반응형 디자인](#7-반응형-디자인)
8. [접근성](#8-접근성)
9. [개선 제안사항](#9-개선-제안사항)

---

## 1. 프로젝트 개요

### 1.1 서비스 목적
엑셀 파일 기반의 생산 데이터를 실시간으로 분석하고 시각화하여, 생산 현장의 의사결정을 지원하는 분석 대시보드

### 1.2 주요 기능
- 엑셀 파일 업로드 (드래그 앤 드롭 지원)
- 생산 데이터 자동 분석
- 다차원 데이터 시각화 (6개 차트)
- 요약 통계 카드 (6개 지표)
- 주요 인사이트 자동 추출

### 1.3 타겟 사용자
- **주 사용자**: 생산 관리자, 품질 관리자
- **부 사용자**: 경영진, 데이터 분석가
- **기술 수준**: 기본적인 컴퓨터 활용 능력

---

## 2. 사용자 플로우

### 2.1 기본 플로우

```
시작
  ↓
[메인 페이지 진입]
  ↓
[파일 업로드 영역]
  ├─ 드래그 앤 드롭
  └─ 클릭하여 파일 선택
  ↓
[파일 선택 확인]
  ↓
[업로드 및 분석 시작 버튼 클릭]
  ↓
[로딩 상태] (분석 중...)
  ↓
[대시보드 표시]
  ├─ 요약 통계 카드 (6개)
  ├─ 차트 그리드 (6개 차트)
  └─ 주요 인사이트
  ↓
[새 파일 업로드] ──→ [파일 업로드 영역]으로 복귀
```

### 2.2 에러 플로우

```
[파일 업로드 시도]
  ↓
[에러 발생]
  ├─ 잘못된 파일 형식 → 에러 메시지 표시
  ├─ 네트워크 오류 → 에러 메시지 표시
  └─ 데이터 분석 실패 → 에러 메시지 표시
  ↓
[사용자 재시도]
```

---

## 3. 화면 구조

### 3.1 전체 레이아웃

```
┌─────────────────────────────────────────────────────┐
│                  Header (고정)                        │
│  🏭 생산 데이터 분석 대시보드                         │
│  엑셀 파일을 업로드하여 실시간 데이터 분석 및 시각화   │
└─────────────────────────────────────────────────────┘
│                                                       │
│  [에러 메시지 영역] (조건부 표시)                      │
│                                                       │
├─────────────────────────────────────────────────────┤
│                                                       │
│        상태에 따라 표시되는 콘텐츠:                    │
│                                                       │
│  📤 파일 업로드 화면                                  │
│     또는                                              │
│  📊 대시보드 화면                                     │
│                                                       │
└─────────────────────────────────────────────────────┘
```

### 3.2 파일 업로드 화면

```
┌─────────────────────────────────────────────────┐
│                                                 │
│              ╔════════════════════╗             │
│              ║                    ║             │
│              ║        📊          ║             │
│              ║                    ║             │
│              ║  엑셀 파일을       ║             │
│              ║  드래그 앤 드롭    ║             │
│              ║  하거나            ║             │
│              ║  클릭하여 선택     ║             │
│              ║                    ║             │
│              ║  지원형식:         ║             │
│              ║  .xlsx, .xls       ║             │
│              ║                    ║             │
│              ╚════════════════════╝             │
│                                                 │
│  ┌─────────────────────────────────────────┐   │
│  │ 선택된 파일: example.xlsx (125.45 KB)   │   │
│  └─────────────────────────────────────────┘   │
│                                                 │
│          [업로드 및 분석 시작]                   │
│                                                 │
│  ⏳ 데이터를 분석하고 있습니다... (로딩 시)      │
│                                                 │
└─────────────────────────────────────────────────┘
```

### 3.3 대시보드 화면

```
┌─────────────────────────────────────────────────────┐
│  [새 파일 업로드] 버튼                                │
├─────────────────────────────────────────────────────┤
│                                                       │
│  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐  │
│  │ 총   │  │ 평균 │  │ 총   │  │ 평균 │  │ 평균   │  │ 평균 │  │
│  │ 생산 │  │ 수율 │  │ 순수 │  │스크랩│  │재작업  │  │ 마진 │  │
│  └──────┘  └──────┘  └──────┘  └──────┘  └──────┘  └──────┘  │
│                                                       │
├─────────────────────────────────────────────────────┤
│                                                       │
│  ┌──────────────────┐  ┌──────────────────┐         │
│  │ 🏭 공장별        │  │ 📦 제품별        │         │
│  │   생산량 및 수익 │  │   수익성         │         │
│  │                  │  │                  │         │
│  │  [Bar Chart]     │  │  [Bar Chart]     │         │
│  └──────────────────┘  └──────────────────┘         │
│                                                       │
│  ┌──────────────────┐  ┌──────────────────┐         │
│  │ 📈 월별          │  │ 🌍 고객지역별    │         │
│  │   생산 트렌드    │  │   매출           │         │
│  │                  │  │                  │         │
│  │  [Line Chart]    │  │  [Pie Chart]     │         │
│  └──────────────────┘  └──────────────────┘         │
│                                                       │
│  ┌──────────────────┐  ┌─────────────────────────────┐ │
│  │ 👥 교대조별      │  │ 🎯 품질 통계                │ │
│  │   품질 지표      │  │                             │ │
│  │                  │  │  [수율│스크랩율│재작업율]  │ │
│  │  [Radar Chart]   │  │  [Stats Grid - 3열]         │ │
│  └──────────────────┘  └─────────────────────────────┘ │
│                                                       │
├─────────────────────────────────────────────────────┤
│                                                       │
│  💡 주요 인사이트                                     │
│                                                       │
│  ┌───────────┐  ┌───────────┐  ┌───────────┐        │
│  │ 최고 성과 │  │ 최고 수익 │  │ 저품질    │        │
│  │ 공장      │  │ 제품      │  │ 배치      │        │
│  └───────────┘  └───────────┘  └───────────┘        │
│                                                       │
└─────────────────────────────────────────────────────┘
```

---

## 4. 컴포넌트 명세

### 4.1 컴포넌트 계층 구조

```
App
├─ Header (헤더)
├─ ErrorMessage (에러 메시지) [조건부]
└─ 상태별 뷰
   ├─ FileUpload (파일 업로드)
   │  ├─ UploadZone (업로드 영역)
   │  ├─ FileInfo (파일 정보) [조건부]
   │  ├─ UploadButton (업로드 버튼)
   │  └─ LoadingIndicator (로딩) [조건부]
   │
   └─ Dashboard (대시보드)
      ├─ ResetButton (새 파일 업로드 버튼)
      ├─ SummaryCards (요약 카드)
      │  └─ SummaryCard × 6
      ├─ ChartGrid (차트 그리드)
      │  ├─ FactoryChart (공장별 차트)
      │  ├─ ProductChart (제품별 차트)
      │  ├─ MonthlyTrendChart (월별 트렌드)
      │  ├─ RegionChart (지역별 차트)
      │  ├─ ShiftChart (교대조별 차트)
      │  └─ QualityChart (품질 통계)
      │     └─ StatCard × 2
      └─ InsightsSection (인사이트)
         └─ InsightCard × 3
```

### 4.2 핵심 컴포넌트 상세

#### 4.2.1 Header
**위치**: App.jsx:27-30
**목적**: 애플리케이션 타이틀 및 설명 표시

**구조**:
```jsx
<div className="header">
  <h1>🏭 생산 데이터 분석 대시보드</h1>
  <p>엑셀 파일을 업로드하여 실시간 데이터 분석 및 시각화</p>
</div>
```

**스타일**:
- 배경: 그라디언트 (보라색 계열)
- 텍스트 색상: 흰색
- 패딩: 30px
- 모서리: 10px 라운드
- 그림자: 0 4px 6px rgba(0,0,0,0.1)

#### 4.2.2 FileUpload
**파일**: FileUpload.jsx
**목적**: 파일 선택 및 업로드 처리

**Props**:
- `onAnalysisComplete`: 분석 완료 콜백
- `onError`: 에러 처리 콜백
- `loading`: 로딩 상태
- `setLoading`: 로딩 상태 설정

**상태**:
- `file`: 선택된 파일
- `dragOver`: 드래그 오버 상태

**주요 기능**:
- 드래그 앤 드롭 파일 선택
- 클릭하여 파일 선택
- 파일 형식 검증 (.xlsx, .xls)
- 파일 업로드 및 분석 요청
- 진행 상태 표시

#### 4.2.3 Dashboard
**파일**: Dashboard.jsx
**목적**: 분석 결과 시각화

**Props**:
- `data`: 분석 결과 객체
  - `summary`: 요약 통계
  - `factory`: 공장별 데이터
  - `product`: 제품별 데이터
  - `monthly`: 월별 트렌드
  - `region`: 지역별 데이터
  - `shift`: 교대조별 데이터
  - `quality`: 품질 분포
  - `insights`: 주요 인사이트

**구성 요소**:
1. SummaryCards: 6개 요약 카드
2. ChartGrid: 6개 차트
3. InsightsSection: 3개 인사이트 카드

#### 4.2.4 SummaryCards
**파일**: SummaryCards.jsx
**목적**: 주요 지표 요약 카드 표시

**카드 목록**:
1. **총 생산량** (톤)
2. **평균 수율** (%)
3. **총 순수익** ($M)
4. **평균 스크랩율** (%) - 2자리 소수점
5. **평균 재작업율** (%) - 2자리 소수점
6. **평균 마진** (%)

**스타일 특징**:
- 각 카드별 고유 그라디언트 배경
- 흰색 텍스트
- 카드 크기: 최소 250px, 반응형
- 그림자 효과

#### 4.2.5 차트 컴포넌트

**공통 라이브러리**: Recharts

##### FactoryChart (공장별 분석)
- **차트 타입**: 이중 축 막대 차트
- **데이터**:
  - 좌측 Y축: 생산량 (톤)
  - 우측 Y축: 순수익 (USD)
  - X축: 공장명
- **색상**:
  - 생산량: #8884d8 (파란색)
  - 순수익: #82ca9d (녹색)

##### ProductChart (제품별 분석)
- **차트 타입**: 가로 막대 차트
- **데이터**: 제품별 순수익
- **색상**: 6가지 색상 순환
- **정렬**: 순수익 내림차순

##### MonthlyTrendChart (월별 트렌드)
- **차트 타입**: 이중 축 선 차트
- **데이터**:
  - 좌측 Y축: 생산량 (톤)
  - 우측 Y축: 수율 (%)
  - X축: 연월
- **색상**:
  - 생산량: #8884d8 (파란색)
  - 수율: #82ca9d (녹색)

##### RegionChart (지역별 분석)
- **차트 타입**: 파이 차트
- **데이터**: 지역별 순수익
- **레이블**: 지역명 + 비율(%)
- **색상**: 7가지 색상 순환

##### ShiftChart (교대조별 분석)
- **차트 타입**: 레이더 차트
- **데이터**:
  - 수율
  - 평균 생산량
  - 평균 순수익
- **색상**: 3가지 색상 (교대조별)

##### QualityChart (품질 통계)
- **차트 타입**: 통계 그리드 (3열 레이아웃)
- **구성**:
  - 수율 통계 (평균, 중앙값, 최소, 최대)
  - 스크랩율 통계 (평균, 중앙값, 최소, 최대)
  - 재작업율 통계 (평균, 중앙값, 최소, 최대)
- **색상**:
  - 수율: #10b981 (녹색)
  - 스크랩율: #ef4444 (빨간색)
  - 재작업율: #f59e0b (주황색)
- **단위**: 모든 값에 % 표시

#### 4.2.6 InsightsSection
**위치**: Dashboard.jsx:60-93
**목적**: 주요 인사이트 강조 표시

**인사이트 카드**:
1. **최고 성과 공장**
   - 배경: 연한 녹색
   - 테두리: 녹색
   - 데이터: 공장명, 순수익

2. **최고 수익 제품**
   - 배경: 연한 파란색
   - 테두리: 파란색
   - 데이터: 제품명, 순수익

3. **저품질 배치**
   - 배경: 연한 빨간색
   - 테두리: 빨간색
   - 데이터: 배치 수, 비율(%)

---

## 5. 디자인 시스템

### 5.1 색상 팔레트

#### 주 색상 (Primary)
```css
Primary Gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%)
Primary Color: #667eea
Primary Dark: #764ba2
```

#### 보조 색상 (Secondary)
```css
Blue: #8884d8
Green: #82ca9d, #10b981
Red: #ef4444
Yellow: #ffc658
```

#### 의미론적 색상
```css
Success: #10b981
  - Background: #f0fdf4
  - Border: #10b981
  - Text: #065f46, #047857

Info: #3b82f6
  - Background: #eff6ff
  - Border: #3b82f6
  - Text: #1e40af, #2563eb

Error: #ef4444
  - Background: #fef2f2
  - Border: #ef4444
  - Text: #991b1b, #dc2626

Warning: #f59e0b
  - Background: #fffbeb
  - Border: #f59e0b
```

#### 중립 색상 (Neutral)
```css
Background: #f5f7fa
White: #ffffff
Light Gray: #f7fafc, #edf2f7, #e2e8f0
Medium Gray: #cbd5e0, #a0aec0
Dark Gray: #718096, #4a5568
Text: #2d3748
```

#### 차트 색상 팔레트
```css
Chart Colors: [
  #0088FE, // 파란색
  #00C49F, // 청록색
  #FFBB28, // 황색
  #FF8042, // 주황색
  #8884D8, // 보라색
  #82CA9D, // 녹색
  #FFC658  // 노란색
]
```

### 5.2 타이포그래피

#### 폰트 패밀리
```css
Primary: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
         'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
         sans-serif

Code: source-code-pro, Menlo, Monaco, Consolas, 'Courier New', monospace
```

#### 폰트 크기
```css
H1 (Header): 2rem (32px)
H2 (Card Title): 1.5rem (24px)
H3 (Card Subtitle): 0.9rem (14.4px)
Body Large: 1.2rem (19.2px)
Body Normal: 1rem (16px)
Body Small: 0.85rem (13.6px)
Caption: 0.85rem (13.6px)

Summary Card Value: 2rem (32px)
Insight Value: 1.5rem (24px)
```

#### 폰트 두께
```css
Normal: 400
Bold: 700
```

### 5.3 간격 (Spacing)

```css
Container Padding: 20px
Header Padding: 30px
Card Padding: 25px
Section Margin: 30px
Card Margin: 20px
Grid Gap: 20px
Element Gap: 10px, 15px
```

### 5.4 모서리 (Border Radius)

```css
Large: 10px (헤더, 카드)
Medium: 8px (통계 카드)
Small: 6px (버튼, 인포 박스)
```

### 5.5 그림자 (Shadows)

```css
Header Shadow: 0 4px 6px rgba(0, 0, 0, 0.1)
Card Shadow: 0 2px 4px rgba(0, 0, 0, 0.1)
```

### 5.6 테두리 (Borders)

```css
Upload Zone: 3px dashed #cbd5e0
Info Box Left Border: 4px solid (색상 변수)
Card Bottom Border: 2px solid #e2e8f0
```

---

## 6. 인터랙션 정의

### 6.1 업로드 영역 인터랙션

#### 6.1.1 호버 효과
**대상**: `.upload-zone`
```css
Normal State:
  border: 3px dashed #cbd5e0
  background: transparent

Hover State:
  border-color: #667eea
  background-color: #f7fafc
  transition: all 0.3s ease
```

#### 6.1.2 드래그 오버 효과
**대상**: `.upload-zone.dragover`
```css
Drag Over State:
  border-color: #667eea
  background-color: #edf2f7
```

#### 6.1.3 클릭 이벤트
**동작**: 파일 선택 다이얼로그 열기
```javascript
onClick={() => fileInputRef.current?.click()}
```

### 6.2 버튼 인터랙션

#### 6.2.1 업로드 버튼
**대상**: `.upload-button`

**Normal State**:
```css
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%)
color: white
padding: 12px 30px
cursor: pointer
```

**Hover State**:
```css
transform: translateY(-2px)
transition: transform 0.2s
```

**Disabled State**:
```css
opacity: 0.6
cursor: not-allowed
```

**로딩 상태**:
- 텍스트 변경: "업로드 및 분석 시작" → "분석 중..."
- disabled 속성 활성화

### 6.3 파일 선택 플로우

```
1. 사용자 파일 선택 (드래그 또는 클릭)
   ↓
2. 파일 형식 검증
   ├─ 성공 → 파일 정보 표시
   └─ 실패 → 에러 메시지 표시
   ↓
3. 업로드 버튼 활성화
   ↓
4. 버튼 클릭
   ↓
5. 로딩 상태 표시
   - 버튼 비활성화
   - "분석 중..." 텍스트
   - 로딩 인디케이터 표시
   ↓
6. API 요청
   ├─ 성공 → 대시보드 표시
   └─ 실패 → 에러 메시지 표시
```

### 6.4 차트 인터랙션

#### 6.4.1 툴팁
**모든 차트 공통**:
- 호버 시 데이터 상세 표시
- 배경: 흰색
- 테두리: #ccc 1px
- 숫자 포맷: 천 단위 구분 기호

#### 6.4.2 레전드
- 클릭 시 해당 데이터 시리즈 표시/숨김 (Recharts 기본 동작)

### 6.5 상태 전환

#### 6.5.1 초기 → 업로드
```
[파일 업로드 화면]
  ↓ 파일 선택
[파일 정보 표시 + 버튼 활성화]
  ↓ 버튼 클릭
[로딩 상태]
  ↓ 분석 완료
[대시보드 화면]
```

#### 6.5.2 대시보드 → 초기
```
[대시보드 화면]
  ↓ "새 파일 업로드" 클릭
[파일 업로드 화면]
```

---

## 7. 반응형 디자인

### 7.1 브레이크포인트

```css
Desktop: > 768px
Mobile: ≤ 768px
```

### 7.2 레이아웃 변경

#### 7.2.1 Desktop (> 768px)

**Summary Grid**:
```css
grid-template-columns: repeat(auto-fit, minmax(250px, 1fr))
gap: 20px
```
→ 최대 6열 (화면 크기에 따라 자동 조정)

**Chart Grid**:
```css
grid-template-columns: repeat(auto-fit, minmax(500px, 1fr))
gap: 20px
```
→ 최대 2열

#### 7.2.2 Mobile (≤ 768px)

**Summary Grid**:
```css
grid-template-columns: 1fr
```
→ 1열 (세로로 쌓임)

**Chart Grid**:
```css
grid-template-columns: 1fr
```
→ 1열 (세로로 쌓임)

### 7.3 반응형 고려사항

1. **터치 타겟 크기**: 버튼 최소 44x44px (모바일 권장 사이즈)
2. **텍스트 가독성**: 최소 폰트 사이즈 14px 유지
3. **차트 높이**: 고정 300px (모든 기기에서 일관성)
4. **컨테이너 최대 너비**: 1400px (대형 모니터 대응)

---

## 8. 접근성

### 8.1 현재 구현 상태

#### 8.1.1 시맨틱 HTML
- ✅ 헤더: `<h1>`, `<h2>`, `<h3>` 사용
- ✅ 버튼: `<button>` 요소 사용
- ⚠️ 랜드마크 역할 미사용 (개선 필요)

#### 8.1.2 키보드 접근성
- ✅ 버튼 포커스 가능
- ✅ 파일 입력 포커스 가능
- ⚠️ 업로드 영역 키보드 접근 제한적

#### 8.1.3 색상 대비
- ✅ 헤더 흰색 텍스트 on 보라색 배경 (충분한 대비)
- ✅ 에러 메시지 빨간색 (명확한 구분)
- ⚠️ 차트 색상 대비 검증 필요

#### 8.1.4 대체 텍스트
- ⚠️ 이모지 아이콘에 대한 설명 없음
- ⚠️ 차트에 대한 텍스트 대안 없음

### 8.2 개선 권장사항

#### 8.2.1 ARIA 레이블 추가
```jsx
// 업로드 영역
<div
  className="upload-zone"
  role="button"
  aria-label="엑셀 파일 업로드 영역, 클릭하거나 파일을 드롭하세요"
  tabIndex={0}
>

// 로딩 상태
<div
  className="loading"
  role="status"
  aria-live="polite"
  aria-label="데이터 분석 중입니다"
>

// 차트 섹션
<div
  className="card"
  role="region"
  aria-label="공장별 생산량 및 수익 차트"
>
```

#### 8.2.2 키보드 내비게이션 개선
```jsx
// 업로드 영역에 Enter/Space 키 지원
const handleKeyDown = (e) => {
  if (e.key === 'Enter' || e.key === ' ') {
    fileInputRef.current?.click()
  }
}
```

#### 8.2.3 스크린 리더 지원
```jsx
// 차트 데이터 요약
<div className="sr-only">
  공장별 생산량: APAC-1 공장 1,234톤, AMER-2 공장 567톤...
</div>
```

---

## 9. 개선 제안사항

### 9.1 UX 개선

#### 9.1.1 진행 표시 강화
**현재**: 단순 "분석 중..." 텍스트
**개선안**:
- 진행률 바 추가
- 단계별 상태 표시 (업로드 중 → 분석 중 → 시각화 중)
- 예상 소요 시간 표시

#### 9.1.2 데이터 필터링/정렬
**추가 기능**:
- 날짜 범위 선택
- 공장/제품별 필터
- 차트 데이터 정렬 옵션
- 데이터 테이블 뷰 추가

#### 9.1.3 데이터 내보내기
**추가 기능**:
- 차트 이미지 다운로드
- PDF 리포트 생성
- CSV 데이터 내보내기

#### 9.1.4 사용자 안내
**추가 요소**:
- 온보딩 튜토리얼
- 툴팁 도움말
- 샘플 데이터 제공
- FAQ 섹션

### 9.2 시각화 개선

#### 9.2.1 차트 커스터마이징
- 차트 타입 전환 옵션
- 색상 테마 선택
- 확대/축소 기능
- 전체화면 모드

#### 9.2.2 인터랙티브 대시보드
- 드릴다운 기능
- 차트 간 연동
- 동적 데이터 업데이트
- 비교 모드

### 9.3 성능 개선

#### 9.3.1 로딩 최적화
- 차트 Lazy Loading
- 이미지 최적화
- 코드 스플리팅

#### 9.3.2 대용량 데이터 처리
- 페이지네이션
- 가상 스크롤링
- 데이터 청킹

### 9.4 추가 기능

#### 9.4.1 데이터 관리
- 여러 파일 비교
- 히스토리 관리
- 즐겨찾기/북마크

#### 9.4.2 협업 기능
- 대시보드 공유
- 주석/코멘트
- 리포트 스케줄링

#### 9.4.3 고급 분석
- 예측 분석
- 이상치 탐지
- 트렌드 분석
- 상관관계 분석

### 9.5 기술적 개선

#### 9.5.1 에러 처리
**현재**: 단순 에러 메시지
**개선안**:
- 에러 타입별 상세 메시지
- 복구 제안
- 로그 수집

#### 9.5.2 상태 관리
**현재**: useState (로컬 상태)
**개선안**:
- Context API 또는 Redux
- 캐싱 전략
- 낙관적 UI 업데이트

#### 9.5.3 테스트
**추가 필요**:
- 단위 테스트
- 통합 테스트
- E2E 테스트
- 시각적 회귀 테스트

---

## 10. 기술 스택

### 10.1 Frontend
```
Framework: React 18
Build Tool: Vite 5
Charts: Recharts
HTTP Client: Axios
Styling: CSS3 (Vanilla)
```

### 10.2 Backend
```
Framework: FastAPI
Data Processing: Pandas, NumPy
Server: Uvicorn
```

### 10.3 개발 도구
```
Package Manager: npm
Version Control: Git
```

---

## 11. 파일 구조

```
frontend/
├── src/
│   ├── components/
│   │   ├── FileUpload.jsx          # 파일 업로드 컴포넌트
│   │   ├── Dashboard.jsx           # 대시보드 메인
│   │   ├── SummaryCards.jsx        # 요약 카드
│   │   └── Charts/
│   │       ├── FactoryChart.jsx    # 공장별 차트
│   │       ├── ProductChart.jsx    # 제품별 차트
│   │       ├── MonthlyTrendChart.jsx # 월별 트렌드
│   │       ├── RegionChart.jsx     # 지역별 차트
│   │       ├── ShiftChart.jsx      # 교대조별 차트
│   │       └── QualityChart.jsx    # 품질 통계
│   ├── App.jsx                     # 메인 애플리케이션
│   ├── main.jsx                    # 엔트리 포인트
│   └── index.css                   # 글로벌 스타일
├── index.html                      # HTML 템플릿
├── package.json                    # 의존성
└── vite.config.js                  # Vite 설정

backend/
├── app.py                          # FastAPI 서버
├── analysis.py                     # 데이터 분석 로직
└── requirements.txt                # Python 의존성
```

---

## 12. API 명세

### 12.1 파일 업로드
```
POST /api/upload
Content-Type: multipart/form-data

Request:
  file: <Excel File>

Response:
  {
    "success": true,
    "message": "파일이 성공적으로 업로드되었습니다",
    "filename": "example.xlsx",
    "file_size": 128450,
    "file_path": "uploads/example.xlsx"
  }
```

### 12.2 데이터 분석
```
GET /api/analyze

Response:
  {
    "success": true,
    "data": {
      "summary": {...},
      "factory": [...],
      "product": [...],
      "monthly": [...],
      "region": [...],
      "shift": [...],
      "quality": {...},
      "correlation": {...},
      "insights": {...}
    }
  }
```

---

## 13. 버전 히스토리

| 버전 | 날짜 | 주요 변경사항 |
|------|------|---------------|
| 1.0.0 | 2025-10-30 | 초기 릴리즈 |
| 1.0.1 | 2025-10-30 | Null 데이터 처리 개선 (결함률, 비가동시간, 주문ID) |
| 1.1.0 | 2025-10-30 | 결함률 제거, 스크랩율/재작업율로 변경<br>- 요약 카드: 평균 결함률 → 평균 스크랩율, 평균 재작업율<br>- 품질 차트: 2열 → 3열 레이아웃 (수율, 스크랩율, 재작업율)<br>- 분석 데이터 건수 카드 제거 |

---

## 14. 참고 자료

- [React 공식 문서](https://react.dev/)
- [Recharts 문서](https://recharts.org/)
- [FastAPI 문서](https://fastapi.tiangolo.com/)
- [WCAG 2.1 가이드라인](https://www.w3.org/WAI/WCAG21/quickref/)
- [Material Design 가이드](https://material.io/design)

---

**문서 작성자**: Claude Code Assistant
**최종 수정일**: 2025-10-30
**문서 버전**: 1.1
