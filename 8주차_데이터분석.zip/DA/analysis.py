#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
데이터 분석 모듈
===============
엑셀 파일을 분석하고 대시보드용 데이터를 생성
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, List
from datetime import datetime


class ProductionDataAnalyzer:
    """생산 데이터 분석 클래스"""

    def __init__(self, file_path: str):
        """
        분석기 초기화

        Args:
            file_path: 엑셀 파일 경로
        """
        self.df = pd.read_excel(file_path)
        self._prepare_data()

    def _prepare_data(self):
        """데이터 전처리 및 파생 변수 생성"""
        # 시간 파생 변수 생성
        if '타임스탬프' in self.df.columns:
            self.df['타임스탬프'] = pd.to_datetime(self.df['타임스탬프'])
            self.df['연도'] = self.df['타임스탬프'].dt.year
            self.df['월'] = self.df['타임스탬프'].dt.month
            self.df['일'] = self.df['타임스탬프'].dt.day
            self.df['시간'] = self.df['타임스탬프'].dt.hour
            self.df['요일'] = self.df['타임스탬프'].dt.dayofweek
            self.df['분기'] = self.df['타임스탬프'].dt.quarter
            self.df['연월'] = self.df['타임스탬프'].dt.to_period('M').astype(str)

    def get_summary_stats(self) -> Dict[str, Any]:
        """전체 요약 통계"""
        return {
            'total_records': int(len(self.df)),
            'total_production': float(self.df['처리량(톤)'].sum()),
            'avg_yield': float(self.df['수율(%)'].mean()),
            'total_profit': float(self.df['순수익(USD)'].sum()),
            'avg_scrap_rate': float(self.df['스크랩율(%)'].mean()),
            'avg_rework_rate': float(self.df['재작업율(%)'].mean()),
            'avg_margin': float(self.df['총마진(%)'].mean()),
            'date_range': {
                'start': self.df['타임스탬프'].min().isoformat() if '타임스탬프' in self.df.columns else None,
                'end': self.df['타임스탬프'].max().isoformat() if '타임스탬프' in self.df.columns else None
            }
        }

    def get_factory_analysis(self) -> List[Dict[str, Any]]:
        """공장별 분석"""
        agg_dict = {
            '처리량(톤)': 'sum',
            '수율(%)': 'mean',
            '순수익(USD)': 'sum',
            '총마진(%)': 'mean',
            '스크랩율(%)': 'mean',
            '재작업율(%)': 'mean'
        }

        # 선택적 컬럼 추가
        if '비가동시간(분)' in self.df.columns:
            agg_dict['비가동시간(분)'] = 'sum'

        factory_data = self.df.groupby('공장').agg(agg_dict).round(2)

        result = []
        for factory, row in factory_data.iterrows():
            item = {
                'factory': factory,
                'production': float(row['처리량(톤)']),
                'yield': float(row['수율(%)']),
                'profit': float(row['순수익(USD)']),
                'margin': float(row['총마진(%)']),
                'scrap_rate': float(row['스크랩율(%)']),
                'rework_rate': float(row['재작업율(%)'])
            }

            # 선택적 필드 추가
            if '비가동시간(분)' in row.index:
                item['downtime'] = float(row['비가동시간(분)'])
            else:
                item['downtime'] = None

            result.append(item)

        return result

    def get_product_analysis(self) -> List[Dict[str, Any]]:
        """제품별 분석"""
        product_data = self.df.groupby('제품').agg({
            '처리량(톤)': 'sum',
            '수율(%)': 'mean',
            '순수익(USD)': 'sum',
            '총마진(%)': 'mean',
            '스크랩율(%)': 'mean',
            '재작업율(%)': 'mean'
        }).round(2)

        result = []
        for product, row in product_data.iterrows():
            result.append({
                'product': product,
                'production': float(row['처리량(톤)']),
                'yield': float(row['수율(%)']),
                'profit': float(row['순수익(USD)']),
                'margin': float(row['총마진(%)']),
                'scrap_rate': float(row['스크랩율(%)']),
                'rework_rate': float(row['재작업율(%)'])
            })

        return sorted(result, key=lambda x: x['profit'], reverse=True)

    def get_monthly_trend(self) -> List[Dict[str, Any]]:
        """월별 트렌드"""
        if '연월' not in self.df.columns:
            return []

        monthly_data = self.df.groupby('연월').agg({
            '처리량(톤)': 'sum',
            '수율(%)': 'mean',
            '순수익(USD)': 'sum'
        }).round(2)

        result = []
        for month, row in monthly_data.iterrows():
            result.append({
                'month': str(month),
                'production': float(row['처리량(톤)']),
                'yield': float(row['수율(%)']),
                'profit': float(row['순수익(USD)'])
            })

        return result

    def get_region_analysis(self) -> List[Dict[str, Any]]:
        """고객지역별 분석"""
        agg_dict = {
            '처리량(톤)': 'sum',
            '순수익(USD)': 'sum',
            '총마진(%)': 'mean'
        }

        # 주문ID가 있으면 카운트 추가
        if '주문ID' in self.df.columns:
            agg_dict['주문ID'] = 'count'

        region_data = self.df.groupby('고객지역').agg(agg_dict).round(2)

        result = []
        for region, row in region_data.iterrows():
            item = {
                'region': region,
                'production': float(row['처리량(톤)']),
                'profit': float(row['순수익(USD)']),
                'margin': float(row['총마진(%)'])
            }

            if '주문ID' in row.index:
                item['orders'] = int(row['주문ID'])
            else:
                item['orders'] = 0

            result.append(item)

        return sorted(result, key=lambda x: x['profit'], reverse=True)

    def get_shift_analysis(self) -> List[Dict[str, Any]]:
        """교대조별 분석"""
        shift_data = self.df.groupby('교대조').agg({
            '처리량(톤)': 'mean',
            '수율(%)': 'mean',
            '스크랩율(%)': 'mean',
            '재작업율(%)': 'mean',
            '순수익(USD)': 'mean'
        }).round(2)

        result = []
        for shift, row in shift_data.iterrows():
            result.append({
                'shift': shift,
                'avg_production': float(row['처리량(톤)']),
                'yield': float(row['수율(%)']),
                'scrap_rate': float(row['스크랩율(%)']),
                'rework_rate': float(row['재작업율(%)']),
                'avg_profit': float(row['순수익(USD)'])
            })

        return result

    def get_quality_distribution(self) -> Dict[str, Any]:
        """품질 분포 데이터"""
        return {
            'yield_stats': {
                'mean': float(self.df['수율(%)'].mean()),
                'median': float(self.df['수율(%)'].median()),
                'std': float(self.df['수율(%)'].std()),
                'min': float(self.df['수율(%)'].min()),
                'max': float(self.df['수율(%)'].max())
            },
            'scrap_stats': {
                'mean': float(self.df['스크랩율(%)'].mean()),
                'median': float(self.df['스크랩율(%)'].median()),
                'std': float(self.df['스크랩율(%)'].std()),
                'min': float(self.df['스크랩율(%)'].min()),
                'max': float(self.df['스크랩율(%)'].max())
            },
            'rework_stats': {
                'mean': float(self.df['재작업율(%)'].mean()),
                'median': float(self.df['재작업율(%)'].median()),
                'std': float(self.df['재작업율(%)'].std()),
                'min': float(self.df['재작업율(%)'].min()),
                'max': float(self.df['재작업율(%)'].max())
            }
        }

    def get_correlation_data(self) -> Dict[str, Any]:
        """상관관계 데이터"""
        # 가능한 모든 메트릭
        all_metrics = [
            '처리량(톤)', '수율(%)', '스크랩율(%)', '재작업율(%)',
            '결함(ppm)', '비가동시간(분)', '총마진(%)', '순수익(USD)'
        ]

        # 실제 존재하는 컬럼만 선택
        key_metrics = [m for m in all_metrics if m in self.df.columns]

        correlation_matrix = self.df[key_metrics].corr().round(3)

        # 상관관계 매트릭스를 리스트로 변환
        corr_data = []
        for i, row_name in enumerate(correlation_matrix.index):
            for j, col_name in enumerate(correlation_matrix.columns):
                corr_data.append({
                    'x': col_name,
                    'y': row_name,
                    'value': float(correlation_matrix.iloc[i, j])
                })

        return {
            'metrics': key_metrics,
            'data': corr_data
        }

    def get_top_insights(self) -> Dict[str, Any]:
        """주요 인사이트"""
        factory_profit = self.df.groupby('공장')['순수익(USD)'].sum()
        product_profit = self.df.groupby('제품')['순수익(USD)'].sum()

        best_factory = factory_profit.idxmax()
        best_product = product_profit.idxmax()

        low_yield_count = len(self.df[self.df['수율(%)'] < 85])

        return {
            'best_factory': {
                'name': best_factory,
                'profit': float(factory_profit[best_factory])
            },
            'best_product': {
                'name': best_product,
                'profit': float(product_profit[best_product])
            },
            'low_yield_batches': {
                'count': int(low_yield_count),
                'percentage': float(low_yield_count / len(self.df) * 100)
            },
            'factory_count': int(self.df['공장'].nunique()),
            'product_count': int(self.df['제품'].nunique()),
            'total_orders': int(self.df['주문ID'].nunique() if '주문ID' in self.df.columns else 0)
        }

    def get_all_analysis(self) -> Dict[str, Any]:
        """모든 분석 결과를 하나의 딕셔너리로 반환"""
        return {
            'summary': self.get_summary_stats(),
            'factory': self.get_factory_analysis(),
            'product': self.get_product_analysis(),
            'monthly': self.get_monthly_trend(),
            'region': self.get_region_analysis(),
            'shift': self.get_shift_analysis(),
            'quality': self.get_quality_distribution(),
            'correlation': self.get_correlation_data(),
            'insights': self.get_top_insights()
        }
