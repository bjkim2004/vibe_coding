### 요구사항
1. supabase DB 테이블 생성
2. 전환퍼널_가상데이터.csv 업로드
3. csv 파일을 supabase DB에 저장
4. backend/api_server.py로 backend 서버 환경 구성, CSV파일 분석
5. DB에 접속, CSV파일 분석 결과 저장
6. 분석결과 frontend dash board 화면 구성

### supabase DB 정보
user: postgres.dktrdivmekmioqqkclzx
password : libero201!
url: aws-1-ap-northeast-2.pooler.supabase.com
port: 6543
dbname: postgres
 