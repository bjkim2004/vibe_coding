# 화면 설계서 (Screen Design Specification)
# 전환 퍼널 분석 대시보드

**문서 버전**: 1.0
**작성일**: 2025-10-30
**작성자**: Design Team
**승인자**: [승인자명]
**상태**: Draft

---

## 목차

1. [개요](#1-개요)
2. [화면 구조](#2-화면-구조)
3. [화면별 상세 설계](#3-화면별-상세-설계)
4. [UI 컴포넌트 명세](#4-ui-컴포넌트-명세)
5. [인터랙션 정의](#5-인터랙션-정의)
6. [반응형 디자인](#6-반응형-디자인)
7. [디자인 시스템](#7-디자인-시스템)
8. [접근성](#8-접근성)
9. [부록](#9-부록)

---

## 1. 개요

### 1.1 문서 목적

본 문서는 전환 퍼널 분석 대시보드의 화면 설계를 상세히 정의하여, 개발팀과 디자인팀 간의 명확한 커뮤니케이션을 지원하고, 일관성 있는 사용자 경험을 구현하기 위해 작성되었습니다.

### 1.2 대상 사용자

- **주요 사용자**: 마케팅 매니저, 제품 매니저, 데이터 분석가
- **보조 사용자**: 경영진, 비즈니스 인텔리전스 팀
- **기술 수준**: 중급 (데이터 분석 도구 사용 경험 보유)

### 1.3 디자인 원칙

1. **명확성**: 데이터를 직관적으로 이해할 수 있도록 시각화
2. **일관성**: 전체 화면에서 통일된 UI/UX 패턴 적용
3. **효율성**: 최소한의 클릭으로 원하는 정보 접근
4. **접근성**: WCAG 2.1 AA 수준 준수
5. **반응성**: 다양한 디바이스에서 최적화된 경험 제공

---

## 2. 화면 구조

### 2.1 전체 레이아웃

```
┌─────────────────────────────────────────────────────────────┐
│                        HEADER (고정)                          │
│  ┌───────────────────────────────────────────────────────┐  │
│  │ [로고] 전환 퍼널 분석 대시보드      [CSV 업로드 버튼]   │  │
│  └───────────────────────────────────────────────────────┘  │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐          │
│  │ 총 세션  │ │ 전환율   │ │ 총 매출  │ │   AOV   │          │
│  │ 10,000  │ │  8.23%  │ │ 143억원  │ │ 174만원  │          │
│  └─────────┘ └─────────┘ └─────────┘ └─────────┘          │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                      MAIN CONTENT (스크롤)                    │
│                                                               │
│  ┌─────────────────────────────────────────────────────┐    │
│  │ 전환 퍼널 (Full Width)                              │    │
│  │ ┌─────────────────────────────────────────────────┐ │    │
│  │ │      [퍼널 차트 - 가로 막대형]                   │ │    │
│  │ └─────────────────────────────────────────────────┘ │    │
│  │ [퍼널 데이터 테이블]                                │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                               │
│  ┌──────────────────────────┐ ┌──────────────────────────┐  │
│  │ 유입 채널별 분석          │ │ 기기별 분석              │  │
│  │ [막대 차트]              │ │ [도넛 차트]              │  │
│  │ [데이터 테이블]          │ │ [데이터 테이블]          │  │
│  └──────────────────────────┘ └──────────────────────────┘  │
│                                                               │
│  ┌──────────────────────────┐ ┌──────────────────────────┐  │
│  │ A/B 테스트 분석          │ │ 사용자 유형 분석          │  │
│  │ [비교 막대 차트]          │ │ [그룹 막대 차트]          │  │
│  └──────────────────────────┘ └──────────────────────────┘  │
│                                                               │
│  ┌───────────┐ ┌───────────┐ ┌───────────┐                  │
│  │ 지역별     │ │ 카테고리별 │ │ 로딩시간   │                  │
│  │ [차트]    │ │ [차트]    │ │ [차트]    │                  │
│  └───────────┘ └───────────┘ └───────────┘                  │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                         FOOTER                                │
│  마지막 업데이트: 2025-10-30 14:30:25                        │
│  © 2025 Funnel Analytics Dashboard                           │
└─────────────────────────────────────────────────────────────┘
```

### 2.2 화면 플로우

```
[대시보드 로딩]
    │
    ├─→ API 호출 (개요 통계)
    ├─→ API 호출 (퍼널 데이터)
    ├─→ API 호출 (채널별 데이터)
    ├─→ API 호출 (기기별 데이터)
    └─→ 차트 렌더링

[CSV 업로드 버튼 클릭]
    │
    ├─→ [파일 선택 다이얼로그]
    │       │
    │       ├─→ 파일 선택
    │       └─→ 업로드 실행
    │              │
    │              ├─→ [로딩 상태]
    │              │
    │              ├─→ [성공] → 대시보드 새로고침
    │              └─→ [실패] → 에러 메시지 표시
```

### 2.3 화면 그리드 시스템

**Desktop (>1024px)**:
- Container: 1200px max-width
- Gutter: 24px
- Columns: 12-column grid
- Grid Gap: 24px

**Tablet (768px - 1024px)**:
- Container: 100% width
- Padding: 16px
- Columns: 8-column grid
- Grid Gap: 16px

**Mobile (<768px)**:
- Container: 100% width
- Padding: 16px
- Columns: 4-column grid
- Grid Gap: 16px

---

## 3. 화면별 상세 설계

### 3.1 헤더 영역

#### 3.1.1 레이아웃

```
┌──────────────────────────────────────────────────────────┐
│ Padding: 20px                                             │
│ ┌────────┐                                     ┌────────┐ │
│ │ [아이콘] │ 전환 퍼널 분석 대시보드            │ CSV 업로드│ │
│ └────────┘                                     └────────┘ │
└──────────────────────────────────────────────────────────┘
```

**컴포넌트**:
- **로고/아이콘**: 24×24px, 파란색 퍼널 아이콘
- **제목**: "전환 퍼널 분석 대시보드", 24px, 굵게
- **업로드 버튼**: 파란색 버튼, "CSV 업로드" 텍스트

**스타일**:
```css
.header {
    background: #ffffff;
    border-bottom: 1px solid #e5e7eb;
    padding: 20px 32px;
    position: sticky;
    top: 0;
    z-index: 100;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.header-title {
    font-size: 24px;
    font-weight: 700;
    color: #111827;
    display: flex;
    align-items: center;
    gap: 12px;
}

.upload-button {
    background: #3b82f6;
    color: white;
    padding: 10px 20px;
    border-radius: 8px;
    border: none;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.2s;
}

.upload-button:hover {
    background: #2563eb;
}
```

#### 3.1.2 통계 카드

```
┌─────────────────────────────────────────────────────────┐
│ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐        │
│ │  아이콘  │ │  아이콘  │ │  아이콘  │ │  아이콘  │        │
│ │ 총 세션  │ │  전환율  │ │ 총 매출  │ │   AOV   │        │
│ │ 10,000  │ │  8.23%  │ │ 143억원  │ │ 174만원  │        │
│ │ ──────  │ │ ──────  │ │ ──────  │ │ ──────  │        │
│ │기간정보 │ │기간정보 │ │기간정보 │ │기간정보 │        │
│ └─────────┘ └─────────┘ └─────────┘ └─────────┘        │
└─────────────────────────────────────────────────────────┘
```

**카드 구조**:
1. **아이콘** (32×32px)
   - 세션: 👥 (사용자 아이콘)
   - 전환율: 📊 (차트 아이콘)
   - 매출: 💰 (돈 아이콘)
   - AOV: 🛒 (장바구니 아이콘)

2. **레이블** (14px, 회색)
   - "총 세션", "전환율", "총 매출", "평균 주문액"

3. **값** (32px, 굵게, 검정)
   - 숫자는 천 단위 구분자 사용
   - 통화는 억/만 단위 변환
   - 퍼센트는 소수점 2자리

4. **보조 정보** (12px, 연한 회색)
   - 데이터 기간 표시

**스타일**:
```css
.stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
    margin-top: 24px;
}

.stat-card {
    background: #ffffff;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    padding: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    transition: transform 0.2s, box-shadow 0.2s;
}

.stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.stat-icon {
    font-size: 32px;
    margin-bottom: 12px;
}

.stat-label {
    font-size: 14px;
    color: #6b7280;
    margin-bottom: 8px;
}

.stat-value {
    font-size: 32px;
    font-weight: 700;
    color: #111827;
    margin-bottom: 8px;
}

.stat-period {
    font-size: 12px;
    color: #9ca3af;
    padding-top: 8px;
    border-top: 1px solid #f3f4f6;
}
```

### 3.2 전환 퍼널 섹션

#### 3.2.1 레이아웃

```
┌───────────────────────────────────────────────────────┐
│ 전환 퍼널                                [새로고침 버튼] │
├───────────────────────────────────────────────────────┤
│                                                        │
│  Visit       ████████████████████████████  10,000    │
│  (100.0%)                                             │
│                                                        │
│  Engage      ████████████████            5,498        │
│  (54.98%)                                             │
│                                                        │
│  Cart        ██████                     2,000         │
│  (20.0%)                                              │
│                                                        │
│  Checkout    ███                        1,050         │
│  (10.5%)                                              │
│                                                        │
│  Purchase    ██                           823         │
│  (8.23%)                                              │
│                                                        │
├───────────────────────────────────────────────────────┤
│ [데이터 테이블]                                        │
│ 단계 │ 사용자수 │ 전환율 │ 단계별전환율 │ 이탈률      │
│ ─────┼─────────┼───────┼────────────┼─────────    │
│ Visit│ 10,000  │100.0% │    -       │   -         │
│ ...  │  ...    │  ...  │   ...      │  ...        │
└───────────────────────────────────────────────────────┘
```

**차트 설정**:
- **타입**: Horizontal Bar Chart (가로 막대)
- **색상**: 그라데이션 (진한 파란색 → 연한 파란색)
  - Visit: #3b82f6 (100%)
  - Engage: #3b82f6 (85%)
  - Cart: #3b82f6 (70%)
  - Checkout: #3b82f6 (55%)
  - Purchase: #3b82f6 (40%)
- **높이**: 400px
- **애니메이션**: 0.8초 easing

**테이블 구조**:
| 컬럼 | 너비 | 정렬 | 포맷 |
|------|------|------|------|
| 단계 | 20% | 왼쪽 | 텍스트 |
| 사용자 수 | 20% | 오른쪽 | 천 단위 구분 |
| 전환율 | 20% | 오른쪽 | % (소수점 2자리) |
| 단계별 전환율 | 20% | 오른쪽 | % (소수점 2자리) |
| 이탈률 | 20% | 오른쪽 | % (소수점 2자리) |

**인터랙션**:
- 마우스 오버 시 해당 단계 강조
- 툴팁 표시 (단계명, 사용자 수, 전환율, 이탈률)
- 클릭 시 해당 단계 상세 정보 표시 (Phase 2)

### 3.3 유입 채널별 분석 섹션

#### 3.3.1 레이아웃

```
┌────────────────────────────────┐
│ 유입 채널별 분석                │
├────────────────────────────────┤
│ [막대 차트]                    │
│                                │
│ Referral  ████████ 9.32%      │
│ Organic   ███████  9.05%      │
│ Social    ██████   8.98%      │
│ Paid      █████    8.47%      │
│ Direct    ████     7.92%      │
│ Email     ███      7.73%      │
│                                │
├────────────────────────────────┤
│ [데이터 테이블]                │
│ 채널 │ 세션수 │ 전환율 │ 매출  │
└────────────────────────────────┘
```

**차트 설정**:
- **타입**: Horizontal Bar Chart (전환율 기준 내림차순)
- **색상**: 채널별 고유 색상
  - Organic: #10b981 (녹색)
  - Paid Search: #f59e0b (주황)
  - Social: #8b5cf6 (보라)
  - Direct: #6b7280 (회색)
  - Referral: #3b82f6 (파란)
  - Email: #ef4444 (빨강)

### 3.4 기기별 분석 섹션

#### 3.4.1 레이아웃

```
┌────────────────────────────────┐
│ 기기별 분석                     │
├────────────────────────────────┤
│      [도넛 차트]               │
│                                │
│        ┌───────┐               │
│        │       │               │
│     ───┤ 44.3% ├───            │
│        │       │               │
│        └───────┘               │
│                                │
│  Desktop: 44.3% (4,430세션)   │
│  Mobile:  35.5% (3,550세션)   │
│  App:     20.2% (2,020세션)   │
│                                │
├────────────────────────────────┤
│ [데이터 테이블]                │
└────────────────────────────────┘
```

**차트 설정**:
- **타입**: Doughnut Chart (도넛)
- **색상**:
  - Desktop: #3b82f6 (파란)
  - Mobile Web: #10b981 (녹색)
  - App: #f59e0b (주황)
- **중앙 텍스트**: "총 세션"
- **Cutout**: 70%

### 3.5 CSV 업로드 모달

#### 3.5.1 모달 상태별 UI

**[상태 1] 초기 상태**
```
┌─────────────────────────────────────┐
│ CSV 파일 업로드          [X]        │
├─────────────────────────────────────┤
│                                     │
│    ┌───────────────────────┐       │
│    │                       │       │
│    │      📁                │       │
│    │                       │       │
│    │  파일을 선택하거나       │       │
│    │  드래그하여 놓으세요    │       │
│    │                       │       │
│    │  [파일 선택]          │       │
│    │                       │       │
│    └───────────────────────┘       │
│                                     │
│  지원 형식: CSV (UTF-8)             │
│  최대 크기: 50MB                    │
│                                     │
│              [취소]                 │
└─────────────────────────────────────┘
```

**[상태 2] 파일 선택됨**
```
┌─────────────────────────────────────┐
│ CSV 파일 업로드          [X]        │
├─────────────────────────────────────┤
│                                     │
│  선택된 파일:                        │
│  📄 funnel_data.csv (2.3 MB)       │
│                                     │
│  ✓ 파일 형식 확인                   │
│  ✓ 파일 크기 확인                   │
│                                     │
│         [취소]   [업로드]           │
└─────────────────────────────────────┘
```

**[상태 3] 업로드 중**
```
┌─────────────────────────────────────┐
│ CSV 파일 업로드          [X]        │
├─────────────────────────────────────┤
│                                     │
│  업로드 중...                        │
│                                     │
│  ⏳ [████████░░░░░░░░] 45%         │
│                                     │
│  데이터 처리 중 (10,000 / 23,450)  │
│                                     │
└─────────────────────────────────────┘
```

**[상태 4] 업로드 성공**
```
┌─────────────────────────────────────┐
│ CSV 파일 업로드          [X]        │
├─────────────────────────────────────┤
│                                     │
│         ✅                          │
│                                     │
│  업로드 완료!                        │
│                                     │
│  총 23,450건의 데이터가              │
│  성공적으로 업로드되었습니다.         │
│                                     │
│  - 구매 완료: 1,927건               │
│  - 전환율: 8.22%                    │
│                                     │
│  3초 후 대시보드가 새로고침됩니다    │
│                                     │
│              [확인]                 │
└─────────────────────────────────────┘
```

**[상태 5] 업로드 실패**
```
┌─────────────────────────────────────┐
│ CSV 파일 업로드          [X]        │
├─────────────────────────────────────┤
│                                     │
│         ❌                          │
│                                     │
│  업로드 실패                         │
│                                     │
│  오류: 필수 컬럼 'session_id'가     │
│        누락되었습니다.               │
│                                     │
│  다음 컬럼이 필요합니다:             │
│  - session_id                       │
│  - user_id                          │
│  - session_start_time               │
│                                     │
│         [다시 시도]                 │
└─────────────────────────────────────┘
```

**스타일**:
```css
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
}

.modal {
    background: white;
    border-radius: 12px;
    padding: 32px;
    max-width: 500px;
    width: 90%;
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 24px;
}

.modal-title {
    font-size: 20px;
    font-weight: 700;
}

.modal-close {
    font-size: 24px;
    cursor: pointer;
    color: #6b7280;
}

.file-drop-zone {
    border: 2px dashed #d1d5db;
    border-radius: 8px;
    padding: 48px 24px;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s;
}

.file-drop-zone:hover {
    border-color: #3b82f6;
    background: #f0f9ff;
}

.file-drop-zone.drag-over {
    border-color: #3b82f6;
    background: #dbeafe;
}

.progress-bar {
    width: 100%;
    height: 8px;
    background: #e5e7eb;
    border-radius: 4px;
    overflow: hidden;
}

.progress-bar-fill {
    height: 100%;
    background: linear-gradient(90deg, #3b82f6, #2563eb);
    transition: width 0.3s;
}
```

---

## 4. UI 컴포넌트 명세

### 4.1 버튼 컴포넌트

#### 4.1.1 Primary Button

**사용 예시**: CSV 업로드, 확인, 저장 등 주요 액션

```css
.btn-primary {
    background: #3b82f6;
    color: white;
    padding: 10px 20px;
    border-radius: 8px;
    border: none;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
}

.btn-primary:hover {
    background: #2563eb;
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(59, 130, 246, 0.3);
}

.btn-primary:active {
    transform: translateY(0);
}

.btn-primary:disabled {
    background: #9ca3af;
    cursor: not-allowed;
    transform: none;
}
```

**상태**:
- Default: 파란색 배경
- Hover: 진한 파란색, 약간 위로 이동
- Active: 눌림 효과
- Disabled: 회색, 커서 변경

#### 4.1.2 Secondary Button

**사용 예시**: 취소, 닫기 등 보조 액션

```css
.btn-secondary {
    background: white;
    color: #374151;
    padding: 10px 20px;
    border-radius: 8px;
    border: 1px solid #d1d5db;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
}

.btn-secondary:hover {
    background: #f9fafb;
    border-color: #9ca3af;
}
```

#### 4.1.3 Icon Button

**사용 예시**: 새로고침, 설정 등

```css
.btn-icon {
    background: transparent;
    color: #6b7280;
    padding: 8px;
    border-radius: 6px;
    border: none;
    cursor: pointer;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;
}

.btn-icon:hover {
    background: #f3f4f6;
    color: #111827;
}
```

### 4.2 카드 컴포넌트

#### 4.2.1 기본 카드

```css
.card {
    background: white;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    padding: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
}

.card-title {
    font-size: 18px;
    font-weight: 700;
    color: #111827;
}

.card-body {
    /* 차트 또는 테이블 영역 */
}

.card-footer {
    margin-top: 16px;
    padding-top: 16px;
    border-top: 1px solid #f3f4f6;
    font-size: 12px;
    color: #6b7280;
}
```

### 4.3 테이블 컴포넌트

#### 4.3.1 데이터 테이블

```css
.data-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 14px;
}

.data-table thead {
    background: #f9fafb;
    border-bottom: 2px solid #e5e7eb;
}

.data-table th {
    padding: 12px 16px;
    text-align: left;
    font-weight: 600;
    color: #374151;
}

.data-table td {
    padding: 12px 16px;
    border-bottom: 1px solid #f3f4f6;
}

.data-table tbody tr:hover {
    background: #f9fafb;
}

.data-table .text-right {
    text-align: right;
}

.data-table .text-center {
    text-align: center;
}
```

**테이블 기능**:
- 정렬: 컬럼 헤더 클릭 시 오름차순/내림차순
- Hover: 행에 마우스 오버 시 배경색 변경
- Responsive: 모바일에서 가로 스크롤

### 4.4 로딩 컴포넌트

#### 4.4.1 Spinner

```css
.spinner {
    width: 40px;
    height: 40px;
    border: 4px solid #f3f4f6;
    border-top-color: #3b82f6;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

.loading-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(255, 255, 255, 0.9);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    z-index: 10;
}

.loading-text {
    margin-top: 16px;
    font-size: 14px;
    color: #6b7280;
}
```

#### 4.4.2 Skeleton Loader

```css
.skeleton {
    background: linear-gradient(
        90deg,
        #f3f4f6 0%,
        #e5e7eb 50%,
        #f3f4f6 100%
    );
    background-size: 200% 100%;
    animation: skeleton-loading 1.5s ease-in-out infinite;
}

@keyframes skeleton-loading {
    0% { background-position: 200% 0; }
    100% { background-position: -200% 0; }
}

.skeleton-card {
    height: 120px;
    border-radius: 12px;
}

.skeleton-text {
    height: 16px;
    border-radius: 4px;
    margin-bottom: 8px;
}
```

### 4.5 Toast/알림 컴포넌트

```css
.toast {
    position: fixed;
    top: 24px;
    right: 24px;
    min-width: 300px;
    background: white;
    border-radius: 8px;
    padding: 16px;
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
    display: flex;
    align-items: center;
    gap: 12px;
    z-index: 1000;
    animation: slide-in 0.3s ease-out;
}

@keyframes slide-in {
    from {
        transform: translateX(400px);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

.toast.success {
    border-left: 4px solid #10b981;
}

.toast.error {
    border-left: 4px solid #ef4444;
}

.toast.warning {
    border-left: 4px solid #f59e0b;
}

.toast.info {
    border-left: 4px solid #3b82f6;
}

.toast-icon {
    font-size: 24px;
}

.toast-message {
    flex: 1;
    font-size: 14px;
    color: #374151;
}

.toast-close {
    cursor: pointer;
    color: #9ca3af;
}
```

---

## 5. 인터랙션 정의

### 5.1 차트 인터랙션

#### 5.1.1 마우스 오버 (Hover)

**동작**:
1. 마우스가 차트 영역에 진입하면 해당 데이터 포인트 강조
2. 툴팁 표시 (0.2초 지연)
3. 다른 데이터는 투명도 50% 감소

**툴팁 내용**:
```
┌─────────────────────┐
│ Organic             │
│ ─────────────────── │
│ 세션: 2,796         │
│ 전환율: 9.05%       │
│ 매출: 46억원        │
└─────────────────────┘
```

#### 5.1.2 클릭

**동작** (Phase 2):
1. 해당 데이터 포인트 선택
2. 상세 정보 패널 표시
3. 다른 차트와 연동 (필터링)

### 5.2 버튼 인터랙션

#### 5.2.1 클릭 피드백

1. **마우스 다운**: 약간 축소 (scale: 0.98)
2. **마우스 업**: 원래 크기로 복원
3. **액션 실행**: 로딩 상태 표시 (스피너 또는 텍스트 변경)

**예시**:
```javascript
// 업로드 버튼 클릭 시
버튼 텍스트: "CSV 업로드" → "업로드 중..." → "업로드 완료"
버튼 비활성화: disabled 속성 추가
```

### 5.3 모달 인터랙션

#### 5.3.1 열기

1. 배경 오버레이 페이드인 (0.3초)
2. 모달 스케일업 + 페이드인 (0.3초)
3. 배경 스크롤 비활성화

#### 5.3.2 닫기

**트리거**:
- [X] 버튼 클릭
- 배경 오버레이 클릭
- ESC 키 입력
- 자동 닫기 (성공 시 3초 후)

**애니메이션**:
1. 모달 스케일다운 + 페이드아웃 (0.2초)
2. 배경 오버레이 페이드아웃 (0.2초)
3. 배경 스크롤 활성화

### 5.4 파일 드래그 앤 드롭

#### 5.4.1 드래그 오버

```
초기 상태:
┌───────────────────┐
│  파일을 드래그     │
│  해주세요         │
└───────────────────┘

드래그 오버 시:
┌───────────────────┐
│  ✨ 파일을 놓아   │
│     주세요        │
└───────────────────┘
(배경색 변경, 테두리 강조)
```

**동작**:
1. `dragenter`: 테두리 색상 변경, 배경색 변경
2. `dragover`: 드롭 가능 커서 표시
3. `dragleave`: 원래 상태로 복원
4. `drop`: 파일 처리 시작

### 5.5 테이블 정렬

#### 5.5.1 컬럼 헤더 클릭

```
초기 상태:
채널 ↕   세션수 ↕   전환율 ↕

오름차순 정렬:
채널     세션수 ↕   전환율 ↑

내림차순 정렬:
채널     세션수 ↕   전환율 ↓
```

**동작**:
1. 컬럼 헤더 클릭 → 오름차순 정렬
2. 다시 클릭 → 내림차순 정렬
3. 다시 클릭 → 정렬 해제
4. 다른 컬럼 클릭 → 해당 컬럼으로 정렬, 이전 정렬 해제

---

## 6. 반응형 디자인

### 6.1 브레이크포인트

| 디바이스 | 너비 | 컨테이너 | 특징 |
|---------|------|---------|------|
| Mobile | < 768px | 100% - 32px | 1열 레이아웃 |
| Tablet | 768px - 1024px | 100% - 32px | 2열 레이아웃 |
| Desktop | > 1024px | 1200px max | 3-4열 레이아웃 |

### 6.2 레이아웃 변화

#### 6.2.1 통계 카드

**Desktop (>1024px)**:
```
┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐
│세션 │ │전환율│ │매출 │ │AOV  │
└─────┘ └─────┘ └─────┘ └─────┘
```

**Tablet (768-1024px)**:
```
┌─────┐ ┌─────┐
│세션 │ │전환율│
└─────┘ └─────┘
┌─────┐ ┌─────┐
│매출 │ │AOV  │
└─────┘ └─────┘
```

**Mobile (<768px)**:
```
┌─────┐ ┌─────┐
│세션 │ │전환율│
└─────┘ └─────┘
┌─────┐ ┌─────┐
│매출 │ │AOV  │
└─────┘ └─────┘
```

#### 6.2.2 차트 섹션

**Desktop**:
```
┌──────────┐ ┌──────────┐
│ 채널분석  │ │ 기기분석  │
└──────────┘ └──────────┘
```

**Tablet**:
```
┌──────────┐ ┌──────────┐
│ 채널분석  │ │ 기기분석  │
└──────────┘ └──────────┘
```

**Mobile**:
```
┌──────────┐
│ 채널분석  │
└──────────┘
┌──────────┐
│ 기기분석  │
└──────────┘
```

### 6.3 타이포그래피 조정

| 요소 | Desktop | Tablet | Mobile |
|------|---------|--------|--------|
| 페이지 제목 | 24px | 22px | 20px |
| 섹션 제목 | 18px | 17px | 16px |
| 통계 값 | 32px | 28px | 24px |
| 본문 | 14px | 14px | 14px |
| 캡션 | 12px | 12px | 12px |

### 6.4 모바일 최적화

#### 6.4.1 테이블 스크롤

**Mobile에서의 테이블**:
```css
@media (max-width: 767px) {
    .table-wrapper {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }

    .data-table {
        min-width: 600px;
    }
}
```

#### 6.4.2 터치 영역

**최소 터치 영역**: 44×44px

```css
@media (max-width: 767px) {
    .btn-primary,
    .btn-secondary {
        min-height: 44px;
        min-width: 88px;
    }

    .btn-icon {
        width: 44px;
        height: 44px;
    }
}
```

#### 6.4.3 차트 높이 조정

```css
@media (max-width: 767px) {
    .chart-container {
        height: 300px; /* Desktop: 400px */
    }
}
```

---

## 7. 디자인 시스템

### 7.1 색상 팔레트

#### 7.1.1 Primary Colors

```css
:root {
    /* Primary (Blue) */
    --primary-50: #eff6ff;
    --primary-100: #dbeafe;
    --primary-200: #bfdbfe;
    --primary-300: #93c5fd;
    --primary-400: #60a5fa;
    --primary-500: #3b82f6;  /* Main */
    --primary-600: #2563eb;
    --primary-700: #1d4ed8;
    --primary-800: #1e40af;
    --primary-900: #1e3a8a;
}
```

#### 7.1.2 Semantic Colors

```css
:root {
    /* Success (Green) */
    --success-500: #10b981;
    --success-600: #059669;

    /* Warning (Orange) */
    --warning-500: #f59e0b;
    --warning-600: #d97706;

    /* Error (Red) */
    --error-500: #ef4444;
    --error-600: #dc2626;

    /* Info (Blue) */
    --info-500: #3b82f6;
    --info-600: #2563eb;
}
```

#### 7.1.3 Neutral Colors

```css
:root {
    /* Gray Scale */
    --gray-50: #f9fafb;
    --gray-100: #f3f4f6;
    --gray-200: #e5e7eb;
    --gray-300: #d1d5db;
    --gray-400: #9ca3af;
    --gray-500: #6b7280;
    --gray-600: #4b5563;
    --gray-700: #374151;
    --gray-800: #1f2937;
    --gray-900: #111827;

    /* Background */
    --bg-primary: #ffffff;
    --bg-secondary: #f9fafb;
    --bg-tertiary: #f3f4f6;

    /* Text */
    --text-primary: #111827;
    --text-secondary: #6b7280;
    --text-tertiary: #9ca3af;
}
```

#### 7.1.4 Chart Colors

```css
:root {
    /* Funnel 그라데이션 */
    --funnel-1: #3b82f6;  /* Visit */
    --funnel-2: rgba(59, 130, 246, 0.85);  /* Engage */
    --funnel-3: rgba(59, 130, 246, 0.70);  /* Cart */
    --funnel-4: rgba(59, 130, 246, 0.55);  /* Checkout */
    --funnel-5: rgba(59, 130, 246, 0.40);  /* Purchase */

    /* 채널 색상 */
    --channel-organic: #10b981;
    --channel-paid: #f59e0b;
    --channel-social: #8b5cf6;
    --channel-direct: #6b7280;
    --channel-referral: #3b82f6;
    --channel-email: #ef4444;

    /* 기기 색상 */
    --device-desktop: #3b82f6;
    --device-mobile: #10b981;
    --device-app: #f59e0b;
}
```

### 7.2 타이포그래피

#### 7.2.1 폰트 패밀리

```css
:root {
    --font-sans: -apple-system, BlinkMacSystemFont, 'Segoe UI',
                 Roboto, Oxygen, Ubuntu, Cantarell,
                 'Helvetica Neue', sans-serif;

    --font-mono: 'SF Mono', Monaco, 'Cascadia Code',
                 'Roboto Mono', Consolas, 'Courier New', monospace;
}

body {
    font-family: var(--font-sans);
}

code, pre {
    font-family: var(--font-mono);
}
```

#### 7.2.2 폰트 스케일

```css
:root {
    --text-xs: 12px;    /* 캡션, 보조 정보 */
    --text-sm: 14px;    /* 본문, 테이블 */
    --text-base: 16px;  /* 기본 */
    --text-lg: 18px;    /* 섹션 제목 */
    --text-xl: 20px;    /* 모달 제목 */
    --text-2xl: 24px;   /* 페이지 제목 */
    --text-3xl: 32px;   /* 통계 값 */
    --text-4xl: 48px;   /* 히어로 텍스트 (미사용) */
}
```

#### 7.2.3 폰트 굵기

```css
:root {
    --font-normal: 400;
    --font-medium: 500;
    --font-semibold: 600;
    --font-bold: 700;
}
```

#### 7.2.4 줄 높이

```css
:root {
    --leading-tight: 1.25;   /* 제목 */
    --leading-normal: 1.5;   /* 본문 */
    --leading-relaxed: 1.75; /* 긴 텍스트 */
}
```

### 7.3 간격 (Spacing)

```css
:root {
    --space-0: 0;
    --space-1: 4px;
    --space-2: 8px;
    --space-3: 12px;
    --space-4: 16px;
    --space-5: 20px;
    --space-6: 24px;
    --space-8: 32px;
    --space-10: 40px;
    --space-12: 48px;
    --space-16: 64px;
}
```

### 7.4 그림자 (Shadows)

```css
:root {
    /* Elevation */
    --shadow-xs: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
    --shadow-sm: 0 1px 3px 0 rgba(0, 0, 0, 0.1);
    --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
    --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1);

    /* Inner Shadow */
    --shadow-inner: inset 0 2px 4px 0 rgba(0, 0, 0, 0.06);
}

/* 사용 예시 */
.card {
    box-shadow: var(--shadow-sm);
}

.modal {
    box-shadow: var(--shadow-xl);
}
```

### 7.5 경계선 (Borders)

```css
:root {
    /* Border Width */
    --border-0: 0;
    --border-1: 1px;
    --border-2: 2px;
    --border-4: 4px;

    /* Border Radius */
    --radius-sm: 4px;
    --radius-md: 8px;
    --radius-lg: 12px;
    --radius-xl: 16px;
    --radius-full: 9999px;

    /* Border Color */
    --border-light: #f3f4f6;
    --border-default: #e5e7eb;
    --border-strong: #d1d5db;
}
```

### 7.6 애니메이션

```css
:root {
    /* Duration */
    --duration-fast: 150ms;
    --duration-normal: 300ms;
    --duration-slow: 500ms;

    /* Easing */
    --ease-in: cubic-bezier(0.4, 0, 1, 1);
    --ease-out: cubic-bezier(0, 0, 0.2, 1);
    --ease-in-out: cubic-bezier(0.4, 0, 0.2, 1);
}

/* 사용 예시 */
.button {
    transition: all var(--duration-normal) var(--ease-out);
}

.modal {
    animation: fade-in var(--duration-normal) var(--ease-out);
}

@keyframes fade-in {
    from {
        opacity: 0;
        transform: scale(0.95);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
}
```

---

## 8. 접근성

### 8.1 키보드 네비게이션

#### 8.1.1 포커스 순서

1. 헤더 → CSV 업로드 버튼
2. 통계 카드 (왼쪽 → 오른쪽)
3. 전환 퍼널 섹션
4. 채널별 분석 섹션
5. 기기별 분석 섹션
6. 기타 섹션들
7. 푸터

#### 8.1.2 포커스 스타일

```css
*:focus {
    outline: 2px solid #3b82f6;
    outline-offset: 2px;
}

*:focus:not(:focus-visible) {
    outline: none;
}

*:focus-visible {
    outline: 2px solid #3b82f6;
    outline-offset: 2px;
}
```

#### 8.1.3 키보드 단축키

| 키 | 동작 |
|----|------|
| Tab | 다음 요소로 이동 |
| Shift + Tab | 이전 요소로 이동 |
| Enter | 버튼 클릭 / 링크 이동 |
| Space | 버튼 클릭 / 체크박스 토글 |
| Escape | 모달 닫기 |
| Arrow Keys | 테이블 셀 이동 (Phase 2) |

### 8.2 시맨틱 HTML

```html
<!-- 올바른 구조 -->
<header>
    <h1>전환 퍼널 분석 대시보드</h1>
    <nav>...</nav>
</header>

<main>
    <section aria-labelledby="funnel-title">
        <h2 id="funnel-title">전환 퍼널</h2>
        <!-- 차트 -->
    </section>

    <section aria-labelledby="channel-title">
        <h2 id="channel-title">유입 채널별 분석</h2>
        <!-- 차트 -->
    </section>
</main>

<footer>
    <!-- 푸터 내용 -->
</footer>
```

### 8.3 ARIA 속성

#### 8.3.1 버튼

```html
<button
    type="button"
    aria-label="CSV 파일 업로드"
    aria-describedby="upload-help">
    CSV 업로드
</button>
<span id="upload-help" class="sr-only">
    CSV 파일을 선택하여 데이터를 업로드합니다
</span>
```

#### 8.3.2 모달

```html
<div
    role="dialog"
    aria-modal="true"
    aria-labelledby="modal-title"
    aria-describedby="modal-description">
    <h2 id="modal-title">CSV 파일 업로드</h2>
    <p id="modal-description">CSV 파일을 선택하거나 드래그하여 업로드하세요</p>
    <!-- 모달 내용 -->
</div>
```

#### 8.3.3 로딩 상태

```html
<div
    role="status"
    aria-live="polite"
    aria-busy="true">
    <span class="spinner" aria-hidden="true"></span>
    <span>데이터 로딩 중...</span>
</div>
```

### 8.4 색상 대비

**WCAG 2.1 AA 기준**:
- 일반 텍스트: 최소 4.5:1
- 큰 텍스트 (18px 이상): 최소 3:1

**검증된 색상 조합**:
| 배경 | 텍스트 | 대비율 |
|------|--------|--------|
| #ffffff | #111827 | 16.1:1 ✓ |
| #3b82f6 | #ffffff | 4.5:1 ✓ |
| #f3f4f6 | #374151 | 8.9:1 ✓ |

### 8.5 스크린 리더

#### 8.5.1 숨김 텍스트

```css
.sr-only {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
    border-width: 0;
}
```

#### 8.5.2 차트 대체 텍스트

```html
<div class="chart-container">
    <canvas id="funnelChart" aria-label="전환 퍼널 차트"></canvas>
    <div class="sr-only">
        Visit 10,000명 (100%),
        Engage 5,498명 (54.98%),
        Cart 2,000명 (20%),
        Checkout 1,050명 (10.5%),
        Purchase 823명 (8.23%)
    </div>
</div>
```

---

## 9. 부록

### 9.1 아이콘 가이드

#### 9.1.1 아이콘 라이브러리

**사용 라이브러리**: Unicode Emoji 또는 SVG Icons

**주요 아이콘**:
| 용도 | 아이콘 | Unicode |
|------|--------|---------|
| 사용자/세션 | 👥 | U+1F465 |
| 차트/통계 | 📊 | U+1F4CA |
| 돈/매출 | 💰 | U+1F4B0 |
| 장바구니 | 🛒 | U+1F6D2 |
| 업로드 | 📁 | U+1F4C1 |
| 성공 | ✅ | U+2705 |
| 에러 | ❌ | U+274C |
| 경고 | ⚠️ | U+26A0 |
| 정보 | ℹ️ | U+2139 |
| 로딩 | ⏳ | U+23F3 |
| 새로고침 | 🔄 | U+1F504 |
| 설정 | ⚙️ | U+2699 |
| 닫기 | ✕ | U+2715 |

#### 9.1.2 SVG 아이콘 (Phase 2)

**추천 라이브러리**:
- Heroicons
- Feather Icons
- Font Awesome (Free)

### 9.2 이미지 가이드

#### 9.2.1 파일 형식

| 용도 | 형식 | 권장 크기 |
|------|------|----------|
| 로고 | SVG | - |
| 아이콘 | SVG | 24×24, 32×32 |
| 일러스트 | SVG or PNG | - |
| 사진 | WebP or JPG | 최대 1920px |

#### 9.2.2 최적화

- **압축**: TinyPNG, ImageOptim
- **Lazy Loading**: loading="lazy" 속성 사용
- **Responsive Images**: srcset 사용

```html
<img
    src="logo.svg"
    alt="Funnel Analytics Logo"
    width="120"
    height="40"
    loading="lazy">
```

### 9.3 에러 메시지 가이드

#### 9.3.1 메시지 작성 원칙

1. **명확성**: 무엇이 잘못되었는지 명확히 설명
2. **해결 방법**: 사용자가 취할 수 있는 조치 안내
3. **친절함**: 비난하지 않고 도움을 제공
4. **간결함**: 필요한 정보만 포함

#### 9.3.2 예시

**❌ 나쁜 예시**:
```
Error: 500
파일 업로드 실패
```

**✅ 좋은 예시**:
```
CSV 파일 업로드에 실패했습니다

필수 컬럼 'session_id'가 누락되었습니다.
CSV 파일에 다음 컬럼이 포함되어 있는지 확인해주세요:
- session_id
- user_id
- session_start_time

[다시 시도]
```

### 9.4 로딩 상태 메시지

| 상태 | 메시지 |
|------|--------|
| 대시보드 로딩 | "데이터를 불러오는 중..." |
| CSV 업로드 | "파일을 업로드하는 중... (N / M 건)" |
| 차트 렌더링 | "차트를 그리는 중..." |
| 데이터 새로고침 | "최신 데이터로 업데이트 중..." |

### 9.5 빈 상태 (Empty State)

#### 9.5.1 데이터 없음

```
┌─────────────────────────────────┐
│                                  │
│          📊                      │
│                                  │
│     데이터가 없습니다             │
│                                  │
│  CSV 파일을 업로드하여           │
│  데이터를 추가해주세요           │
│                                  │
│      [CSV 업로드]                │
│                                  │
└─────────────────────────────────┘
```

#### 9.5.2 검색 결과 없음

```
┌─────────────────────────────────┐
│          🔍                      │
│                                  │
│  "검색어"에 대한                 │
│  검색 결과가 없습니다            │
│                                  │
│  다른 검색어로 시도해보세요      │
└─────────────────────────────────┘
```

### 9.6 성능 최적화 체크리스트

**화면 설계 관점**:
- [ ] 차트는 필요한 경우에만 렌더링
- [ ] 큰 테이블은 페이지네이션 또는 가상 스크롤 사용
- [ ] 이미지는 lazy loading 적용
- [ ] CSS 애니메이션은 transform, opacity만 사용
- [ ] 불필요한 재렌더링 방지

### 9.7 변경 이력

| 버전 | 날짜 | 작성자 | 변경 내용 |
|------|------|--------|----------|
| 1.0 | 2025-10-30 | Design Team | 초기 화면 설계서 작성 |

### 9.8 승인

| 역할 | 이름 | 서명 | 날짜 |
|------|------|------|------|
| Design Lead | [이름] | | |
| Product Manager | [이름] | | |
| Engineering Lead | [이름] | | |
| UX Researcher | [이름] | | |

---

**문서 끝**
