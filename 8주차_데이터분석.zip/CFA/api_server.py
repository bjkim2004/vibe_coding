#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
전환 퍼널 분석 API 서버
FastAPI를 사용한 백엔드 서버
"""

from fastapi import FastAPI, HTTPException, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
import psycopg2
from psycopg2.extras import RealDictCursor, execute_batch
import pandas as pd
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
import os
import io
from dotenv import load_dotenv
from pathlib import Path

# 환경 변수 로드
env_path = Path(__file__).parent.parent / '.env'
load_dotenv(dotenv_path=env_path)

app = FastAPI(
    title="전환 퍼널 분석 API",
    description="전환 퍼널 데이터를 분석하는 REST API",
    version="1.0.0"
)

# CORS 설정
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# DB 연결 정보 (.env 파일에서 로드)
DB_CONFIG = {
    'host': os.getenv('DB_HOST', 'localhost'),
    'port': int(os.getenv('DB_PORT', 5432)),
    'database': os.getenv('DB_NAME', 'postgres'),
    'user': os.getenv('DB_USER', 'postgres'),
    'password': os.getenv('DB_PASSWORD', '')
}

def get_db_connection():
    """데이터베이스 연결"""
    try:
        conn = psycopg2.connect(**DB_CONFIG, cursor_factory=RealDictCursor)
        return conn
    except Exception as e:
        print(f"DB 연결 실패: {str(e)}")
        raise HTTPException(status_code=500, detail=f"DB 연결 실패: {str(e)}")

def execute_query(query: str, params: tuple = None) -> List[Dict]:
    """쿼리 실행 및 결과 반환"""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute(query, params)
        results = cursor.fetchall()
        return [dict(row) for row in results]
    except Exception as e:
        print(f"쿼리 실행 실패: {str(e)}")
        print(f"Query: {query}")
        raise HTTPException(status_code=500, detail=f"쿼리 실행 실패: {str(e)}")
    finally:
        cursor.close()
        conn.close()

@app.get("/")
async def root():
    """API 루트"""
    return {
        "message": "전환 퍼널 분석 API",
        "version": "1.0.0",
        "endpoints": {
            "overview": "/api/overview",
            "funnel": "/api/funnel",
            "channels": "/api/channels",
            "devices": "/api/devices",
            "regions": "/api/regions",
            "categories": "/api/categories",
            "ab_test": "/api/ab-test",
            "trends": "/api/trends"
        }
    }

@app.get("/api/overview")
async def get_overview():
    """전체 개요 통계"""
    query = """
        SELECT
            COUNT(*) as total_sessions,
            COUNT(DISTINCT user_id) as total_users,
            SUM(CASE WHEN purchase_complete = true THEN 1 ELSE 0 END) as total_purchases,
            SUM(revenue) as total_revenue,
            ROUND(AVG(CASE WHEN purchase_complete = true THEN revenue ELSE NULL END), 2) as avg_order_value,
            ROUND(100.0 * SUM(CASE WHEN purchase_complete = true THEN 1 ELSE 0 END) / COUNT(*), 2) as conversion_rate,
            MIN(session_start_time) as start_date,
            MAX(session_start_time) as end_date
        FROM funnel_data
    """

    result = execute_query(query)
    return result[0] if result else {}

@app.get("/api/funnel")
async def get_funnel_data():
    """퍼널 단계별 데이터"""
    query = """
        SELECT
            COUNT(*) as visit,
            SUM(CASE WHEN product_view = true THEN 1 ELSE 0 END) as engage,
            SUM(CASE WHEN cart_add = true THEN 1 ELSE 0 END) as cart,
            SUM(CASE WHEN checkout_start = true THEN 1 ELSE 0 END) as checkout,
            SUM(CASE WHEN purchase_complete = true THEN 1 ELSE 0 END) as purchase
        FROM funnel_data
    """

    result = execute_query(query)[0]

    # 전환율 계산
    total = result['visit']
    funnel_stages = [
        {
            'stage': '1. Visit',
            'count': result['visit'],
            'conversion_rate': 100.0,
            'drop_rate': 0.0
        },
        {
            'stage': '2. Engage',
            'count': result['engage'],
            'conversion_rate': round(100.0 * result['engage'] / total, 2),
            'step_conversion_rate': round(100.0 * result['engage'] / result['visit'], 2),
            'drop_rate': round(100.0 * (result['visit'] - result['engage']) / result['visit'], 2)
        },
        {
            'stage': '3. Cart',
            'count': result['cart'],
            'conversion_rate': round(100.0 * result['cart'] / total, 2),
            'step_conversion_rate': round(100.0 * result['cart'] / result['engage'], 2) if result['engage'] > 0 else 0,
            'drop_rate': round(100.0 * (result['engage'] - result['cart']) / result['engage'], 2) if result['engage'] > 0 else 0
        },
        {
            'stage': '4. Checkout',
            'count': result['checkout'],
            'conversion_rate': round(100.0 * result['checkout'] / total, 2),
            'step_conversion_rate': round(100.0 * result['checkout'] / result['cart'], 2) if result['cart'] > 0 else 0,
            'drop_rate': round(100.0 * (result['cart'] - result['checkout']) / result['cart'], 2) if result['cart'] > 0 else 0
        },
        {
            'stage': '5. Purchase',
            'count': result['purchase'],
            'conversion_rate': round(100.0 * result['purchase'] / total, 2),
            'step_conversion_rate': round(100.0 * result['purchase'] / result['checkout'], 2) if result['checkout'] > 0 else 0,
            'drop_rate': round(100.0 * (result['checkout'] - result['purchase']) / result['checkout'], 2) if result['checkout'] > 0 else 0
        }
    ]

    return {
        'stages': funnel_stages,
        'overall_conversion_rate': round(100.0 * result['purchase'] / total, 2)
    }

@app.get("/api/channels")
async def get_channel_analysis():
    """유입 채널별 분석"""
    query = """
        SELECT
            traffic_channel,
            COUNT(*) as sessions,
            SUM(CASE WHEN product_view = true THEN 1 ELSE 0 END) as product_views,
            SUM(CASE WHEN cart_add = true THEN 1 ELSE 0 END) as cart_adds,
            SUM(CASE WHEN checkout_start = true THEN 1 ELSE 0 END) as checkouts,
            SUM(CASE WHEN purchase_complete = true THEN 1 ELSE 0 END) as purchases,
            SUM(revenue) as total_revenue,
            ROUND(100.0 * SUM(CASE WHEN purchase_complete = true THEN 1 ELSE 0 END) / COUNT(*), 2) as conversion_rate,
            ROUND(AVG(CASE WHEN purchase_complete = true THEN revenue ELSE NULL END), 2) as avg_revenue
        FROM funnel_data
        GROUP BY traffic_channel
        ORDER BY conversion_rate DESC
    """

    return execute_query(query)

@app.get("/api/devices")
async def get_device_analysis():
    """기기별 분석"""
    query = """
        SELECT
            device_type,
            COUNT(*) as sessions,
            SUM(CASE WHEN product_view = true THEN 1 ELSE 0 END) as product_views,
            SUM(CASE WHEN cart_add = true THEN 1 ELSE 0 END) as cart_adds,
            SUM(CASE WHEN checkout_start = true THEN 1 ELSE 0 END) as checkouts,
            SUM(CASE WHEN purchase_complete = true THEN 1 ELSE 0 END) as purchases,
            SUM(revenue) as total_revenue,
            ROUND(100.0 * SUM(CASE WHEN purchase_complete = true THEN 1 ELSE 0 END) / COUNT(*), 2) as conversion_rate,
            ROUND(AVG(CASE WHEN purchase_complete = true THEN revenue ELSE NULL END), 2) as avg_revenue
        FROM funnel_data
        GROUP BY device_type
        ORDER BY conversion_rate DESC
    """

    return execute_query(query)

@app.get("/api/regions")
async def get_region_analysis():
    """지역별 분석"""
    query = """
        SELECT
            region,
            COUNT(*) as sessions,
            SUM(CASE WHEN product_view = true THEN 1 ELSE 0 END) as product_views,
            SUM(CASE WHEN cart_add = true THEN 1 ELSE 0 END) as cart_adds,
            SUM(CASE WHEN checkout_start = true THEN 1 ELSE 0 END) as checkouts,
            SUM(CASE WHEN purchase_complete = true THEN 1 ELSE 0 END) as purchases,
            SUM(revenue) as total_revenue,
            ROUND(100.0 * SUM(CASE WHEN purchase_complete = true THEN 1 ELSE 0 END) / COUNT(*), 2) as conversion_rate,
            ROUND(AVG(CASE WHEN purchase_complete = true THEN revenue ELSE NULL END), 2) as avg_revenue
        FROM funnel_data
        GROUP BY region
        ORDER BY conversion_rate DESC
    """

    return execute_query(query)

@app.get("/api/categories")
async def get_category_analysis():
    """상품 카테고리별 분석"""
    query = """
        SELECT
            product_category,
            COUNT(*) as sessions,
            SUM(CASE WHEN product_view = true THEN 1 ELSE 0 END) as product_views,
            SUM(CASE WHEN cart_add = true THEN 1 ELSE 0 END) as cart_adds,
            SUM(CASE WHEN checkout_start = true THEN 1 ELSE 0 END) as checkouts,
            SUM(CASE WHEN purchase_complete = true THEN 1 ELSE 0 END) as purchases,
            SUM(revenue) as total_revenue,
            ROUND(100.0 * SUM(CASE WHEN purchase_complete = true THEN 1 ELSE 0 END) / COUNT(*), 2) as conversion_rate,
            ROUND(AVG(CASE WHEN purchase_complete = true THEN revenue ELSE NULL END), 2) as avg_revenue
        FROM funnel_data
        GROUP BY product_category
        ORDER BY conversion_rate DESC
    """

    return execute_query(query)

@app.get("/api/ab-test")
async def get_ab_test_analysis():
    """A/B 테스트 분석"""
    query = """
        SELECT
            ab_test_version,
            COUNT(*) as sessions,
            SUM(CASE WHEN product_view = true THEN 1 ELSE 0 END) as product_views,
            SUM(CASE WHEN cart_add = true THEN 1 ELSE 0 END) as cart_adds,
            SUM(CASE WHEN checkout_start = true THEN 1 ELSE 0 END) as checkouts,
            SUM(CASE WHEN purchase_complete = true THEN 1 ELSE 0 END) as purchases,
            SUM(revenue) as total_revenue,
            ROUND(100.0 * SUM(CASE WHEN purchase_complete = true THEN 1 ELSE 0 END) / COUNT(*), 2) as conversion_rate,
            ROUND(100.0 * SUM(CASE WHEN product_view = true THEN 1 ELSE 0 END) / COUNT(*), 2) as engagement_rate,
            ROUND(100.0 * SUM(CASE WHEN cart_add = true THEN 1 ELSE 0 END) / COUNT(*), 2) as cart_rate,
            ROUND(AVG(page_loading_time_ms), 2) as avg_loading_time,
            ROUND(AVG(funnel_duration_sec), 2) as avg_duration
        FROM funnel_data
        GROUP BY ab_test_version
        ORDER BY ab_test_version
    """

    return execute_query(query)

@app.get("/api/user-types")
async def get_user_type_analysis():
    """신규/재방문 사용자 분석"""
    query = """
        SELECT
            CASE WHEN is_new_user = true THEN 'New' ELSE 'Returning' END as user_type,
            COUNT(*) as sessions,
            SUM(CASE WHEN product_view = true THEN 1 ELSE 0 END) as product_views,
            SUM(CASE WHEN cart_add = true THEN 1 ELSE 0 END) as cart_adds,
            SUM(CASE WHEN checkout_start = true THEN 1 ELSE 0 END) as checkouts,
            SUM(CASE WHEN purchase_complete = true THEN 1 ELSE 0 END) as purchases,
            SUM(revenue) as total_revenue,
            ROUND(100.0 * SUM(CASE WHEN purchase_complete = true THEN 1 ELSE 0 END) / COUNT(*), 2) as conversion_rate,
            ROUND(AVG(CASE WHEN purchase_complete = true THEN revenue ELSE NULL END), 2) as avg_revenue
        FROM funnel_data
        GROUP BY is_new_user
        ORDER BY user_type DESC
    """

    return execute_query(query)

@app.get("/api/drop-stages")
async def get_drop_stage_analysis():
    """이탈 단계 분석"""
    query = """
        SELECT
            drop_stage,
            COUNT(*) as count,
            ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM funnel_data), 2) as percentage
        FROM funnel_data
        WHERE drop_stage IS NOT NULL AND drop_stage != ''
        GROUP BY drop_stage
        ORDER BY count DESC
    """

    return execute_query(query)

@app.get("/api/loading-time-impact")
async def get_loading_time_impact():
    """페이지 로딩 시간의 전환율 영향"""
    query = """
        SELECT
            loading_time_range,
            sessions,
            purchases,
            conversion_rate
        FROM (
            SELECT
                CASE
                    WHEN page_loading_time_ms < 1000 THEN '<1s'
                    WHEN page_loading_time_ms < 1500 THEN '1-1.5s'
                    WHEN page_loading_time_ms < 2000 THEN '1.5-2s'
                    ELSE '>2s'
                END as loading_time_range,
                COUNT(*) as sessions,
                SUM(CASE WHEN purchase_complete = true THEN 1 ELSE 0 END) as purchases,
                ROUND(100.0 * SUM(CASE WHEN purchase_complete = true THEN 1 ELSE 0 END) / COUNT(*), 2) as conversion_rate,
                MIN(page_loading_time_ms) as min_time
            FROM funnel_data
            WHERE page_loading_time_ms IS NOT NULL
            GROUP BY
                CASE
                    WHEN page_loading_time_ms < 1000 THEN '<1s'
                    WHEN page_loading_time_ms < 1500 THEN '1-1.5s'
                    WHEN page_loading_time_ms < 2000 THEN '1.5-2s'
                    ELSE '>2s'
                END
        ) sub
        ORDER BY min_time
    """

    return execute_query(query)

@app.get("/api/trends")
async def get_trends(days: int = 30):
    """일별 트렌드 분석"""
    query = """
        SELECT
            DATE(session_start_time) as date,
            COUNT(*) as sessions,
            SUM(CASE WHEN purchase_complete = true THEN 1 ELSE 0 END) as purchases,
            SUM(revenue) as revenue,
            ROUND(100.0 * SUM(CASE WHEN purchase_complete = true THEN 1 ELSE 0 END) / COUNT(*), 2) as conversion_rate
        FROM funnel_data
        WHERE session_start_time >= NOW() - INTERVAL '%s days'
        GROUP BY DATE(session_start_time)
        ORDER BY date DESC
        LIMIT %s
    """

    return execute_query(query, (days, days))

def clean_value(value):
    """데이터 정제"""
    if pd.isna(value) or value == '' or value == 'nan':
        return None
    if isinstance(value, str) and value.lower() == 'true':
        return True
    if isinstance(value, str) and value.lower() == 'false':
        return False
    return value

@app.post("/api/upload")
async def upload_csv(file: UploadFile = File(...)):
    """CSV 파일 업로드 및 DB에 저장"""
    try:
        # 파일 내용 읽기
        contents = await file.read()
        df = pd.read_csv(io.BytesIO(contents))

        # Log upload (suppress Korean characters for Windows console)
        try:
            print(f"[INFO] CSV file uploaded, records: {len(df):,}")
        except:
            pass

        # 컬럼명 매핑 (한글 -> 영문)
        column_mapping = {
            '세션ID': 'session_id',
            '사용자ID': 'user_id',
            '세션시작시간': 'session_start_time',
            '지역': 'region',
            '기기유형': 'device_type',
            '운영체제': 'os',
            '유입채널': 'traffic_channel',
            'UTM소스': 'utm_source',
            'UTM매체': 'utm_medium',
            '랜딩페이지': 'landing_page',
            'AB테스트버전': 'ab_test_version',
            '페이지로딩시간(ms)': 'page_loading_time_ms',
            '신규사용자여부': 'is_new_user',
            '상품카테고리': 'product_category',
            '상품조회': 'product_view',
            '장바구니추가': 'cart_add',
            '결제시작': 'checkout_start',
            '구매완료': 'purchase_complete',
            '이탈단계': 'drop_stage',
            '장바구니상품수': 'cart_item_count',
            '장바구니금액': 'cart_amount',
            '할인율': 'discount_rate',
            '쿠폰사용여부': 'coupon_used',
            '배송옵션': 'shipping_option',
            '결제수단': 'payment_method',
            '첫행동까지시간(초)': 'time_to_first_action_sec',
            '퍼널체류시간(초)': 'funnel_duration_sec',
            '조회시간': 'view_time',
            '장바구니시간': 'cart_time',
            '결제시작시간': 'checkout_start_time',
            '구매시간': 'purchase_time',
            '매출액': 'revenue'
        }

        # 컬럼명이 한글인 경우에만 변환
        existing_columns = df.columns.tolist()
        if any(col in column_mapping for col in existing_columns):
            df = df.rename(columns=column_mapping)

        # DB 연결
        conn = psycopg2.connect(**DB_CONFIG)
        cursor = conn.cursor()

        # 기존 데이터 삭제
        try:
            print("[INFO] Deleting existing data...")
        except:
            pass
        cursor.execute("DELETE FROM funnel_data")
        conn.commit()
        try:
            print("[OK] Existing data deleted")
        except:
            pass

        # INSERT 쿼리 준비
        insert_query = """
            INSERT INTO funnel_data (
                session_id, user_id, session_start_time, region, device_type, os,
                traffic_channel, utm_source, utm_medium, landing_page, ab_test_version,
                page_loading_time_ms, is_new_user, product_category, product_view,
                cart_add, checkout_start, purchase_complete, drop_stage,
                cart_item_count, cart_amount, discount_rate, coupon_used,
                shipping_option, payment_method, time_to_first_action_sec,
                funnel_duration_sec, view_time, cart_time, checkout_start_time,
                purchase_time, revenue
            ) VALUES (
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
            )
        """

        # 배치 데이터 준비
        try:
            print("[INFO] Uploading data...")
        except:
            pass
        batch_size = 1000
        records = []

        for idx, row in df.iterrows():
            record = (
                clean_value(row.get('session_id')),
                clean_value(row.get('user_id')),
                clean_value(row.get('session_start_time')),
                clean_value(row.get('region')),
                clean_value(row.get('device_type')),
                clean_value(row.get('os')),
                clean_value(row.get('traffic_channel')),
                clean_value(row.get('utm_source')),
                clean_value(row.get('utm_medium')),
                clean_value(row.get('landing_page')),
                clean_value(row.get('ab_test_version')),
                clean_value(row.get('page_loading_time_ms')),
                clean_value(row.get('is_new_user')),
                clean_value(row.get('product_category')),
                clean_value(row.get('product_view')),
                clean_value(row.get('cart_add')),
                clean_value(row.get('checkout_start')),
                clean_value(row.get('purchase_complete')),
                clean_value(row.get('drop_stage')),
                clean_value(row.get('cart_item_count')),
                clean_value(row.get('cart_amount')),
                clean_value(row.get('discount_rate')),
                clean_value(row.get('coupon_used')),
                clean_value(row.get('shipping_option')),
                clean_value(row.get('payment_method')),
                clean_value(row.get('time_to_first_action_sec')),
                clean_value(row.get('funnel_duration_sec')),
                clean_value(row.get('view_time')),
                clean_value(row.get('cart_time')),
                clean_value(row.get('checkout_start_time')),
                clean_value(row.get('purchase_time')),
                clean_value(row.get('revenue'))
            )
            records.append(record)

            # 배치 업로드
            if len(records) >= batch_size:
                execute_batch(cursor, insert_query, records)
                conn.commit()
                try:
                    print(f"  [OK] {idx + 1:,} / {len(df):,} records uploaded")
                except:
                    pass
                records = []

        # 남은 레코드 업로드
        if records:
            execute_batch(cursor, insert_query, records)
            conn.commit()
            try:
                print(f"  [OK] {len(df):,} / {len(df):,} records uploaded")
            except:
                pass

        # 통계 조회
        cursor.execute("SELECT COUNT(*) FROM funnel_data")
        total_count = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM funnel_data WHERE purchase_complete = true")
        purchase_count = cursor.fetchone()[0]

        conversion_rate = (purchase_count / total_count * 100) if total_count > 0 else 0

        cursor.close()
        conn.close()

        try:
            print("[OK] CSV data upload complete!")
        except:
            pass

        return {
            "success": True,
            "message": "CSV file uploaded successfully.",
            "filename": file.filename,
            "total_records": total_count,
            "purchases": purchase_count,
            "conversion_rate": round(conversion_rate, 2)
        }

    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"File upload failed: {repr(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
