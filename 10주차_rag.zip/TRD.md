# Technical Requirements Document (TRD)
## Korail 법령검색 챗봇 시스템

**버전**: 2.0.0  
**작성일**: 2025-01-XX  
**프로젝트명**: Korail 사규 및 내규 AI 검색 서비스  
**최종 업데이트**: Gemini 2.0 Flash 모델 적용

---

## 1. 기술 스택 개요

### 1.1 아키텍처
```
┌─────────────────┐
│   Frontend      │ React 18 + Vite 5
│   (Port 3000)   │
└────────┬────────┘
         │ HTTP/REST API
┌────────▼────────┐
│   Backend       │ FastAPI 0.104 + Python 3.8+
│   (Port 8000)   │
└────────┬────────┘
         │
    ┌────┴────┐
    │         │
┌───▼───┐ ┌──▼──────┐
│ChromaDB│ │Gemini API│
│Vector  │ │(2.0 Flash)│
│Store   │ └─────────┘
└────────┘
```

### 1.2 기술 스택

#### Frontend
- **Framework**: React 18.2+
- **Build Tool**: Vite 5.0+
- **언어**: JavaScript (ES6+)
- **스타일링**: CSS3
- **HTTP Client**: Axios 1.6+

#### Backend
- **Framework**: FastAPI 0.104.1
- **언어**: Python 3.8+
- **비동기 처리**: asyncio, threading, BackgroundTasks
- **로깅**: Python logging (파일 + 콘솔)

#### AI/ML
- **임베딩 모델**: BM-K/KoSimCSE-roberta-multitask (Hugging Face)
- **LLM**: Google Gemini 2.0 Flash
- **벡터 스토어**: ChromaDB 0.4.22
- **RAG 프레임워크**: LangChain 0.1.0+

#### 문서 처리
- **PDF 로더**: UnstructuredFileLoader (unstructured[pdf] 0.11.6)
- **텍스트 분할**: 
  - MarkdownHeaderTextSplitter (조 단위 분할)
  - RecursiveCharacterTextSplitter (긴 조 추가 분할)
- **전처리**: 정규식 기반 패턴 매칭

---

## 2. 시스템 아키텍처

### 2.1 백엔드 구조

```
backend/
├── main.py                 # FastAPI 서버, API 엔드포인트
├── embeddings.py           # CustomHuggingFaceEmbeddings 클래스
├── document_processor.py   # PDF 로드, 전처리, 청킹
├── chroma_db/             # 벡터 DB 저장 디렉토리
├── rag_chatbot.log        # 로그 파일
└── show_chunks.py         # 청크 샘플 확인 스크립트
```

#### 주요 모듈

**main.py**
- FastAPI 애플리케이션
- API 엔드포인트 정의
- RAG 체인 생성 및 관리
- 전역 상태 관리 (vector_store, rag_chain, init_progress)
- 백그라운드 태스크 처리
- 로깅 설정

**embeddings.py**
- `CustomHuggingFaceEmbeddings` 클래스
- KoSimCSE-roberta-multitask 모델 로드
- Mean Pooling 적용
- 텍스트 → 벡터 변환

**document_processor.py**
- `DocumentProcessor` 클래스
- PDF 문서 로드
- 마크다운 전처리
- 구조 인식 청킹 (조 단위 + 글자수 제한)

### 2.2 프론트엔드 구조

```
frontend/
├── src/
│   ├── App.jsx                    # 메인 앱 컴포넌트
│   ├── App.css
│   ├── index.css                  # 전역 스타일
│   ├── main.jsx                   # 진입점
│   └── components/
│       ├── ChatInterface.jsx      # 채팅 인터페이스
│       ├── ChatInterface.css
│       ├── MessageList.jsx        # 메시지 목록
│       ├── MessageList.css
│       ├── MessageBubble.jsx      # 개별 메시지
│       ├── MessageBubble.css
│       ├── InputArea.jsx          # 입력 영역
│       ├── InputArea.css
│       ├── InitializePanel.jsx    # 초기화 패널
│       └── InitializePanel.css
├── index.html
├── vite.config.js
└── package.json
```

---

## 3. 데이터 흐름

### 3.1 초기화 프로세스

```
1. 사용자: PDF 디렉토리 지정 (기본값: "pdfs")
   ↓
2. Backend: POST /initialize 요청 수신
   ↓
3. Backend: 기존 DB 확인 (force=false인 경우)
   ├─ 존재 → 기존 DB 로드 및 skip_initialization 반환
   └─ 없음 → 초기화 진행
   ↓
4. Backend: PDF 파일 검색
   ↓
5. Backend: PDF → 텍스트 추출 (UnstructuredFileLoader)
   ↓
6. Backend: 텍스트 → 마크다운 전처리
   - 제N조 → # 제N조
   - 항목번호 → ## 1.
   - 한글항목 → ### (가)
   ↓
7. Backend: 조 단위로 청킹 (MarkdownHeaderTextSplitter)
   ↓
8. Backend: 긴 조는 글자수 제한으로 추가 분할 (RecursiveCharacterTextSplitter)
   - chunk_size: 1000자
   - chunk_overlap: 200자
   ↓
9. Backend: 임베딩 생성 (CustomHuggingFaceEmbeddings)
   - 배치 크기: 256
   ↓
10. Backend: 벡터 DB 저장 (ChromaDB)
    - collection: "regulations_collection"
    - persist_directory: "./chroma_db"
    ↓
11. Backend: RAG 체인 초기화
    ↓
12. Frontend: 완료 상태 표시
```

### 3.2 질의응답 프로세스

```
1. 사용자: 자연어 질문 입력
   ↓
2. Frontend: POST /chat 요청
   {
     question: "질문",
     similarity_threshold: 0.5,
     max_k: 5,
     temperature: 0.05
   }
   ↓
3. Backend: Dual Retriever 실행
   - 'raw' (법규) 문서 검색
   - 'regulation' (사규) 문서 검색
   - 유사도 필터링 (threshold 이하만)
   ↓
4. Backend: 검색된 문서 포맷팅
   - 문서 유형, 출처, 조항 정보 포함
   - 원문 전체 포함
   ↓
5. Backend: LLM 호출 (Gemini 2.0 Flash)
   - System Prompt + 참고 문서 + 질문
   - Temperature 설정 적용
   ↓
6. Backend: 로깅
   - 질문, 파라미터, 검색된 문서, 프롬프트, 응답
   ↓
7. Backend: 응답 및 소스 정보 반환
   {
     answer: "답변",
     sources: [
       {
         source: "파일명.pdf",
         article_title: "제1조(목적)",
         document_type: "regulation",
         similarity_score: 0.85
       }
     ]
   }
   ↓
8. Frontend: 답변 및 출처 표시
```

---

## 4. API 명세

### 4.1 엔드포인트 목록

#### GET `/`
- **설명**: API 상태 확인
- **응답**: `{"message": "Korail RAG Backend API", "status": "running"}`

#### GET `/health`
- **설명**: 서버 및 벡터 스토어 상태 확인
- **응답**:
```json
{
  "status": "healthy",
  "vector_store_initialized": true
}
```

#### POST `/initialize`
- **설명**: 벡터 스토어 초기화
- **요청 본문**:
```json
{
  "pdf_directory": "pdfs",
  "model_path": null,
  "force": false
}
```
- **응답**:
```json
{
  "message": "초기화가 시작되었습니다...",
  "status": "started",
  "skip_initialization": false
}
```
- **동작**: 백그라운드에서 초기화 진행

#### GET `/initialize/progress`
- **설명**: 초기화 진행 상황 조회
- **응답**:
```json
{
  "status": "processing",
  "current_step": "PDF 문서 로드 중",
  "progress": 45,
  "total": 10,
  "processed": 5,
  "message": "PDF 로드 중: 규정.pdf (5/10)"
}
```

#### POST `/chat`
- **설명**: 질문 처리 및 답변 생성
- **요청 본문**:
```json
{
  "question": "휴가 신청 절차는?",
  "similarity_threshold": 0.5,
  "max_k": 5,
  "temperature": 0.05
}
```
- **응답**:
```json
{
  "answer": "휴가 신청은 다음과 같이 진행됩니다...",
  "sources": [
    {
      "source": "규정.pdf",
      "article_title": "제3조(휴가)",
      "document_type": "regulation",
      "similarity_score": 0.87
    }
  ]
}
```

### 4.2 데이터 모델

#### ChatRequest
```python
class ChatRequest(BaseModel):
    question: str
    similarity_threshold: float = 0.5
    max_k: int = 5
    temperature: float = 0.05
```

#### ChatResponse
```python
class SourceInfo(BaseModel):
    source: str
    article_title: str
    document_type: str
    similarity_score: float

class ChatResponse(BaseModel):
    answer: str
    sources: List[SourceInfo]
```

#### InitializeRequest
```python
class InitializeRequest(BaseModel):
    pdf_directory: str = "pdfs"
    model_path: Optional[str] = None
    force: bool = False
```

#### ProgressResponse
```python
class ProgressResponse(BaseModel):
    status: str  # "idle", "processing", "completed", "error"
    current_step: Optional[str] = None
    progress: Optional[int] = None  # 0-100
    total: Optional[int] = None
    processed: Optional[int] = None
    message: Optional[str] = None
```

---

## 5. 데이터베이스 스키마

### 5.1 ChromaDB 컬렉션

**Collection Name**: `regulations_collection`

**Metadata Schema**:
```python
{
    "source": str,              # PDF 파일 경로
    "Document_Type": str,       # "raw" (법규) 또는 "regulation" (사규)
    "Article_Title": str,        # "제1조(목적)" (있는 경우)
    "Item_Numbering": str,       # "1." (있는 경우)
    "Hangeul_Item": str,         # "(가)" (있는 경우)
    "chunk_index": int,         # 같은 조 내 청크 인덱스 (긴 조 분할 시)
    "total_chunks": int,        # 같은 조 내 전체 청크 수 (긴 조 분할 시)
    "page": int                 # 페이지 번호 (있는 경우)
}
```

**Embedding**:
- 모델: BM-K/KoSimCSE-roberta-multitask
- 차원: 모델 출력 차원 (일반적으로 768)
- 거리 측정: Cosine Similarity

---

## 6. 청킹 전략

### 6.1 청킹 파이프라인

#### Step 1: 마크다운 전처리
```
원본: "제1조(목적) 이 규정은..."
     ↓
마크다운: "# 제1조(목적) 이 규정은..."
```

#### Step 2: 조 단위 분할
```
MarkdownHeaderTextSplitter
- 헤더: ("#", "Article_Title")
- strip_headers: False
```

**결과**: 각 조가 별도 청크

#### Step 3: 긴 조 추가 분할
```
조 내용 길이 > 1000자?
  ├─ Yes → RecursiveCharacterTextSplitter로 분할
  │         (chunk_size=1000, overlap=200)
  │         - chunk_index, total_chunks 메타데이터 추가
  └─ No → 그대로 유지
```

### 6.2 청킹 예시

**예시 1: 짧은 조**
```
원본: 제1조(목적)
      이 규정은... (200자)

→ 청크 1개
```

**예시 2: 긴 조**
```
원본: 제2조(정의)
      매우 긴 내용... (2500자)

→ 청크 3개로 분할
   - 청크 1: [0-1000자] (제2조 [1/3])
   - 청크 2: [800-1800자] (제2조 [2/3], 200자 overlap)
   - 청크 3: [1600-2500자] (제2조 [3/3], 200자 overlap)
```

### 6.3 정규식 패턴

```python
COMPILED_REGEX_PATTERNS = {
    "article_title": re.compile(
        r"(?:^|\n\s*)(제\s*\d+\s*조\s*(?:\([^\)]+\))?)(?:\s|\.|:|：|$)",
        re.MULTILINE
    ),
    # ... 기타 패턴
}
```

---

## 7. 검색 알고리즘

### 7.1 Dual Retriever

```python
def dual_retriever(query: str):
    MAX_DISTANCE = 1.0 - similarity_threshold
    initial_k = max_k * 2
    
    # 1. 법규 문서 검색
    raw_results = vector_store.similarity_search_with_score(
        query, 
        k=initial_k,
        filter={"Document_Type": "raw"}
    )
    
    # 2. 사규 문서 검색
    regulation_results = vector_store.similarity_search_with_score(
        query,
        k=initial_k,
        filter={"Document_Type": "regulation"}
    )
    
    # 3. 유사도 필터링 (threshold 이하만)
    filtered_raw = [doc for doc, score in raw_results 
                    if score <= MAX_DISTANCE][:max_k]
    filtered_regulation = [doc for doc, score in regulation_results 
                          if score <= MAX_DISTANCE][:max_k]
    
    # 4. 병합 반환
    return filtered_raw + filtered_regulation
```

### 7.2 유사도 계산

- **거리 측정**: Cosine Distance
- **임계값**: 기본 0.5 (설정 가능, 0.0 ~ 1.0)
- **최대 문서 수**: 기본 5개 (설정 가능, 1 ~ 20)

---

## 8. LLM 프롬프트

### 8.1 System Prompt
```
당신은 회사의 사규 및 내규에 정통한 전문 컨설턴트입니다.
제공된 '참고 문서'만을 활용하여 사용자의 질문에 정확하고 자세하게 답변해야 합니다.
임계값을 충족했으면 답변을 해야 합니다.
답변 끝에는 반드시 사용된 '참고 문서'의 [문서 유형: XX, 출처: 파일명, 조항: 제목]을 명확하게 제시해야 합니다.
표 형태로 추출된 내용은 표 형태로 깔끔하게 포맷팅하여 제공하세요.
```

### 8.2 Human Prompt Template
```
참고 문서:
{context}

질문: {question}
```

### 8.3 LLM 설정
- **모델**: Gemini 2.0 Flash
- **Temperature**: 기본 0.05 (설정 가능, 0.0 ~ 2.0)
- **Max Tokens**: 기본값 사용
- **API Key**: 환경 변수 `GOOGLE_API_KEY` 또는 코드 기본값

---

## 9. 로깅 및 모니터링

### 9.1 로깅 설정

**파일**: `backend/rag_chatbot.log`
- **인코딩**: UTF-8
- **레벨**: INFO
- **포맷**: `%(asctime)s - %(name)s - %(levelname)s - %(message)s`
- **핸들러**: 파일 + 콘솔

### 9.2 로그 항목

**초기화 로그**:
- 모델 다운로드
- 문서 로드
- 청킹 진행
- 벡터 DB 저장

**질의응답 로그**:
- 질문 내용
- 검색 파라미터 (temperature, threshold, max_k)
- 검색된 문서 목록 및 원문
- 전체 프롬프트
- LLM 응답

**로그 형식**:
```
================================================================================
[LLM 입력 프롬프트 - 2025-01-XX HH:MM:SS]
질문: ...
Temperature: 0.05
Similarity Threshold: 0.5
Max K: 5
검색된 문서 수: 3개
--------------------------------------------------------------------------------
검색된 문서 원문 목록:
  문서 1: [regulation] 파일명.pdf - 제1조(목적)
    원문 길이: 500 문자
    원문 미리보기: ...
--------------------------------------------------------------------------------
참고 문서 컨텍스트 전체 길이: 1500 문자
--------------------------------------------------------------------------------
전체 프롬프트:
...
================================================================================
```

---

## 10. 성능 최적화

### 10.1 배치 처리
- **임베딩 생성**: 배치 크기 256
- **벡터 DB 저장**: 배치 단위로 저장

### 10.2 캐싱
- **모델 캐싱**: Hugging Face 캐시 활용
- **벡터 DB**: 로컬 파일 시스템에 영구 저장
- **RAG 체인**: 전역 변수로 캐싱

### 10.3 비동기 처리
- **초기화**: 백그라운드 태스크로 실행
- **API**: FastAPI 비동기 처리
- **진행 상황**: 전역 딕셔너리로 상태 공유

### 10.4 모델 선택
- **LLM**: Gemini 2.0 Flash (빠른 응답 속도)
- **임베딩**: CPU 모드 (GPU 선택 가능)

---

## 11. 보안 요구사항

### 11.1 API 키 관리
- **환경 변수**: `.env` 파일 사용 (권장)
- **변수명**: `GOOGLE_API_KEY`
- **기본값**: 코드에 하드코딩 (개발용)
- **프로덕션**: 환경 변수로만 관리 권장

### 11.2 CORS 설정
- **개발 환경**: 모든 도메인 허용 (`allow_origins=["*"]`)
- **프로덕션**: 특정 도메인으로 제한 필요

### 11.3 데이터 보안
- **로컬 저장**: 벡터 DB는 로컬 파일 시스템
- **PDF 파일**: 사용자 관리
- **로그 파일**: 민감 정보 제외

---

## 12. 배포 요구사항

### 12.1 시스템 요구사항

**최소 사양**:
- CPU: 2코어 이상
- RAM: 4GB 이상
- 디스크: 2GB 이상 여유 공간
- OS: Windows 10 이상

**권장 사양**:
- CPU: 4코어 이상
- RAM: 8GB 이상
- 디스크: 5GB 이상 여유 공간

### 12.2 의존성

**Backend** (`requirements.txt`):
```
fastapi==0.104.1
uvicorn[standard]==0.24.0
pydantic>=2.5.0
python-dotenv==1.0.0
pypdf==3.17.0
langchain==0.1.0
langchain-community==0.0.10
langchain-google-genai>=3.1.0
unstructured[pdf]==0.11.6
chromadb==0.4.22
transformers==4.36.0
torch>=2.1.0
huggingface-hub==0.19.4
python-multipart==0.0.6
```

**Frontend** (`package.json`):
- React 18.2+
- Vite 5.0+
- Axios 1.6+

### 12.3 시작 스크립트

**start_all.bat**:
- 백엔드 서버 시작 (포트 8000)
- 프론트엔드 서버 시작 (포트 3000)
- 자동 의존성 설치 확인

---

## 13. 에러 처리

### 13.1 백엔드 에러

**HTTP 상태 코드**:
- `200`: 성공
- `404`: 리소스 없음 (PDF 디렉토리, 파일 등)
- `500`: 서버 오류
- `503`: 서비스 불가 (벡터 스토어 미초기화)

**에러 응답 형식**:
```json
{
  "detail": "에러 메시지"
}
```

### 13.2 프론트엔드 에러

**에러 표시**:
- 네트워크 오류: 사용자 친화적 메시지
- API 오류: 상세 오류 메시지 표시
- 초기화 오류: 재시도 안내

---

## 14. 테스트 전략

### 14.1 단위 테스트 (추후 구현)
- 문서 로드 함수
- 전처리 함수
- 청킹 함수
- 임베딩 생성 함수

### 14.2 통합 테스트 (추후 구현)
- API 엔드포인트
- RAG 체인 동작
- 벡터 DB CRUD

### 14.3 수동 테스트 체크리스트
- [ ] PDF 파일 로드 확인
- [ ] 초기화 진행 상황 표시 확인
- [ ] 질의응답 정확도 확인
- [ ] 출처 정보 표시 확인
- [ ] 재초기화 기능 확인
- [ ] Temperature 조정 확인
- [ ] 로깅 기능 확인

---

## 15. 확장 계획

### 15.1 Phase 2 기능
- 멀티턴 대화 지원
- 검색 히스토리 저장
- 사용자 인증
- 관리자 대시보드
- 문서 업데이트 감지

### 15.2 기술 개선
- 더 빠른 임베딩 모델
- 캐싱 레이어 추가
- 로드 밸런싱
- 컨테이너화 (Docker)
- GPU 가속 지원

---

## 16. 알려진 제약사항

### 16.1 기술적 제약
- PDF 파일은 단일 페이지 모드로 로드 (멀티 페이지는 통합)
- 임베딩 모델은 CPU에서 실행 (느릴 수 있음)
- 벡터 DB는 단일 서버 환경
- 현재 세션만 대화 기록 유지

### 16.2 기능 제약
- 멀티턴 대화 미지원 (각 질문은 독립적)
- 파일 업로드 미지원 (로컬 파일 시스템 사용)
- 검색 히스토리 저장 미지원

---

## 17. 참고 자료

### 17.1 기술 문서
- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [LangChain Documentation](https://python.langchain.com/)
- [ChromaDB Documentation](https://docs.trychroma.com/)
- [Google Gemini API](https://ai.google.dev/docs)

### 17.2 모델 정보
- **임베딩 모델**: [BM-K/KoSimCSE-roberta-multitask](https://huggingface.co/BM-K/KoSimCSE-roberta-multitask)
- **LLM**: Google Gemini 2.0 Flash

---

## 18. 부록

### 18.1 코드 주요 파일
- `backend/main.py`: FastAPI 서버 메인
- `backend/document_processor.py`: 문서 처리 로직
- `backend/embeddings.py`: 임베딩 모델 래퍼
- `frontend/src/App.jsx`: React 메인 컴포넌트

### 18.2 설정 파일
- `.env`: 환경 변수 (API 키 등)
- `requirements.txt`: Python 의존성
- `package.json`: Node.js 의존성
- `start_all.bat`: 시작 스크립트

### 18.3 주요 상수
- **청크 크기**: 1000자
- **청크 오버랩**: 200자
- **기본 Temperature**: 0.05
- **기본 유사도 임계값**: 0.5
- **기본 최대 문서 수**: 5개

---

## 19. 승인

**아키텍처 리뷰**: [이름]  
**기술 리더**: [이름]  
**개발 팀**: [이름]

**최종 승인일**: [날짜]
