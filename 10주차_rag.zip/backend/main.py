"""
RAG Backend Server for 법령검색 챗봇
FastAPI 기반 REST API 서버
"""
import os
import logging
from typing import List, Dict, Optional, Any
from datetime import datetime

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('rag_chatbot.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import asyncio
import threading

from langchain_core.documents import Document
from langchain_community.document_loaders import UnstructuredFileLoader
from langchain_text_splitters import MarkdownHeaderTextSplitter
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_community.vectorstores import Chroma
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough, RunnableLambda

from embeddings import CustomHuggingFaceEmbeddings
from document_processor import DocumentProcessor

# 환경 변수 로드
from dotenv import load_dotenv
load_dotenv()

app = FastAPI(title="Korail RAG Backend", version="1.0.0")

# CORS 설정
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 프로덕션에서는 특정 도메인으로 제한
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 전역 변수
vector_store: Optional[Chroma] = None
rag_chain = None
document_processor = DocumentProcessor()
# 초기화 진행 상황 추적
init_progress = {
    "status": "idle",  # idle, loading_model, loading_docs, processing, embedding, done
    "current_step": "",
    "progress": 0,
    "total": 0,
    "message": ""
}


def load_existing_vector_store():
    """서버 시작 시 기존 벡터 스토어가 있으면 로드합니다."""
    global vector_store, rag_chain
    
    try:
        # 임베딩 모델 경로 결정
        from huggingface_hub import snapshot_download
        MODEL_ID = "BM-K/KoSimCSE-roberta-multitask"
        try:
            model_path = snapshot_download(repo_id=MODEL_ID)
        except:
            return False
        
        # backend 디렉토리 기준으로 chroma_db 경로 설정
        current_dir = os.path.dirname(os.path.abspath(__file__))
        chroma_db_path = os.path.join(current_dir, "chroma_db")
        
        # 기존 ChromaDB 컬렉션 확인
        try:
            embeddings = CustomHuggingFaceEmbeddings(model_path=model_path, device='cpu')
            existing_store = Chroma(
                collection_name="regulations_collection",
                embedding_function=embeddings,
                collection_metadata={"hnsw:space": "cosine"},
                persist_directory=chroma_db_path
            )
            
            # 컬렉션에 문서가 있는지 확인
            collection = existing_store._collection
            count = collection.count()
            
            if count > 0:
                # 기존 벡터 스토어 사용
                vector_store = existing_store
                
                # RAG 체인 초기화
                api_key = os.getenv("GOOGLE_API_KEY", "AIzaSyCPeHe4VSXawGN9ocudEwy_T1XipTT2xSk")
                if api_key:
                    rag_chain = create_rag_chain(vector_store, api_key, 0.5, 5, 0.05)
                
                print(f"✅ 기존 벡터 DB를 로드했습니다. ({count}개의 청크)")
                return True
        except Exception as e:
            print(f"기존 벡터 DB 로드 실패: {e}")
            return False
    except Exception as e:
        print(f"벡터 DB 확인 중 오류: {e}")
        return False
    
    return False


@app.on_event("startup")
async def startup_event():
    """서버 시작 시 실행됩니다."""
    print("서버 시작 중... 기존 벡터 DB를 확인합니다.")
    load_existing_vector_store()


# Pydantic 모델
class ChatRequest(BaseModel):
    question: str
    similarity_threshold: float = 0.5
    max_k: int = 5
    temperature: float = 0.05


class SourceInfo(BaseModel):
    source: str
    article_title: str
    document_type: str
    similarity_score: float


class ChatResponse(BaseModel):
    answer: str
    sources: List[SourceInfo]


class InitializeRequest(BaseModel):
    pdf_directory: str = "pdfs"
    model_path: Optional[str] = None
    force: bool = False  # True이면 기존 벡터 DB를 무시하고 강제로 재초기화


class InitializeResponse(BaseModel):
    message: str
    num_documents: int
    num_chunks: int


class ProgressResponse(BaseModel):
    status: str
    current_step: str
    progress: int
    total: int
    message: str


def format_docs(docs: List[Document]) -> str:
    """검색된 문서 목록을 LLM 입력에 적합한 하나의 문자열로 포맷합니다.
    벡터 검색으로 찾은 원문 전체를 명확하게 포함시킵니다."""
    formatted_texts = []
    for i, doc in enumerate(docs):
        source_info = os.path.basename(doc.metadata.get("source", "알 수 없음"))
        article_title = doc.metadata.get("Article_Title", "조항 없음")
        doc_type = doc.metadata.get("Document_Type", "알 수 없음")
        page_number = doc.metadata.get("page", "알 수 없음")
        
        # 원문 전체를 명확하게 표시
        header_info = f"[문서 유형: {doc_type}, 출처: {source_info}, 조항: {article_title}, 페이지: {page_number}]"
        
        # 원문 내용 전체 포함 (벡터 검색으로 찾은 청크의 원문)
        original_text = doc.page_content
        
        formatted_texts.append(
            f"--- 문서 {i+1} ---\n"
            f"{header_info}\n"
            f"원문:\n{original_text}\n"
            f"--- 문서 {i+1} 끝 ---"
        )
    return "\n\n".join(formatted_texts)


def create_rag_chain(vector_store: Chroma, api_key: str, similarity_threshold: float, max_k: int, temperature: float = 0.05):
    """RAG 체인을 생성합니다."""
    # 환경 변수에서 temperature를 가져오거나 기본값 사용
    env_temperature = os.getenv("LLM_TEMPERATURE")
    if env_temperature:
        try:
            temperature = float(env_temperature)
        except:
            pass
    
    # temperature 범위 검증 (0.0 ~ 2.0)
    temperature = max(0.0, min(2.0, temperature))
    
    llm = ChatGoogleGenerativeAI(model="gemini-2.0-flash", google_api_key=api_key, temperature=temperature)

    def dual_retriever(query: str) -> List[Document]:
        MAX_DISTANCE = 1.0 - similarity_threshold
        initial_k = max_k * 2

        # 1. 'raw' (법규) 문서 검색
        raw_results_with_score = vector_store.similarity_search_with_score(
            query, k=initial_k, filter={"Document_Type": "raw"}
        )
        raw_docs = [doc for doc, score in raw_results_with_score if score <= MAX_DISTANCE][:max_k]

        # 2. 'regulation' (사규) 문서 검색
        regulation_results_with_score = vector_store.similarity_search_with_score(
            query, k=initial_k, filter={"Document_Type": "regulation"}
        )
        regulation_docs = [
            doc for doc, score in regulation_results_with_score if score <= MAX_DISTANCE
        ][:max_k]

        return raw_docs + regulation_docs

    SYSTEM_PROMPT = (
        "당신은 회사의 사규 및 내규에 정통한 전문 컨설턴트입니다. "
        "제공된 '참고 문서'만을 활용하여 사용자의 질문에 정확하고 자세하게 답변해야 합니다. "
        "임계값을 충족했으면 답변을 해야 합니다. "
        "답변 끝에는 반드시 사용된 '참고 문서'의 [문서 유형: XX, 출처: 파일명, 조항: 제목]을 명확하게 제시해야 합니다. "
        "표 형태로 추출된 내용은 표 형태로 깔끔하게 포맷팅하여 제공하세요."
    )
    prompt = ChatPromptTemplate.from_messages([
        ("system", SYSTEM_PROMPT),
        ("human", "참고 문서:\n{context}\n\n질문: {question}")
    ])

    # LLM 호출 및 로깅을 포함한 커스텀 체인
    def rag_with_logging(query: str) -> str:
        """RAG 체인을 실행하고 로깅합니다."""
        # 문서 검색
        docs = dual_retriever(query)
        context = format_docs(docs)
        
        # 프롬프트 생성
        formatted_prompt = prompt.format_messages(context=context, question=query)
        full_prompt_text = "\n".join([f"{msg.type}: {msg.content}" for msg in formatted_prompt])
        
        logger.info("=" * 80)
        logger.info(f"[LLM 입력 프롬프트 - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}]")
        logger.info(f"질문: {query}")
        logger.info(f"Temperature: {temperature}")
        logger.info(f"Similarity Threshold: {similarity_threshold}")
        logger.info(f"Max K: {max_k}")
        logger.info(f"검색된 문서 수: {len(docs)}개")
        logger.info("-" * 80)
        logger.info("검색된 문서 원문 목록:")
        for i, doc in enumerate(docs, 1):
            source_info = os.path.basename(doc.metadata.get("source", "알 수 없음"))
            article_title = doc.metadata.get("Article_Title", "조항 없음")
            doc_type = doc.metadata.get("Document_Type", "알 수 없음")
            logger.info(f"  문서 {i}: [{doc_type}] {source_info} - {article_title}")
            logger.info(f"    원문 길이: {len(doc.page_content)} 문자")
            logger.info(f"    원문 미리보기: {doc.page_content[:200]}...")
        logger.info("-" * 80)
        logger.info(f"참고 문서 컨텍스트 전체 길이: {len(context)} 문자")
        logger.info("-" * 80)
        logger.info(f"전체 프롬프트:\n{full_prompt_text}")
        logger.info("=" * 80)
        
        # LLM 호출
        response = llm.invoke(formatted_prompt)
        response_text = response.content if hasattr(response, 'content') else str(response)
        
        logger.info("=" * 80)
        logger.info(f"[LLM 응답 - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}]")
        logger.info(f"응답 길이: {len(response_text)} 문자")
        logger.info(f"응답 내용:\n{response_text}")
        logger.info("=" * 80)
        logger.info("")  # 빈 줄 추가
        
        return response_text
    
    rag_chain = RunnableLambda(rag_with_logging)

    return rag_chain


@app.get("/")
async def root():
    return {"message": "Korail RAG Backend API", "status": "running"}


@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "vector_store_initialized": vector_store is not None
    }


@app.get("/initialize/progress", response_model=ProgressResponse)
async def get_init_progress():
    """초기화 진행 상황을 조회합니다."""
    global init_progress
    return ProgressResponse(**init_progress)


@app.post("/initialize")
async def initialize_vector_store(request: InitializeRequest, background_tasks: BackgroundTasks):
    """PDF 문서를 로드하고 벡터 스토어를 초기화합니다."""
    global init_progress, vector_store
    
    # force=True이면 기존 DB 확인 생략하고 바로 초기화
    if not request.force:
        # 기존 벡터 스토어 확인
        try:
            from langchain_community.vectorstores import Chroma
            
            # 임베딩 모델 경로 결정
            model_path = request.model_path
            if not model_path:
                from huggingface_hub import snapshot_download
                MODEL_ID = "BM-K/KoSimCSE-roberta-multitask"
                try:
                    model_path = snapshot_download(repo_id=MODEL_ID)
                except:
                    pass
            
            if model_path:
                # 기존 ChromaDB 컬렉션 확인
                try:
                    embeddings = CustomHuggingFaceEmbeddings(model_path=model_path, device='cpu')
                    
                    # backend 디렉토리 기준으로 chroma_db 경로 설정
                    current_dir = os.path.dirname(os.path.abspath(__file__))
                    chroma_db_path = os.path.join(current_dir, "chroma_db")
                    
                    existing_store = Chroma(
                        collection_name="regulations_collection",
                        embedding_function=embeddings,
                        collection_metadata={"hnsw:space": "cosine"},
                        persist_directory=chroma_db_path  # 명시적 경로 지정
                    )
                    
                    # 컬렉션에 문서가 있는지 확인
                    collection = existing_store._collection
                    count = collection.count()
                    
                    if count > 0:
                        # 기존 벡터 스토어 사용
                        global vector_store, rag_chain
                        vector_store = existing_store
                        
                        # RAG 체인 초기화
                        api_key = os.getenv("GOOGLE_API_KEY", "AIzaSyCPeHe4VSXawGN9ocudEwy_T1XipTT2xSk")
                        if api_key:
                            rag_chain = create_rag_chain(vector_store, api_key, 0.5, 5, 0.05)
                        
                        return {
                            "message": f"기존 벡터 DB가 발견되었습니다. ({count}개의 청크가 저장되어 있음)",
                            "status": "existing",
                            "num_chunks": count,
                            "skip_initialization": True
                        }
                except Exception as e:
                    # 컬렉션이 없거나 오류 발생 시 새로 생성
                    print(f"기존 벡터 DB 확인 실패, 새로 생성합니다: {e}")
        except Exception as e:
            print(f"벡터 DB 확인 중 오류: {e}")
    
    # 진행 상황 초기화
    force_flag = request.force if hasattr(request, 'force') else False
    init_progress = {
        "status": "loading_model",
        "current_step": "시작",
        "progress": 0,
        "total": 100,
        "message": "재초기화를 시작합니다..." if force_flag else "초기화를 시작합니다..."
    }
    
    # 백그라운드 태스크로 실행
    background_tasks.add_task(initialize_vector_store_sync, request)
    
    # 즉시 응답 반환
    return {"message": "초기화가 시작되었습니다. /initialize/progress에서 진행 상황을 확인하세요.", "status": "started"}


def initialize_vector_store_sync(request: InitializeRequest):
    """PDF 문서를 로드하고 벡터 스토어를 초기화합니다 (동기 함수)."""
    global vector_store, rag_chain, init_progress

    try:
        # 진행 상황 초기화
        init_progress = {
            "status": "loading_model",
            "current_step": "임베딩 모델 로드 중",
            "progress": 0,
            "total": 100,
            "message": "임베딩 모델을 준비하고 있습니다..."
        }

        # 모델 경로 결정
        model_path = request.model_path
        if not model_path:
            init_progress["message"] = "Hugging Face에서 모델을 다운로드하고 있습니다..."
            # Hugging Face 캐시에서 자동 탐색
            from huggingface_hub import snapshot_download
            MODEL_ID = "BM-K/KoSimCSE-roberta-multitask"
            model_path = snapshot_download(repo_id=MODEL_ID)
        
        init_progress["progress"] = 10
        init_progress["status"] = "loading_docs"
        init_progress["current_step"] = "PDF 파일 검색 중"
        init_progress["message"] = "PDF 파일을 찾고 있습니다..."

        # 문서 처리
        pdf_dir = request.pdf_directory
        # 상대 경로인 경우 프로젝트 루트 기준으로 처리
        if not os.path.isabs(pdf_dir):
            # backend 디렉토리에서 상위로 이동하여 프로젝트 루트 확인
            current_dir = os.path.dirname(os.path.abspath(__file__))
            project_root = os.path.dirname(current_dir)
            pdf_dir = os.path.join(project_root, pdf_dir)
        
        if not os.path.exists(pdf_dir):
            init_progress["status"] = "error"
            init_progress["message"] = f"PDF 디렉토리를 찾을 수 없습니다: {pdf_dir}"
            return

        # PDF 파일 목록 가져오기
        pdf_files = [os.path.join(pdf_dir, f) for f in os.listdir(pdf_dir) if f.endswith('.pdf')]
        
        if not pdf_files:
            init_progress["status"] = "error"
            init_progress["message"] = f"PDF 파일이 없습니다: {pdf_dir}"
            return

        init_progress["progress"] = 20
        init_progress["status"] = "processing"
        init_progress["current_step"] = "PDF 문서 로드 중"
        init_progress["message"] = f"{len(pdf_files)}개의 PDF 파일을 로드하고 있습니다..."
        init_progress["total"] = len(pdf_files)

        # 문서 로드
        all_documents = []
        import time
        for idx, pdf_file in enumerate(pdf_files):
            init_progress["message"] = f"PDF 로드 중: {os.path.basename(pdf_file)} ({idx + 1}/{len(pdf_files)})"
            init_progress["progress"] = 20 + int((idx + 1) / len(pdf_files) * 20)
            
            doc = document_processor.load_single_document(pdf_file)
            if doc:
                all_documents.append(doc)
            
            # 진행 상황이 업데이트되도록 약간의 지연
            time.sleep(0.1)

        if not all_documents:
            init_progress["status"] = "error"
            init_progress["message"] = "문서 로드 실패"
            return

        init_progress["progress"] = 40
        init_progress["current_step"] = "문서 전처리 중"
        init_progress["message"] = "문서 구조를 분석하고 있습니다..."

        # 구조 인식 청킹
        markdown_docs = document_processor.preprocess_to_markdown(all_documents)
        init_progress["progress"] = 50
        chunks = document_processor.split_text_with_structure_awareness(markdown_docs)
        init_progress["progress"] = 60

        init_progress["status"] = "embedding"
        init_progress["current_step"] = "임베딩 모델 초기화 중"
        init_progress["message"] = "임베딩 모델을 초기화하고 있습니다..."

        # 벡터 스토어 생성
        embeddings = CustomHuggingFaceEmbeddings(model_path=model_path, device='cpu')
        init_progress["progress"] = 65
        
        # backend 디렉토리 기준으로 chroma_db 경로 설정
        current_dir = os.path.dirname(os.path.abspath(__file__))
        chroma_db_path = os.path.join(current_dir, "chroma_db")
        
        # force=True이면 기존 컬렉션 삭제
        force_flag = request.force if hasattr(request, 'force') else False
        if force_flag:
            try:
                # 기존 컬렉션 삭제
                import shutil
                if os.path.exists(chroma_db_path):
                    init_progress["message"] = "기존 벡터 DB를 삭제하고 있습니다..."
                    print(f"[재초기화] 기존 벡터 DB 삭제 중: {chroma_db_path}")
                    shutil.rmtree(chroma_db_path)
                    print("[재초기화] 기존 벡터 DB 삭제 완료")
                    init_progress["message"] = "기존 벡터 DB 삭제 완료. 새로운 문서를 로드합니다..."
            except Exception as e:
                print(f"[경고] 기존 벡터 DB 삭제 중 오류 (무시하고 계속): {e}")
        
        vector_store = Chroma(
            collection_name="regulations_collection",
            embedding_function=embeddings,
            collection_metadata={"hnsw:space": "cosine"},
            persist_directory=chroma_db_path  # 명시적 경로 지정
        )

        init_progress["current_step"] = "벡터 DB 저장 중"
        init_progress["message"] = f"{len(chunks)}개의 청크를 벡터 DB에 저장하고 있습니다..."
        init_progress["total"] = len(chunks)

        # 배치 처리로 임베딩
        batch_size = 256
        total_batches = (len(chunks) + batch_size - 1) // batch_size
        
        import time
        for batch_idx in range(0, len(chunks), batch_size):
            batch = chunks[batch_idx:batch_idx + batch_size]
            vector_store.add_documents(documents=batch)
            
            # 진행 상황 업데이트
            processed = min(batch_idx + batch_size, len(chunks))
            progress_percent = 65 + int((processed / len(chunks)) * 25)
            init_progress["progress"] = progress_percent
            init_progress["message"] = f"벡터 DB 저장 중: {processed}/{len(chunks)} 청크 ({progress_percent}%)"
            
            # 진행 상황이 업데이트되도록 약간의 지연
            time.sleep(0.05)

        init_progress["progress"] = 90
        init_progress["current_step"] = "RAG 체인 초기화 중"
        init_progress["message"] = "RAG 시스템을 초기화하고 있습니다..."

        # RAG 체인 초기화
        api_key = os.getenv("GOOGLE_API_KEY", "AIzaSyCPeHe4VSXawGN9ocudEwy_T1XipTT2xSk")
        if not api_key:
            init_progress["status"] = "error"
            init_progress["message"] = "GOOGLE_API_KEY 환경 변수가 설정되지 않았습니다."
            return
        
        rag_chain = create_rag_chain(vector_store, api_key, 0.5, 5)

        init_progress["status"] = "done"
        init_progress["progress"] = 100
        init_progress["current_step"] = "완료"
        init_progress["message"] = f"초기화가 완료되었습니다! (문서: {len(all_documents)}개, 청크: {len(chunks)}개)"

    except Exception as e:
        init_progress["status"] = "error"
        init_progress["message"] = f"오류 발생: {str(e)}"
        print(f"초기화 오류: {str(e)}")


@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """챗봇 질문을 처리하고 답변을 반환합니다."""
    global vector_store, rag_chain

    # 벡터 스토어가 없으면 기존 DB 자동 로드 시도
    if vector_store is None:
        print("벡터 스토어가 없습니다. 기존 DB를 로드 시도합니다...")
        loaded = load_existing_vector_store()
        if not loaded:
            raise HTTPException(
                status_code=503, 
                detail="벡터 스토어가 초기화되지 않았습니다. /initialize를 먼저 호출하세요."
            )
    
    # RAG 체인이 없으면 초기화
    if rag_chain is None:
        api_key = os.getenv("GOOGLE_API_KEY", "AIzaSyCPeHe4VSXawGN9ocudEwy_T1XipTT2xSk")
        if api_key:
            rag_chain = create_rag_chain(vector_store, api_key, 0.5, 5)
        else:
            raise HTTPException(
                status_code=503,
                detail="RAG 체인이 초기화되지 않았습니다. GOOGLE_API_KEY를 확인하세요."
            )

    try:
        # RAG 체인을 동적 파라미터로 재생성
        api_key = os.getenv("GOOGLE_API_KEY", "AIzaSyCPeHe4VSXawGN9ocudEwy_T1XipTT2xSk")
        if not api_key:
            raise HTTPException(status_code=500, detail="GOOGLE_API_KEY 환경 변수가 설정되지 않았습니다.")
        
        current_rag_chain = create_rag_chain(
            vector_store,
            api_key,
            request.similarity_threshold,
            request.max_k,
            request.temperature
        )

        # 질문 처리
        response = current_rag_chain.invoke(request.question)

        # 소스 추출 (검색된 문서 정보)
        MAX_DISTANCE = 1.0 - request.similarity_threshold
        initial_k = request.max_k * 2
        
        raw_results = vector_store.similarity_search_with_score(
            request.question, k=initial_k, filter={"Document_Type": "raw"}
        )
        regulation_results = vector_store.similarity_search_with_score(
            request.question, k=initial_k, filter={"Document_Type": "regulation"}
        )
        
        all_results = [
            (doc, score) for doc, score in raw_results + regulation_results
            if score <= MAX_DISTANCE
        ][:request.max_k * 2]

        sources = []
        for doc, score in all_results:
            sources.append(SourceInfo(
                source=os.path.basename(doc.metadata.get("source", "알 수 없음")),
                article_title=doc.metadata.get("Article_Title", "조항 없음"),
                document_type=doc.metadata.get("Document_Type", "알 수 없음"),
                similarity_score=float(1.0 - score)
            ))

        return ChatResponse(answer=response, sources=sources)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"챗봇 처리 실패: {str(e)}")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

