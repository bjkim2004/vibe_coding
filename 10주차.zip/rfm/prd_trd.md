### 기능
- csv 파일업로드 기능
- 데이터 레이아웃은 @주문데이터.csv 참조
- 업로든 된 csv 파일을 supabase DB에 저장
- DB저장을 위해 테이블 생성
- 저장된 데이터를 이용하여 RFM 분석 수행
- 분석결과를 dashboard로 출력
- 분석 결과를 gemini api를 호출하여 마케팅 전략 인사이트 제시

### 기술
1. backend: python fast api 환경 구성
2. frontend: vite로 구성

### DB 접속 정보


### Gemini OpenAPI Key 
