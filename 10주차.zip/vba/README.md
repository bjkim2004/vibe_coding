# MyAI for Excel 🤖

Excel에서 Google Sheets의 `=AI()`나 MS365의 `=Copilot()`과 동일한 AI 기능을 사용할 수 있는 VBA 기반 커스텀 함수입니다.

[![Excel](https://img.shields.io/badge/Excel-2016+-green.svg)](https://www.microsoft.com/excel)
[![VBA](https://img.shields.io/badge/VBA-7.0+-blue.svg)](https://docs.microsoft.com/office/vba)
[![Gemini](https://img.shields.io/badge/Gemini-2.0_Flash-orange.svg)](https://ai.google.dev)

---

## ✨ 주요 기능

### 1️⃣ `=MyAI()` 함수 (수식 모드)
Excel 셀에서 직접 AI를 호출하는 수식 함수

```excel
=MyAI("2+2는?")
→ 4

=MyAI("이 데이터를 요약해줘", A1:A10)
→ [A1:A10 범위의 데이터 요약 결과]

=MyAI("근무 연수 계산: " & A1)
→ 5년
```

### 2️⃣ `MyAI_Macro` (배치 처리 모드)
여러 셀을 한 번에 처리하며 **"⏳ Loading..."** 표시

**사용법:**
1. 질문이 입력된 셀들을 선택
2. `Alt + F8` → `MyAI_Macro` 실행
3. 각 셀에 로딩 표시 → AI 답변으로 자동 교체

---

## 🚀 빠른 시작

### 설치 방법

1. **`GeminiAI.bas` 파일 다운로드**

2. **Excel 열기** 후 `Alt + F11` (VBA 편집기)

3. **파일 → 가져오기** 선택

4. **`GeminiAI.bas`** 선택

5. **Excel로 돌아가서 사용!**

### 첫 사용

```excel
=MyAI("Hello! Are you working?")
```

---

## 📖 사용 예시

### 기본 질문
```excel
=MyAI("대한민국의 수도는?")
```

### 데이터 분석
```excel
=MyAI("평균을 계산해줘", B2:B20)
```

### 텍스트 처리
```excel
=MyAI("다음을 영어로 번역: " & A1)
```

### 복잡한 계산
```excel
=MyAI("2017년부터 2022년까지는 몇 년?")
```

### 자기소개서 분석
```excel
=MyAI("근무 연수를 계산해줘", A1)
# A1: "Google SW 엔지니어로 5년 활동했습니다"
# 결과: "5년"
```

---

## 🎯 두 가지 사용 방법 비교

| 특징 | `=MyAI()` 함수 | `MyAI_Macro` 매크로 |
|------|---------------|-------------------|
| **사용 방식** | 수식으로 입력 | 셀 선택 후 실행 |
| **로딩 표시** | 상태 표시줄 + 커서 | 셀에 "⏳ Loading..." 표시 ✨ |
| **자동 업데이트** | ✅ (수식이므로) | ❌ (한 번 실행) |
| **배치 처리** | 수동으로 복사 필요 | ✅ 여러 셀 한 번에 |
| **결과 캐싱** | ✅ | ✅ |
| **추천 시나리오** | 동적 데이터 | 일회성 대량 처리 |

---

## 🛠️ 고급 기능

### 캐시 관리
동일한 질문은 자동으로 캐싱되어 즉시 응답합니다.

**캐시 삭제:**
```
Alt + F8 → ClearAICache 실행
```

### API 테스트
```
Alt + F8 → TestGeminiAPI 실행
```

---

## 📋 시스템 요구사항

- **OS:** Windows 10 이상
- **Excel:** 2016 이상
- **인터넷:** 필수 (API 호출)
- **추가 설치:** 불필요 (VBA 기본 기능만 사용)

---

## 🔧 기술 스펙

| 항목 | 상세 |
|------|------|
| **언어** | VBA (Visual Basic for Applications) |
| **AI 모델** | Gemini 2.0 Flash |
| **HTTP 클라이언트** | WinHTTP 5.1 |
| **API 제공** | Google Generative AI |
| **응답 시간** | 평균 2-4초 |
| **타임아웃** | 30초 |
| **최대 출력** | 8192 토큰 |

---

## 📂 프로젝트 구조

```
vba/
├── GeminiAI.bas       # VBA 모듈 (메인 파일)
├── README.md          # 이 파일
├── PRD.md             # 제품 요구사항 문서
├── TRD.md             # 기술 요구사항 문서
└── prd_trd.md         # 원본 요구사항
```

---

## 🎓 함수 레퍼런스

### MyAI(prompt, [referenceCells])

**파라미터:**
- `prompt` (필수): AI에게 전달할 질문 또는 명령
- `referenceCells` (선택): 컨텍스트로 사용할 셀 범위

**반환값:** AI 생성 답변 (String)

**예시:**
```excel
=MyAI("요약해줘", A1:A10)
=MyAI(A1 & " - 분석")
=MyAI("계산: " & B1 & " + " & B2)
```

---

### MyAI_Macro

**설명:** 선택된 셀을 순차적으로 AI 처리

**사용법:**
1. 처리할 셀 선택
2. `Alt + F8`
3. `MyAI_Macro` 선택
4. 실행

**동작:**
- 각 셀에 "⏳ Loading..." 표시 (회색, 이탤릭)
- API 응답 후 결과로 교체
- 완료 메시지 표시

---

### ClearAICache

**설명:** 캐시된 모든 응답 삭제

**사용 시기:**
- 동일 질문에 대해 새로운 답변을 받고 싶을 때
- 메모리 정리가 필요할 때

---

### TestGeminiAPI

**설명:** API 연결 테스트

**사용법:**
```
Alt + F8 → TestGeminiAPI → 실행
```

---

## 💡 팁 & 트릭

### 1. 동적 프롬프트 만들기
```excel
=MyAI("다음 텍스트의 키워드 3개: " & A1)
```

### 2. 조건부 AI 호출
```excel
=IF(A1<>"", MyAI("분석: " & A1), "")
```

### 3. 여러 셀 참조
```excel
=MyAI("비교 분석", A1:B10)
```

### 4. 배치 처리 최적화
대량 데이터는 `MyAI_Macro`를 사용하세요 (더 빠른 피드백)

---

## ⚠️ 제한사항

### Excel/VBA 제약
- ❌ **비동기 처리 불가:** 순차적으로만 처리
- ❌ **UDF 내 셀 변경 불가:** 수식 모드에서는 로딩 표시 제한적
- ✅ **해결책:** 매크로 모드 사용 시 셀에 로딩 표시 가능

### API 제약
- 인터넷 연결 필수
- Rate limit 적용 (과도한 호출 시 제한 가능)
- 매우 긴 응답은 잘릴 수 있음

---

## 🔐 보안 고려사항

### v1.0 (현재)
- API Key가 코드에 하드코딩
- VBA 편집기에서 확인 가능
- **권장:** 개인/프로토타입 용도

### v2.0 (계획)
- 사용자 입력 UI
- 암호화된 저장
- 환경 변수 지원

---

## 🐛 문제 해결

### "Error: Prompt is required"
→ 빈 셀에 수식을 입력했습니다. 프롬프트를 입력하세요.

### "API Error: HTTP 400"
→ API Key가 유효하지 않거나 요청 형식이 잘못되었습니다.

### "API Error: HTTP 429"
→ Rate limit 초과. 잠시 후 다시 시도하세요.

### "Parse Error"
→ API 응답 형식이 예상과 다릅니다. 네트워크 상태를 확인하세요.

### 로딩이 너무 오래 걸림
→ 30초 타임아웃이 적용됩니다. 네트워크 속도를 확인하세요.

---

## 🚧 로드맵

### v1.0 (완료) ✅
- [x] MyAI() 함수
- [x] MyAI_Macro 배치 처리
- [x] 로딩 인디케이터
- [x] 응답 캐싱
- [x] 마크다운 정리

### v2.0 (계획) 🔮
- [ ] API Key 설정 UI
- [ ] 모델 선택 기능 (Pro, Flash 등)
- [ ] 비동기 처리 (Application.OnTime)
- [ ] 응답 히스토리 관리
- [ ] 이미지 입력 지원
- [ ] 사용량 통계
- [ ] 다국어 UI

---

## 📚 문서

- **[PRD.md](PRD.md)** - 제품 요구사항 문서
- **[TRD.md](TRD.md)** - 기술 요구사항 문서
- **[prd_trd.md](prd_trd.md)** - 원본 요구사항

---

## 🤝 기여

이 프로젝트는 개인 프로젝트이지만, 개선 제안은 환영합니다!

---

## 📄 라이선스

이 프로젝트는 교육 및 개인 용도로 자유롭게 사용 가능합니다.

**주의:** Gemini API 사용 시 Google의 이용 약관을 준수해야 합니다.

---

## 🙏 감사의 말

- **Google Gemini API** - 강력한 AI 모델 제공
- **Excel VBA** - 확장 가능한 스크립팅 환경

---

## 📧 지원

문제가 있거나 질문이 있으신가요?

- GitHub Issues (설정 시)
- 또는 코드를 직접 수정해보세요! VBA는 배우기 쉽습니다 😊

---

<div align="center">

**Made with ❤️ for Excel Users**

⭐ 이 프로젝트가 유용했다면 Star를 눌러주세요!

</div>


