/**
 * Google Sheets Gemini API 플러그인
 * Gemini API를 호출하여 응답을 Sheets에 반영하는 애드온
 */

// Gemini API 설정
const GEMINI_API_KEY = 'YOUR_GEMINI_API_KEY'; // 사용자의 API 키로 변경 필요
// 기본 모델: gemini-2.0-flash
const DEFAULT_MODEL = 'gemini-2.0-flash';
const GEMINI_API_BASE_URL = 'https://generativelanguage.googleapis.com/v1beta/models';

/**
 * 스프레드시트 열릴 때 메뉴 추가
 */
function onOpen() {
  createGeminiMenu();
}

/**
 * Gemini AI 메뉴 생성 (수동 실행 가능)
 */
function createGeminiMenu() {
  try {
    const ui = SpreadsheetApp.getUi();
    
    // 기존 메뉴가 있으면 제거 (중복 방지)
    try {
      ui.removeMenu('Gemini AI');
    } catch (e) {
      // 메뉴가 없으면 무시
    }
    
    ui.createMenu('Gemini AI')
      .addItem('선택한 셀로 질문하기', 'askGeminiFromSelection')
      .addItem('선택한 셀 분석하기', 'analyzeWithGemini')
      .addItem('응답을 다음 셀에 추가', 'getGeminiResponseToNextCell')
      .addSeparator()
      .addItem('API 키 설정', 'setApiKey')
      .addItem('모델 선택', 'setModel')
      .addSeparator()
      .addItem('메뉴 새로고침', 'createGeminiMenu')
      .addToUi();
  } catch (error) {
    Logger.log('메뉴 생성 오류: ' + error.toString());
    // 에러가 발생해도 계속 진행
    try {
      SpreadsheetApp.getActiveSpreadsheet().toast('메뉴 생성 중 오류가 발생했습니다. 스프레드시트를 새로고침해주세요.', '알림', 5);
    } catch (e) {
      // toast도 실패하면 무시
    }
  }
}

/**
 * 설치 시 실행되는 함수 (권한 요청용)
 */
function onInstall() {
  onOpen();
}

/**
 * 파일 범위 권한이 부여되었을 때 실행되는 함수 (부가기능용)
 */
function onFileScopeGranted() {
  createGeminiMenu();
  try {
    SpreadsheetApp.getActiveSpreadsheet().toast('Gemini AI 부가기능이 활성화되었습니다!', '설치 완료', 3);
  } catch (e) {
    // toast 실패 시 무시
  }
}

/**
 * Gemini API 키 설정
 */
function setApiKey() {
  const ui = SpreadsheetApp.getUi();
  const response = ui.prompt(
    'Gemini API 키 설정',
    'Google AI Studio에서 발급받은 Gemini API 키를 입력하세요:',
    ui.ButtonSet.OK_CANCEL
  );
  
  if (response.getSelectedButton() == ui.Button.OK) {
    const apiKey = response.getResponseText();
    if (apiKey && apiKey.trim() !== '') {
      // PropertiesService를 사용하여 API 키 저장
      PropertiesService.getScriptProperties().setProperty('GEMINI_API_KEY', apiKey);
      ui.alert('API 키가 저장되었습니다.');
    } else {
      ui.alert('유효한 API 키를 입력해주세요.');
    }
  }
}

/**
 * 저장된 API 키 가져오기
 */
function getApiKey() {
  const savedKey = PropertiesService.getScriptProperties().getProperty('GEMINI_API_KEY');
  return savedKey || GEMINI_API_KEY;
}

/**
 * 사용 중인 모델 가져오기
 */
function getModel() {
  const savedModel = PropertiesService.getScriptProperties().getProperty('GEMINI_MODEL');
  return savedModel || DEFAULT_MODEL;
}

/**
 * Gemini 모델 선택
 */
function setModel() {
  const ui = SpreadsheetApp.getUi();
  const currentModel = getModel();
  
  const response = ui.alert(
    'Gemini 모델 선택',
    `현재 모델: ${currentModel}\n\n사용 가능한 모델:\n` +
    `1. gemini-2.0-flash (권장 - 최신 버전)\n` +
    `2. gemini-1.5-flash\n` +
    `3. gemini-1.5-flash-latest\n` +
    `4. gemini-pro\n\n` +
    `사용할 모델 번호를 입력하세요 (1-4):`,
    ui.ButtonSet.OK_CANCEL
  );
  
  if (response == ui.Button.OK) {
    const prompt = ui.prompt(
      '모델 선택',
      '1: gemini-2.0-flash (권장 - 최신)\n2: gemini-1.5-flash\n3: gemini-1.5-flash-latest\n4: gemini-pro\n\n번호를 입력하세요:',
      ui.ButtonSet.OK_CANCEL
    );
    
    if (prompt.getSelectedButton() == ui.Button.OK) {
      const choice = prompt.getResponseText().trim();
      let selectedModel = '';
      
      switch(choice) {
        case '1':
          selectedModel = 'gemini-2.0-flash';
          break;
        case '2':
          selectedModel = 'gemini-1.5-flash';
          break;
        case '3':
          selectedModel = 'gemini-1.5-flash-latest';
          break;
        case '4':
          selectedModel = 'gemini-pro';
          break;
        default:
          ui.alert('잘못된 선택입니다. 1, 2, 3, 또는 4를 입력하세요.');
          return;
      }
      
      PropertiesService.getScriptProperties().setProperty('GEMINI_MODEL', selectedModel);
      ui.alert(`모델이 "${selectedModel}"로 변경되었습니다.`);
    }
  }
}

/**
 * 응답에서 핵심 결과만 추출
 * @param {string} response - Gemini의 전체 응답
 * @return {string} 핵심 결과만 추출한 텍스트
 */
function extractResultOnly(response) {
  if (!response) return '';
  
  // 응답을 줄바꿈으로 분리
  const lines = response.split('\n');
  const resultLines = [];
  let skipExplanation = false;
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    // 설명 문구 제거
    if (line.includes('다음과 같이') || 
        line.includes('예를 들어') || 
        line.includes('참고로') ||
        line.includes('이렇게') ||
        line.match(/^[0-9]+\.\s*(설명|방법|예시)/)) {
      skipExplanation = true;
      continue;
    }
    
    // 코드 블록이나 결과만 포함
    if (line.startsWith('```') || 
        line.startsWith('#') ||
        line.match(/^[가-힣]+:/) ||
        line.match(/^[A-Za-z]+:/) ||
        line.length > 0 && !skipExplanation) {
      resultLines.push(line);
      skipExplanation = false;
    }
  }
  
  // 결과가 없으면 원본 반환
  const extracted = resultLines.join('\n').trim();
  return extracted || response.trim();
}

/**
 * Gemini API 호출
 * @param {string} prompt - Gemini에 보낼 프롬프트
 * @param {string} model - 사용할 모델 (선택사항, 기본값: getModel())
 * @param {boolean} resultOnly - 결과만 반환할지 여부 (기본값: false)
 * @return {string} Gemini의 응답 텍스트
 */
function callGeminiAPI(prompt, model, resultOnly) {
  const apiKey = getApiKey();
  const selectedModel = model || getModel();
  
  if (apiKey === 'YOUR_GEMINI_API_KEY' || !apiKey) {
    throw new Error('Gemini API 키가 설정되지 않았습니다. 메뉴에서 "API 키 설정"을 먼저 실행해주세요.');
  }
  
  if (!prompt || prompt.trim() === '') {
    throw new Error('프롬프트가 비어있습니다.');
  }
  
  const url = `${GEMINI_API_BASE_URL}/${selectedModel}:generateContent?key=${apiKey}`;
  
  const payload = {
    contents: [{
      parts: [{
        text: prompt
      }]
    }]
  };
  
  const options = {
    method: 'post',
    contentType: 'application/json',
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  };
  
  try {
    const response = UrlFetchApp.fetch(url, options);
    const responseCode = response.getResponseCode();
    const responseText = response.getContentText();
    
    if (responseCode !== 200) {
      let errorMessage = `API 호출 실패 (${responseCode})`;
      
      try {
        const errorData = JSON.parse(responseText);
        if (errorData.error && errorData.error.message) {
          errorMessage += ': ' + errorData.error.message;
        } else {
          errorMessage += '\n' + responseText;
        }
      } catch (e) {
        errorMessage += '\n' + responseText;
      }
      
      // 무료 티어 관련 오류 메시지 개선
      if (responseCode === 403) {
        errorMessage += '\n\n참고: API 키가 유효한지 확인하거나, 모델 이름이 올바른지 확인해주세요.';
      } else if (responseCode === 429) {
        errorMessage += '\n\n참고: 요청 한도를 초과했습니다. 잠시 후 다시 시도해주세요.';
      }
      
      throw new Error(errorMessage);
    }
    
    const data = JSON.parse(responseText);
    
    // 응답 파싱 개선 (더 안전하게)
    if (data.candidates && data.candidates.length > 0) {
      const candidate = data.candidates[0];
      
      // 안전성 체크 (finishReason 확인)
      if (candidate.finishReason === 'SAFETY') {
        throw new Error('응답이 안전 정책에 의해 차단되었습니다.');
      } else if (candidate.finishReason === 'RECITATION') {
        throw new Error('응답이 저작권 보호로 인해 차단되었습니다.');
      } else if (candidate.finishReason === 'OTHER') {
        throw new Error('응답 생성 중 오류가 발생했습니다. (finishReason: OTHER)');
      }
      
      if (candidate.content && candidate.content.parts && candidate.content.parts.length > 0) {
        const fullResponse = candidate.content.parts[0].text;
        
        // resultOnly가 true이면 핵심 결과만 추출
        if (resultOnly === true) {
          return extractResultOnly(fullResponse);
        }
        
        return fullResponse;
      }
    }
    
    // 응답이 없거나 형식이 다른 경우
    if (data.promptFeedback && data.promptFeedback.blockReason) {
      throw new Error(`프롬프트가 차단되었습니다: ${data.promptFeedback.blockReason}`);
    }
    
    throw new Error('응답을 파싱할 수 없습니다. 응답 형식: ' + JSON.stringify(data).substring(0, 200));
  } catch (error) {
    Logger.log('Error calling Gemini API: ' + error.toString());
    Logger.log('URL: ' + url);
    Logger.log('Model: ' + selectedModel);
    throw error;
  }
}

/**
 * 선택한 셀의 내용으로 Gemini에 질문하고 결과를 표시
 */
function askGeminiFromSelection() {
  const sheet = SpreadsheetApp.getActiveSheet();
  const range = sheet.getActiveRange();
  
  if (!range) {
    SpreadsheetApp.getUi().alert('셀을 먼저 선택해주세요.');
    return;
  }
  
  const selectedText = range.getValue();
  
  if (!selectedText || selectedText.toString().trim() === '') {
    SpreadsheetApp.getUi().alert('선택한 셀에 내용이 없습니다.');
    return;
  }
  
  try {
    SpreadsheetApp.getActiveSpreadsheet().toast('Gemini API 호출 중...', '처리 중', 2);
    const response = callGeminiAPI(selectedText.toString());
    
    // 결과를 새 시트에 표시하거나 다이얼로그로 표시
    const ui = SpreadsheetApp.getUi();
    ui.alert('Gemini 응답', response, ui.ButtonSet.OK);
  } catch (error) {
    SpreadsheetApp.getUi().alert('오류: ' + error.toString());
  }
}

/**
 * 선택한 셀의 내용을 분석하고 결과를 다음 셀에 추가
 */
function analyzeWithGemini() {
  const sheet = SpreadsheetApp.getActiveSheet();
  const range = sheet.getActiveRange();
  
  if (!range) {
    SpreadsheetApp.getUi().alert('셀을 먼저 선택해주세요.');
    return;
  }
  
  const selectedText = range.getValue();
  
  if (!selectedText || selectedText.toString().trim() === '') {
    SpreadsheetApp.getUi().alert('선택한 셀에 내용이 없습니다.');
    return;
  }
  
  const prompt = `다음 내용을 분석해주세요: ${selectedText.toString()}`;
  
  try {
    SpreadsheetApp.getActiveSpreadsheet().toast('Gemini 분석 중...', '처리 중', 2);
    const response = callGeminiAPI(prompt);
    
    // 결과를 다음 행에 추가
    const nextRow = range.getRow() + 1;
    const nextCol = range.getColumn();
    sheet.getRange(nextRow, nextCol).setValue(response);
    
    SpreadsheetApp.getActiveSpreadsheet().toast('분석 완료!', '완료', 2);
  } catch (error) {
    SpreadsheetApp.getUi().alert('오류: ' + error.toString());
  }
}

/**
 * 선택한 셀로 질문하고 응답을 다음 셀에 추가
 */
function getGeminiResponseToNextCell() {
  const sheet = SpreadsheetApp.getActiveSheet();
  const range = sheet.getActiveRange();
  
  if (!range) {
    SpreadsheetApp.getUi().alert('셀을 먼저 선택해주세요.');
    return;
  }
  
  const selectedText = range.getValue();
  
  if (!selectedText || selectedText.toString().trim() === '') {
    SpreadsheetApp.getUi().alert('선택한 셀에 내용이 없습니다.');
    return;
  }
  
  try {
    SpreadsheetApp.getActiveSpreadsheet().toast('Gemini API 호출 중...', '처리 중', 2);
    const response = callGeminiAPI(selectedText.toString());
    
    // 결과를 옆 열에 추가
    const currentRow = range.getRow();
    const nextCol = range.getColumn() + 1;
    sheet.getRange(currentRow, nextCol).setValue(response);
    
    SpreadsheetApp.getActiveSpreadsheet().toast('응답 완료!', '완료', 2);
  } catch (error) {
    SpreadsheetApp.getUi().alert('오류: ' + error.toString());
  }
}

/**
 * 범위의 모든 셀에 대해 Gemini API 호출
 * @param {Range} range - 처리할 범위
 * @param {string} promptPrefix - 프롬프트 앞에 추가할 텍스트
 */
function processRangeWithGemini(range, promptPrefix = '') {
  const values = range.getValues();
  const responses = [];
  
  for (let i = 0; i < values.length; i++) {
    const row = values[i];
    for (let j = 0; j < row.length; j++) {
      const cellValue = row[j];
      if (cellValue && cellValue.toString().trim() !== '') {
        try {
          const prompt = promptPrefix ? `${promptPrefix}: ${cellValue.toString()}` : cellValue.toString();
          const response = callGeminiAPI(prompt);
          responses.push([response]);
        } catch (error) {
          responses.push([`오류: ${error.toString()}`]);
        }
      } else {
        responses.push(['']);
      }
    }
  }
  
  return responses;
}

/**
 * 커스텀 함수: 셀에서 직접 사용 가능한 MyAI 함수
 * 해당 셀에서만 독립적으로 처리되며 다른 셀에 영향을 주지 않습니다.
 * 
 * 사용법:
 * =MyAI("프롬프트") - 프롬프트만 사용 (결과만 반환)
 * =MyAI("프롬프트", A1) - 프롬프트 + 셀 참조 (결과만 반환)
 * =MyAI("번역해줘", B2) - 셀의 내용을 번역 (결과만 반환)
 * =MyAI("분석해줘", "매출: 1000만원") - 직접 값 전달 (결과만 반환)
 * 
 * @param {string} prompt - Gemini에 보낼 프롬프트
 * @param {string|number|Range} cellReference - 선택사항: 셀 참조, 값, 또는 셀 범위
 * @return {string} Gemini의 응답 텍스트 (결과만 반환, 해당 셀에만 표시)
 * @customfunction
 */
function MyAI(prompt, cellReference) {
  try {
    // 프롬프트 검증
    if (!prompt || prompt.toString().trim() === '') {
      return '오류: 프롬프트를 입력해주세요.';
    }
    
    // 현재 활성 시트 확인 (컨텍스트 격리)
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    if (!ss) {
      return '오류: 활성 스프레드시트를 찾을 수 없습니다.';
    }
    
    let fullPrompt = prompt.toString();
    
    // 두 번째 인자가 제공된 경우
    if (cellReference !== undefined && cellReference !== null) {
      let cellValue = '';
      
      try {
        // Range 객체인 경우 (셀 참조)
        if (typeof cellReference === 'object' && cellReference.constructor && 
            cellReference.constructor.name === 'Range') {
          cellValue = cellReference.getValue();
        } 
        // 값이 직접 전달된 경우
        else {
          cellValue = cellReference.toString();
        }
        
        // 셀 값이 있으면 프롬프트에 추가
        if (cellValue && cellValue.toString().trim() !== '') {
          fullPrompt = `${fullPrompt}\n\n다음 내용: ${cellValue.toString()}`;
        }
      } catch (e) {
        // 셀 참조 오류 무시하고 계속 진행
        Logger.log('셀 참조 처리 오류: ' + e.toString());
      }
    }
    
    // 결과만 간결하게 요청하는 지시 추가
    fullPrompt = `${fullPrompt}\n\n중요: 설명 없이 결과만 간결하게 답변해주세요.`;
    
    // Gemini API 호출 (결과만 반환)
    // 이 함수는 호출된 셀에만 값을 반환하므로 자동으로 격리됨
    const response = callGeminiAPI(fullPrompt, null, true);
    
    // 결과를 해당 셀에만 반환 (다른 셀에 영향 없음)
    return response;
    
  } catch (error) {
    // 에러 메시지 반환 (커스텀 함수는 UI.alert를 사용할 수 없음)
    // 에러도 해당 셀에만 표시됨
    const errorMessage = error.toString();
    
    // API 키 관련 오류
    if (errorMessage.includes('API 키가 설정되지 않았습니다')) {
      return '오류: API 키가 설정되지 않았습니다. Gemini AI > API 키 설정 메뉴에서 설정하세요.';
    }
    
    // 기타 오류
    return `오류: ${errorMessage}`;
  }
}

/**
 * 간단한 버전: 프롬프트만 사용 (결과만 반환)
 * 해당 셀에서만 독립적으로 처리됩니다.
 * 
 * 사용법:
 * =AI("프롬프트")
 * 
 * @param {string} prompt - Gemini에 보낼 프롬프트
 * @return {string} Gemini의 응답 텍스트 (결과만 반환, 해당 셀에만 표시)
 * @customfunction
 */
function AI(prompt) {
  // MyAI 함수 호출 (격리된 처리)
  return MyAI(prompt);
}

/**
 * 전체 응답을 받는 함수 (설명 포함)
 * 해당 셀에서만 독립적으로 처리됩니다.
 * 
 * 사용법:
 * =MyAIFull("프롬프트", A1) - 전체 응답 받기
 * 
 * @param {string} prompt - Gemini에 보낼 프롬프트
 * @param {string|number|Range} cellReference - 선택사항: 셀 참조, 값, 또는 셀 범위
 * @return {string} Gemini의 전체 응답 텍스트 (해당 셀에만 표시)
 * @customfunction
 */
function MyAIFull(prompt, cellReference) {
  try {
    // 프롬프트 검증
    if (!prompt || prompt.toString().trim() === '') {
      return '오류: 프롬프트를 입력해주세요.';
    }
    
    // 현재 활성 시트 확인 (컨텍스트 격리)
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    if (!ss) {
      return '오류: 활성 스프레드시트를 찾을 수 없습니다.';
    }
    
    let fullPrompt = prompt.toString();
    
    // 두 번째 인자가 제공된 경우
    if (cellReference !== undefined && cellReference !== null) {
      let cellValue = '';
      
      try {
        // Range 객체인 경우 (셀 참조)
        if (typeof cellReference === 'object' && cellReference.constructor && 
            cellReference.constructor.name === 'Range') {
          cellValue = cellReference.getValue();
        } 
        // 값이 직접 전달된 경우
        else {
          cellValue = cellReference.toString();
        }
        
        // 셀 값이 있으면 프롬프트에 추가
        if (cellValue && cellValue.toString().trim() !== '') {
          fullPrompt = `${fullPrompt}\n\n다음 내용: ${cellValue.toString()}`;
        }
      } catch (e) {
        // 셀 참조 오류 무시하고 계속 진행
        Logger.log('셀 참조 처리 오류: ' + e.toString());
      }
    }
    
    // Gemini API 호출 (전체 응답 반환)
    // 이 함수는 호출된 셀에만 값을 반환하므로 자동으로 격리됨
    const response = callGeminiAPI(fullPrompt, null, false);
    return response;
    
  } catch (error) {
    // 에러도 해당 셀에만 표시됨
    const errorMessage = error.toString();
    
    if (errorMessage.includes('API 키가 설정되지 않았습니다')) {
      return '오류: API 키가 설정되지 않았습니다. Gemini AI > API 키 설정 메뉴에서 설정하세요.';
    }
    
    return `오류: ${errorMessage}`;
  }
}

