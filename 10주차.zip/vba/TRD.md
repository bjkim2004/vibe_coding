# Technical Requirements Document (TRD)
## MyAI - Excel AI Function

---

## 1. Technical Overview

**Product:** MyAI for Excel  
**Technology Stack:** VBA (Visual Basic for Applications)  
**API:** Google Gemini 2.0 Flash  
**HTTP Client:** WinHTTP 5.1  
**Version:** 1.0  
**Date:** 2024-11-09  

---

## 2. System Architecture

### 2.1 High-Level Architecture

```
┌─────────────────┐
│  Excel User     │
│  Interface      │
└────────┬────────┘
         │
         │ =MyAI() or MyAI_Macro
         ▼
┌─────────────────┐
│  GeminiAI.bas   │
│  VBA Module     │
│  - MyAI()       │
│  - MyAI_Macro() │
│  - Cache        │
└────────┬────────┘
         │
         │ HTTP POST (JSON)
         ▼
┌─────────────────┐
│  WinHTTP 5.1    │
│  HTTP Client    │
└────────┬────────┘
         │
         │ HTTPS
         ▼
┌─────────────────┐
│  Gemini API     │
│  2.0 Flash      │
│  Endpoint       │
└─────────────────┘
```

### 2.2 Component Diagram

```
GeminiAI Module
├── Public Functions (User-Facing)
│   ├── MyAI(prompt, [referenceCells]) → Variant
│   ├── MyAI_Macro() → Sub
│   ├── ClearAICache() → Sub
│   └── TestGeminiAPI() → Sub
│
├── Private Functions (Internal)
│   ├── CallGeminiAPI(prompt) → String
│   ├── BuildJsonRequest(prompt) → String
│   ├── ParseGeminiResponse(jsonResponse) → String
│   ├── CleanupResponse(response) → String
│   ├── GetRangeText(cellRange) → String
│   ├── EscapeJsonString(text) → String
│   └── UnescapeJsonString(text) → String
│
└── Data Structures
    └── cacheDict (Scripting.Dictionary)
```

---

## 3. API Integration

### 3.1 Gemini API Configuration

**Endpoint:**
```
https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={API_KEY}
```

**API Key:**
```
AIzaSyCPeHe4VSXawGN9ocudEwy_T1XipTT2xSk
```

**Model:**
```
gemini-2.0-flash
```

### 3.2 HTTP Request Specification

**Method:** POST  
**Content-Type:** application/json; charset=utf-8  
**Timeout:** 30,000ms (30 seconds)  

**Request Body Structure:**
```json
{
  "contents": [
    {
      "parts": [
        {
          "text": "[USER_PROMPT]"
        }
      ]
    }
  ],
  "generationConfig": {
    "temperature": 1,
    "maxOutputTokens": 8192
  }
}
```

**Example Request:**
```json
{
  "contents": [
    {
      "parts": [
        {
          "text": "What is 2+2?\n\nIMPORTANT: Answer with ONLY the essential result. No explanations, no markdown formatting, no asterisks, no extra text. Just the direct answer."
        }
      ]
    }
  ],
  "generationConfig": {
    "temperature": 1,
    "maxOutputTokens": 8192
  }
}
```

### 3.3 HTTP Response Specification

**Success Response (HTTP 200):**
```json
{
  "candidates": [
    {
      "content": {
        "parts": [
          {
            "text": "4"
          }
        ]
      },
      "finishReason": "STOP"
    }
  ]
}
```

**Error Response (HTTP 4xx/5xx):**
```json
{
  "error": {
    "code": 400,
    "message": "API key not valid",
    "status": "INVALID_ARGUMENT"
  }
}
```

---

## 4. Core Function Specifications

### 4.1 MyAI() - Main UDF

**Signature:**
```vb
Public Function MyAI(prompt As Variant, Optional referenceCells As Variant) As Variant
```

**Parameters:**
- `prompt` (Variant, Required): User question or instruction
- `referenceCells` (Variant, Optional): Cell range for context

**Return Value:**
- `Variant`: AI response string or error message

**Algorithm:**
```
1. Validate input (prompt not empty)
2. Initialize cache dictionary if needed
3. Build full prompt with reference cells (if provided)
4. Add concise answer instruction to prompt
5. Create cache key from full prompt
6. Check cache:
   - If exists → Return cached result
   - If not exists → Continue
7. Show loading cursor & status bar
8. Call Gemini API
9. Clean up response (remove markdown)
10. Store in cache
11. Clear loading indicators
12. Return response
```

**Error Handling:**
- Input validation error → "Error: Prompt is required"
- API error → "API Error: [description]"
- Parse error → "Parse Error: [description]"

**Performance:**
- Cache hit: < 10ms
- Cache miss: 2-5 seconds (API dependent)

---

### 4.2 MyAI_Macro() - Batch Processing Macro

**Signature:**
```vb
Public Sub MyAI_Macro()
```

**Behavior:**
1. Get selected range
2. Validate selection (not empty)
3. Set loading cursor
4. For each cell in selection:
   - Save original value
   - Set cell to "⏳ Loading..." (gray, italic)
   - Call MyAI(originalValue)
   - Replace with response (black, normal)
   - Update status bar
5. Show completion message
6. Restore cursor

**Visual Feedback:**
- Cell during loading: "⏳ Loading..." (RGB 128,128,128, Italic)
- Cell after completion: Response text (RGB 0,0,0, Normal)
- Status bar: "Processing: [prompt]..."
- Completion dialog: "AI processing complete! Processed N cell(s)."

---

### 4.3 CallGeminiAPI() - HTTP Request Handler

**Signature:**
```vb
Private Function CallGeminiAPI(prompt As String) As String
```

**Process:**
1. Create WinHttp.WinHttpRequest.5.1 object
2. Build API URL with endpoint + model + API key
3. Build JSON request body
4. Configure HTTP POST request
5. Set request headers (Content-Type)
6. Set timeouts (30 seconds)
7. Send request
8. Check HTTP status:
   - 200 → Parse response
   - Other → Return error with status
9. Cleanup and return

**Timeout Configuration:**
```vb
http.SetTimeouts 30000, 30000, 30000, 30000
' ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
```

---

### 4.4 BuildJsonRequest() - JSON Serialization

**Signature:**
```vb
Private Function BuildJsonRequest(prompt As String) As String
```

**Process:**
1. Escape special characters in prompt:
   - `\` → `\\`
   - `"` → `\"`
   - CR → `\r`
   - LF → `\n`
   - Tab → `\t`
2. Build JSON structure manually (no external library)
3. Return JSON string

**Note:** VBA doesn't have native JSON library, so manual string construction is used.

---

### 4.5 ParseGeminiResponse() - JSON Parsing

**Signature:**
```vb
Private Function ParseGeminiResponse(jsonResponse As String) As String
```

**Algorithm:**
```
1. Check for error field
   - If found → Return error message
2. Find "text" field in JSON
3. Locate opening quote after "text":
4. Find matching closing quote (handle escapes)
5. Extract text between quotes
6. Unescape JSON characters
7. Return extracted text
```

**Parsing Strategy:**
- Simple string search (no JSON library)
- Handles escaped quotes
- Error handling for malformed JSON

---

### 4.6 CleanupResponse() - Response Post-Processing

**Signature:**
```vb
Private Function CleanupResponse(response As String) As String
```

**Cleanup Rules:**
1. Remove markdown bold: `**text**` → `text`
2. Remove markdown italic: `*text*` → `text`
3. Remove underscores: `_text_` → `text`
4. Remove backticks: `` `code` `` → `code`
5. Trim whitespace
6. Remove surrounding quotes (if entire string is quoted)

**Examples:**
```
"**5년**" → "5년"
"*Important*" → "Important"
"  answer  " → "answer"
"\"quoted\"" → "quoted"
```

---

### 4.7 GetRangeText() - Cell Range Converter

**Signature:**
```vb
Private Function GetRangeText(cellRange As Variant) As String
```

**Behavior:**
- If Range object → Concatenate all non-empty cell values
- If single value → Convert to string
- Return trimmed result

**Example:**
```vb
A1: "Apple"
A2: "Banana"
A3: "" (empty)
GetRangeText(A1:A3) → "Apple Banana"
```

---

## 5. Data Structures

### 5.1 Cache Dictionary

**Type:** Scripting.Dictionary (COM object)  
**Scope:** Module-level private variable  
**Key:** Full prompt string (including instructions)  
**Value:** AI response string  

**Structure:**
```vb
Private cacheDict As Object

' Example entries:
cacheDict("What is 2+2?...") = "4"
cacheDict("Google SW engineer...") = "5년"
```

**Lifecycle:**
- Created on first MyAI() call
- Persists during Excel session
- Cleared by ClearAICache()
- Lost when workbook closes

**Benefits:**
- Instant response for repeated queries
- Reduces API calls (cost savings)
- Improves user experience

---

## 6. Error Handling Strategy

### 6.1 Error Categories

| Error Type | Detection | Response |
|------------|-----------|----------|
| **Input Validation** | Empty prompt | "Error: Prompt is required" |
| **HTTP Error** | Status ≠ 200 | "API Error: HTTP [status] - [body]" |
| **Network Error** | Exception | "API Error: [description] (Number: [code])" |
| **Parse Error** | JSON parsing fail | "Parse Error: [description]" |
| **Timeout** | 30s elapsed | WinHTTP timeout error |

### 6.2 Error Propagation

```
User Function → Error Message in Cell
Macro → Error Dialog Box + Cleanup
```

### 6.3 Error Recovery

- Status bar cleared
- Cursor restored to default
- Screen updating re-enabled
- User informed of error

---

## 7. Performance Optimization

### 7.1 Caching Strategy

**Implementation:**
- Dictionary-based in-memory cache
- Key: Full prompt (including reference cells)
- No expiration (session-based)

**Cache Hit Ratio Target:** > 30% for typical usage

**Benefits:**
- 99.5% faster response for cached queries
- Reduced API costs
- Better offline resilience

### 7.2 Prompt Optimization

**Auto-appended instruction:**
```
IMPORTANT: Answer with ONLY the essential result. 
No explanations, no markdown formatting, no asterisks, no extra text. 
Just the direct answer.
```

**Benefits:**
- Shorter responses → Faster API processing
- Less token usage → Lower costs
- Cleaner output → Less post-processing

### 7.3 HTTP Configuration

```vb
' Aggressive timeout for responsive UX
http.SetTimeouts 30000, 30000, 30000, 30000

' Synchronous mode (no async in VBA UDF)
http.Open "POST", apiUrl, False
```

---

## 8. Security Considerations

### 8.1 API Key Management

**Current Implementation (v1.0):**
- Hardcoded in VBA module
- Visible in VBA editor
- No encryption

**Risk Level:** Medium (suitable for personal/prototype use)

**Mitigation:**
- VBA project password protection (optional)
- Distribute as .xlsm with locked VBA

**Future Enhancement (v2.0):**
- User input via dialog
- Store in document properties (encrypted)
- Environment variable support

### 8.2 Data Transmission

**Protocol:** HTTPS  
**Library:** WinHTTP 5.1 (SSL/TLS support)  
**Validation:** Certificate validation enabled by default  

### 8.3 Input Sanitization

**JSON Escaping:**
- All special characters escaped before API call
- Prevents JSON injection
- Handles user input safely

**Functions:**
- `EscapeJsonString()` - Before API call
- `UnescapeJsonString()` - After API response

---

## 9. Testing Strategy

### 9.1 Unit Testing

**Test Function:** TestGeminiAPI()

**Test Cases:**
1. ✅ Simple arithmetic: "What is 2+2?" → "4"
2. ✅ Korean text: "Google SW 엔지니어로 5년" → "5년"
3. ✅ Long text processing
4. ✅ Cell reference handling
5. ✅ Cache hit/miss
6. ✅ Error handling (invalid API key)
7. ✅ Timeout handling

### 9.2 Integration Testing

**Scenarios:**
1. Excel formula calculation
2. Copy-paste formula across cells
3. Macro batch processing
4. Cache persistence during session
5. Error recovery

### 9.3 Performance Testing

**Metrics:**
- First call latency: 2-5s (expected)
- Cached call latency: < 10ms (expected)
- Concurrent calls: Sequential (VBA limitation)

---

## 10. Deployment Specification

### 10.1 File Structure

```
vba/
├── GeminiAI.bas          # Main VBA module (deployable)
├── PRD.md                # Product requirements
├── TRD.md                # Technical requirements (this file)
└── prd_trd.md            # Original requirements
```

### 10.2 Installation Steps

1. Download `GeminiAI.bas`
2. Open Excel workbook
3. Press `Alt + F11` (VBA Editor)
4. `File` → `Import File`
5. Select `GeminiAI.bas`
6. Save workbook as `.xlsm` (macro-enabled)

### 10.3 System Requirements

**Minimum:**
- Windows 10 or later
- Excel 2016 or later
- Internet connection
- WinHTTP 5.1 (included in Windows)

**Recommended:**
- Windows 11
- Excel 2021 or Microsoft 365
- Stable internet (5+ Mbps)

### 10.4 Dependencies

**Built-in (no installation required):**
- WinHttp.WinHttpRequest.5.1 (COM)
- Scripting.Dictionary (COM)

**External:**
- Gemini API (requires API key)

---

## 11. Limitations & Constraints

### 11.1 Technical Limitations

| Limitation | Description | Workaround |
|------------|-------------|------------|
| **Synchronous only** | VBA UDF cannot be async | Use macro for batch processing |
| **No real-time loading** | UDF cannot update cell during execution | Status bar + cursor change |
| **No streaming** | Response waits for complete generation | N/A (API limitation) |
| **Single-threaded** | Cannot process multiple cells in parallel | Sequential processing |
| **Memory limit** | Large cache may consume memory | Periodic ClearAICache() |

### 11.2 API Limitations

| Limitation | Value | Impact |
|------------|-------|--------|
| **Max input tokens** | ~32k (model dependent) | Limit prompt + context size |
| **Max output tokens** | 8192 | Long responses may truncate |
| **Rate limit** | Per API key quota | May fail under heavy load |
| **Timeout** | 30s (client-side) | Very long responses timeout |

### 11.3 Excel Limitations

- **Volatile function:** Not marked volatile, recalculates on dependency change only
- **Calculation mode:** Manual calc mode affects auto-update
- **Cell size:** Very long responses may not display fully

---

## 12. Code Quality Standards

### 12.1 Naming Conventions

- **Public functions:** PascalCase (e.g., `MyAI`, `TestGeminiAPI`)
- **Private functions:** PascalCase (e.g., `CallGeminiAPI`)
- **Variables:** camelCase (e.g., `fullPrompt`, `cacheKey`)
- **Constants:** UPPER_SNAKE_CASE (e.g., `GEMINI_API_KEY`)

### 12.2 Documentation Standards

- All public functions have comment headers
- All complex logic has inline comments
- Comments in English only (避免 VBA 한글 깨짐)

### 12.3 Error Handling

- Every public function has `On Error GoTo ErrorHandler`
- Error messages are user-friendly
- Resources cleaned up in error handlers

---

## 13. Maintenance & Support

### 13.1 Known Issues

None currently identified in v1.0.

### 13.2 Future Improvements

**Performance:**
- Implement batch API calls (multiple prompts in one request)
- Add progress bar for long operations
- Optimize JSON parsing

**Features:**
- Multi-model support (Pro, Flash, etc.)
- Image input support
- Conversation history
- Response editing

**UX:**
- Settings dialog for API key
- Usage statistics
- Response preview

---

## 14. API Reference

### 14.1 Public Functions

#### MyAI(prompt, [referenceCells])
Main UDF for Excel formulas.

**Parameters:**
- `prompt` (Variant, Required): Question or instruction
- `referenceCells` (Variant, Optional): Cell range for context

**Returns:** Variant (String or Error)

**Example:**
```vb
=MyAI("Summarize", A1:A10)
```

---

#### MyAI_Macro()
Batch processing macro with loading indicator.

**Parameters:** None

**Returns:** None (updates selected cells)

**Usage:** Select cells, run macro

---

#### ClearAICache()
Clears response cache.

**Parameters:** None

**Returns:** None (shows confirmation dialog)

---

#### TestGeminiAPI()
Tests API connectivity.

**Parameters:** None

**Returns:** None (shows result dialog)

---

## 15. Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2024-11-09 | Initial release |
| | | - MyAI() function |
| | | - MyAI_Macro() |
| | | - Loading indicators |
| | | - Response caching |
| | | - Response cleanup |

---

## 16. References

### 16.1 External Documentation

- [Gemini API Documentation](https://ai.google.dev/docs)
- [Excel VBA Reference](https://docs.microsoft.com/en-us/office/vba/api/overview/excel)
- [WinHTTP 5.1 Documentation](https://docs.microsoft.com/en-us/windows/win32/winhttp/winhttp-start-page)

### 16.2 Related Standards

- JSON RFC 8259
- HTTP/1.1 RFC 7231
- TLS 1.2/1.3 for HTTPS

---

**Document Owner:** Development Team  
**Last Updated:** 2024-11-09  
**Version:** 1.0  
**Status:** Final


