Attribute VB_Name = "GeminiAI"
' ============================================
' Gemini AI Excel UDF Module
' Implements =MyAI() function similar to Google Sheets =AI() and MS365 =Copilot()
' Uses Gemini 2.0 Flash API
' ============================================

Option Explicit

' API Configuration
Private Const GEMINI_API_KEY As String = "AIzaSyCPeHe4VSXawGN9ocudEwy_T1XipTT2xSk"
Private Const GEMINI_MODEL As String = "gemini-2.0-flash"
Private Const API_ENDPOINT As String = "https://generativelanguage.googleapis.com/v1beta/models/"

' Cache for async loading simulation
Private Type CacheEntry
    prompt As String
    result As String
    isLoading As Boolean
    timestamp As Double
End Type

Private cacheDict As Object ' Dictionary to store cache entries

' ============================================
' Main UDF Function: MyAI
' Usage: =MyAI(prompt, [reference_cells])
' Parameters:
'   prompt: The question or instruction for AI
'   reference_cells: Optional range of cells to include as context
' Returns: AI generated response
' ============================================
Public Function MyAI(prompt As Variant, Optional referenceCells As Variant) As Variant
    On Error GoTo ErrorHandler
    
    ' Validate input
    If IsMissing(prompt) Or IsEmpty(prompt) Then
        MyAI = "Error: Prompt is required"
        Exit Function
    End If
    
    ' Initialize cache dictionary if needed
    If cacheDict Is Nothing Then
        Set cacheDict = CreateObject("Scripting.Dictionary")
    End If
    
    ' Build the full prompt with reference cells if provided
    Dim fullPrompt As String
    fullPrompt = CStr(prompt)
    
    If Not IsMissing(referenceCells) Then
        If Not IsEmpty(referenceCells) Then
            fullPrompt = fullPrompt & vbCrLf & "Context: " & GetRangeText(referenceCells)
        End If
    End If
    
    ' Add instruction to return concise answer only
    fullPrompt = fullPrompt & vbCrLf & vbCrLf & _
                 "IMPORTANT: Answer with ONLY the essential result. " & _
                 "No explanations, no markdown formatting, no asterisks, no extra text. " & _
                 "Just the direct answer."
    
    ' Create unique key for caching
    Dim cacheKey As String
    cacheKey = fullPrompt
    
    ' Check if we have a cached result
    If cacheDict.Exists(cacheKey) Then
        ' Return cached result
        MyAI = cacheDict(cacheKey)
        Exit Function
    End If
    
    ' Show loading status
    Dim originalCursor As XlMousePointer
    originalCursor = Application.Cursor
    Application.Cursor = xlWait
    Application.StatusBar = "⏳ Loading AI response..."
    
    ' Call Gemini API
    Dim response As String
    response = CallGeminiAPI(fullPrompt)
    
    ' Clean up the response (remove markdown and extra formatting)
    response = CleanupResponse(response)
    
    ' Cache the result
    cacheDict(cacheKey) = response
    
    ' Clear status and restore cursor
    Application.StatusBar = False
    Application.Cursor = originalCursor
    
    ' Return the response
    MyAI = response
    
    Exit Function
    
ErrorHandler:
    Application.StatusBar = False
    Application.Cursor = xlDefault
    MyAI = "Error: " & Err.Description
End Function

' ============================================
' Clean up AI response (remove markdown, formatting, etc.)
' ============================================
Private Function CleanupResponse(response As String) As String
    Dim result As String
    result = response
    
    ' Remove markdown bold (**text**)
    result = Replace(result, "**", "")
    
    ' Remove markdown italic (*text* or _text_)
    result = Replace(result, "*", "")
    result = Replace(result, "_", "")
    
    ' Remove common markdown code backticks
    result = Replace(result, "`", "")
    
    ' Trim whitespace
    result = Trim(result)
    
    ' Remove quotes if the entire response is quoted
    If Len(result) > 1 Then
        If Left(result, 1) = """" And Right(result, 1) = """" Then
            result = Mid(result, 2, Len(result) - 2)
        End If
    End If
    
    CleanupResponse = result
End Function

' ============================================
' Convert range to text for context
' ============================================
Private Function GetRangeText(cellRange As Variant) As String
    On Error Resume Next
    Dim result As String
    Dim cell As Range
    
    ' Handle single cell
    If TypeName(cellRange) = "Range" Then
        For Each cell In cellRange.Cells
            If Not IsEmpty(cell.Value) Then
                result = result & cell.Value & " "
            End If
        Next cell
    Else
        ' Handle direct value
        result = CStr(cellRange)
    End If
    
    GetRangeText = Trim(result)
End Function

' ============================================
' Call Gemini API and return response
' ============================================
Private Function CallGeminiAPI(prompt As String) As String
    On Error GoTo APIError
    
    ' Create HTTP request object
    Dim http As Object
    Set http = CreateObject("WinHttp.WinHttpRequest.5.1")
    
    ' Build API URL
    Dim apiUrl As String
    apiUrl = API_ENDPOINT & GEMINI_MODEL & ":generateContent?key=" & GEMINI_API_KEY
    
    ' Build JSON request body
    Dim jsonRequest As String
    jsonRequest = BuildJsonRequest(prompt)
    
    ' Configure HTTP request
    http.Open "POST", apiUrl, False
    http.setRequestHeader "Content-Type", "application/json; charset=utf-8"
    
    ' Set timeout (30 seconds)
    http.SetTimeouts 30000, 30000, 30000, 30000
    
    ' Send request
    http.send jsonRequest
    
    ' Get response text
    Dim responseText As String
    responseText = http.responseText
    
    ' Check response status
    If http.Status = 200 Then
        ' Parse and extract response
        CallGeminiAPI = ParseGeminiResponse(responseText)
    Else
        ' Return detailed error with response body
        CallGeminiAPI = "API Error: HTTP " & http.Status & " - " & responseText
    End If
    
    Set http = Nothing
    Exit Function
    
APIError:
    CallGeminiAPI = "API Error: " & Err.Description & " (Number: " & Err.Number & ")"
End Function

' ============================================
' Build JSON request for Gemini API
' ============================================
Private Function BuildJsonRequest(prompt As String) As String
    Dim json As String
    
    ' Escape special characters in prompt
    Dim escapedPrompt As String
    escapedPrompt = EscapeJsonString(prompt)
    
    ' Build JSON structure
    json = "{" & _
           """contents"": [{" & _
           """parts"":[{""text"":""" & escapedPrompt & """}]" & _
           "}]," & _
           """generationConfig"": {" & _
           """temperature"": 1," & _
           """maxOutputTokens"": 8192" & _
           "}" & _
           "}"
    
    BuildJsonRequest = json
End Function

' ============================================
' Escape JSON special characters
' ============================================
Private Function EscapeJsonString(text As String) As String
    Dim result As String
    result = text
    
    ' Replace special characters
    result = Replace(result, "\", "\\")
    result = Replace(result, """", "\""")
    result = Replace(result, vbCr, "\r")
    result = Replace(result, vbLf, "\n")
    result = Replace(result, vbTab, "\t")
    
    EscapeJsonString = result
End Function

' ============================================
' Parse Gemini API response and extract text
' ============================================
Private Function ParseGeminiResponse(jsonResponse As String) As String
    On Error GoTo ParseError
    
    ' Check if response contains error
    If InStr(jsonResponse, """error""") > 0 Then
        ParseGeminiResponse = "API returned error: " & jsonResponse
        Exit Function
    End If
    
    ' Simple JSON parsing to extract text from response
    ' Looking for "text": "..." pattern
    Dim textStart As Long
    Dim textEnd As Long
    Dim searchPos As Long
    
    ' Find the text field in response
    searchPos = InStr(jsonResponse, """text""")
    
    If searchPos > 0 Then
        ' Find the colon after "text"
        textStart = InStr(searchPos, jsonResponse, ":")
        If textStart = 0 Then GoTo ParseError
        
        ' Skip whitespace and find opening quote
        textStart = textStart + 1
        Do While Mid(jsonResponse, textStart, 1) = " "
            textStart = textStart + 1
        Loop
        
        ' Verify we have opening quote
        If Mid(jsonResponse, textStart, 1) <> """" Then
            ParseGeminiResponse = "Error: Expected quote at position " & textStart
            Exit Function
        End If
        
        ' Move past opening quote
        textStart = textStart + 1
        
        ' Find the end of the text value (looking for closing quote)
        textEnd = textStart
        Dim inEscape As Boolean
        inEscape = False
        
        Do While textEnd <= Len(jsonResponse)
            Dim currentChar As String
            currentChar = Mid(jsonResponse, textEnd, 1)
            
            If inEscape Then
                inEscape = False
            ElseIf currentChar = "\" Then
                inEscape = True
            ElseIf currentChar = """" Then
                Exit Do
            End If
            
            textEnd = textEnd + 1
        Loop
        
        ' Extract the text
        Dim extractedText As String
        extractedText = Mid(jsonResponse, textStart, textEnd - textStart)
        
        ' Unescape JSON characters
        extractedText = UnescapeJsonString(extractedText)
        
        ParseGeminiResponse = extractedText
    Else
        ParseGeminiResponse = "Error: No 'text' field found in response: " & Left(jsonResponse, 200)
    End If
    
    Exit Function
    
ParseError:
    ParseGeminiResponse = "Parse Error: " & Err.Description & " at line " & Erl
End Function

' ============================================
' Unescape JSON string
' ============================================
Private Function UnescapeJsonString(text As String) As String
    Dim result As String
    result = text
    
    ' Replace escaped characters
    result = Replace(result, "\n", vbLf)
    result = Replace(result, "\r", vbCr)
    result = Replace(result, "\t", vbTab)
    result = Replace(result, "\""", """")
    result = Replace(result, "\\", "\")
    
    UnescapeJsonString = result
End Function

' ============================================
' Macro version: Updates selected cells with AI response
' Shows "Loading..." in cell while processing
' Usage: Select cells with prompts, then run this macro
' ============================================
Public Sub MyAI_Macro()
    On Error GoTo ErrorHandler
    
    Dim selectedRange As Range
    Dim cell As Range
    Dim response As String
    
    ' Get selected range
    Set selectedRange = Selection
    
    ' Validate selection
    If selectedRange Is Nothing Then
        MsgBox "Please select cells containing prompts.", vbExclamation, "No Selection"
        Exit Sub
    End If
    
    ' Keep screen updating ON to show loading status
    Application.ScreenUpdating = True
    Application.Cursor = xlWait
    
    ' Process each cell
    For Each cell In selectedRange.Cells
        If Not IsEmpty(cell.Value) Then
            ' Show loading status in cell
            Dim originalValue As String
            originalValue = cell.Value
            cell.Value = "⏳ Loading..."
            cell.Font.Italic = True
            cell.Font.Color = RGB(128, 128, 128) ' Gray color
            
            ' Force Excel to update the display immediately
            DoEvents
            Application.StatusBar = "Processing: " & Left(originalValue, 50) & "..."
            
            ' Get AI response
            response = MyAI(originalValue)
            
            ' Update cell with result
            cell.Value = response
            cell.Font.Italic = False
            cell.Font.Color = RGB(0, 0, 0) ' Black color
            
            ' Small delay to see the loading indicator
            DoEvents
        End If
    Next cell
    
    ' Cleanup
    Application.ScreenUpdating = True
    Application.Cursor = xlDefault
    Application.StatusBar = False
    
    MsgBox "AI processing complete! Processed " & selectedRange.Cells.Count & " cell(s).", _
           vbInformation, "MyAI Macro Complete"
    
    Exit Sub
    
ErrorHandler:
    Application.ScreenUpdating = True
    Application.Cursor = xlDefault
    Application.StatusBar = False
    MsgBox "Error: " & Err.Description, vbCritical, "MyAI Macro Error"
End Sub

' ============================================
' Helper function to clear AI cache
' Usage: Call ClearAICache to reset all cached responses
' ============================================
Public Sub ClearAICache()
    If Not cacheDict Is Nothing Then
        cacheDict.RemoveAll
        MsgBox "AI response cache cleared successfully.", vbInformation, "Cache Cleared"
    Else
        MsgBox "Cache is already empty.", vbInformation, "Cache Status"
    End If
End Sub

' ============================================
' Helper function to test API connectivity
' Usage: Call TestGeminiAPI in VBA editor
' ============================================
Public Sub TestGeminiAPI()
    Dim result As String
    
    result = MyAI("Google SW engineer for 5 years. Calculate work experience in years.")
    
    MsgBox "API Test Result: " & vbCrLf & vbCrLf & _
           "Expected: Just number like '5년' or '5' " & vbCrLf & _
           "Actual: " & result, vbInformation, "Gemini API Test"
End Sub

