### 기능
google sheets의 = AI(), MS365의 =Copilot()과 동일한 기능 구현
@Code.gs와 동일한 기능 구현
엑셀에서 =MyAI함수 사용할 수 있도록 VBA 스크립트 작성
=MyAI(프롬프트, 참조셀)
Gemini API 호출
API 호출 후 셀에 정답 표시 전까지 '로드중' 표시
gemini의 응답 내용에서 정답만을 셀에 출력
gemini-2.0-flash 모델 사용
VBA 개발환경에서 한글깨지지 않도록 영문으로 주석, 메시지 작성

### API Key
AIzaSyCPeHe4VSXawGN9ocudEwy_T1XipTT2xSk