# Product Requirements Document (PRD)
## MyAI - Excel AI Function

---

## 1. Executive Summary

**Product Name:** MyAI for Excel  
**Version:** 1.0  
**Date:** 2024-11-09  
**Status:** Completed  

MyAI는 Excel에서 Google Sheets의 `=AI()`나 MS365의 `=Copilot()`과 동일한 AI 기능을 제공하는 VBA 기반 사용자 정의 함수입니다. Gemini 2.0 Flash API를 활용하여 자연어 질문에 대한 답변을 셀에 직접 출력합니다.

---

## 2. Product Goals

### 2.1 Primary Goals
- Excel 사용자에게 AI 기반 자동화 기능 제공
- Google Sheets AI() 및 MS365 Copilot()과 동등한 사용자 경험 제공
- 간단한 수식으로 복잡한 데이터 분석 및 텍스트 처리 가능

### 2.2 Success Metrics
- API 응답 성공률 > 95%
- 평균 응답 시간 < 5초
- 사용자가 별도 설정 없이 바로 사용 가능
- 한글 지원 및 깨짐 현상 없음

---

## 3. Target Users

### 3.1 Primary Users
- 데이터 분석을 하는 비즈니스 사용자
- Excel을 사용한 보고서 작성자
- 대량의 텍스트 처리가 필요한 실무자

### 3.2 User Scenarios
- 자기소개서에서 근무 연수 자동 계산
- 데이터 요약 및 분석
- 텍스트 번역 및 변환
- 수식 작성이 복잡한 계산

---

## 4. Feature Requirements

### 4.1 Core Features

#### F1: MyAI 함수 (수식 모드)
**Description:** Excel 셀에서 수식으로 사용 가능한 AI 함수  
**Priority:** P0 (Critical)  
**Status:** ✅ Completed

**Specifications:**
- **Syntax:** `=MyAI(prompt, [reference_cells])`
- **Parameters:**
  - `prompt` (필수): AI에게 전달할 질문 또는 명령
  - `reference_cells` (선택): 컨텍스트로 사용할 셀 범위
- **Output:** AI가 생성한 답변 (정답만 출력, 설명 제외)
- **Examples:**
  ```excel
  =MyAI("2+2는?")  → "4"
  =MyAI("요약해줘", A1:A10)  → "데이터 요약 결과"
  =MyAI("근무 연수 계산: " & A1)  → "5년"
  ```

**Acceptance Criteria:**
- ✅ 수식으로 입력 가능
- ✅ 셀 참조 지원
- ✅ 결과가 셀에 자동 표시
- ✅ 수식 복사 시 정상 작동
- ✅ 동일 프롬프트는 캐싱되어 빠른 응답

---

#### F2: MyAI_Macro (매크로 모드)
**Description:** 선택된 셀의 내용을 AI로 처리하는 매크로  
**Priority:** P0 (Critical)  
**Status:** ✅ Completed

**Specifications:**
- 선택된 셀들을 순차적으로 처리
- 각 셀에 "⏳ Loading..." 표시 (회색, 이탤릭)
- API 응답 완료 후 결과로 교체
- 상태 표시줄에 진행 상황 표시

**User Flow:**
1. 질문/프롬프트를 셀에 입력
2. 처리할 셀 선택
3. `Alt + F8` → `MyAI_Macro` 실행
4. 각 셀에 "Loading..." 표시
5. AI 답변으로 자동 교체
6. 완료 메시지 표시

**Acceptance Criteria:**
- ✅ 셀에 "Loading..." 표시
- ✅ 여러 셀 동시 처리
- ✅ 진행 상황 시각적 피드백
- ✅ 오류 발생 시 적절한 메시지 표시

---

#### F3: Loading Indicator
**Description:** API 호출 중 로딩 상태 표시  
**Priority:** P0 (Critical)  
**Status:** ✅ Completed

**Specifications:**
- **수식 모드:**
  - 하단 상태 표시줄: "⏳ Loading AI response..."
  - 마우스 커서: 대기 아이콘 (모래시계)
- **매크로 모드:**
  - 셀 내용: "⏳ Loading..."
  - 글자 색상: 회색 (RGB 128, 128, 128)
  - 글자 스타일: 이탤릭
  - 상태 표시줄: "Processing: [프롬프트]..."

**Acceptance Criteria:**
- ✅ 로딩 중임을 사용자가 명확히 인지
- ✅ 로딩 완료 후 원래 상태로 복원
- ✅ 로딩 인디케이터가 사용자 경험 방해하지 않음

---

#### F4: Response Cleanup
**Description:** AI 응답에서 불필요한 포맷 제거  
**Priority:** P1 (High)  
**Status:** ✅ Completed

**Specifications:**
- 마크다운 포맷 제거 (`**`, `*`, `_`, `` ` ``)
- 앞뒤 공백 제거
- 전체 응답을 감싼 따옴표 제거
- 프롬프트에 자동으로 "정답만 출력" 지시사항 추가

**Before/After:**
```
Before: "2017년부터 2022년까지 근무하였으므로, 근속연수는 총 **6년**입니다."
After:  "2017년부터 2022년까지 근무하였으므로, 근속연수는 총 6년입니다."

Before: "**5년**"
After:  "5년"
```

**Acceptance Criteria:**
- ✅ 깔끔한 답변 출력
- ✅ 마크다운 제거
- ✅ 불필요한 설명 최소화

---

#### F5: Response Caching
**Description:** 동일 프롬프트 응답 캐싱  
**Priority:** P2 (Medium)  
**Status:** ✅ Completed

**Specifications:**
- 프롬프트를 키로 사용한 Dictionary 기반 캐시
- 동일 질문 시 API 호출 없이 즉시 응답
- 캐시 수동 삭제 기능 제공 (`ClearAICache`)

**Benefits:**
- API 호출 비용 절감
- 응답 속도 향상
- 네트워크 부하 감소

**Acceptance Criteria:**
- ✅ 동일 프롬프트 재호출 시 즉시 응답
- ✅ 캐시 삭제 기능 동작
- ✅ 메모리 누수 없음

---

### 4.2 Utility Features

#### F6: TestGeminiAPI
**Description:** API 연결 테스트 함수  
**Priority:** P2 (Medium)  
**Status:** ✅ Completed

**Specifications:**
- VBA 편집기에서 실행 가능
- 간단한 질문으로 API 동작 확인
- 결과를 메시지 박스로 표시

---

#### F7: ClearAICache
**Description:** 캐시 초기화 매크로  
**Priority:** P2 (Medium)  
**Status:** ✅ Completed

**Specifications:**
- 모든 캐시된 응답 삭제
- 완료 메시지 표시

---

## 5. Non-Functional Requirements

### 5.1 Performance
- API 응답 시간: 평균 2-4초
- 타임아웃: 30초
- 대용량 프롬프트 지원: 최대 8192 토큰

### 5.2 Reliability
- 에러 핸들링: 모든 API 에러 적절히 처리
- HTTP 상태 코드별 에러 메시지 제공
- 네트워크 장애 시 명확한 피드백

### 5.3 Usability
- 별도 설정 없이 바로 사용 가능
- 직관적인 함수 이름 (`MyAI`)
- 영문 에러 메시지 (VBA 한글 깨짐 방지)

### 5.4 Compatibility
- Excel 2016 이상
- Windows 10/11
- .NET Framework 불필요
- 외부 라이브러리 불필요

### 5.5 Security
- API Key: 코드에 하드코딩 (프로토타입)
- HTTPS 통신 (WinHTTP)

---

## 6. Technical Constraints

### 6.1 API Limitations
- **Model:** Gemini 2.0 Flash
- **Rate Limit:** Google API 기본 제한 적용
- **Max Tokens:** 8192 (출력)
- **API Key:** AIzaSyCPeHe4VSXawGN9ocudEwy_T1XipTT2xSk

### 6.2 Excel/VBA Limitations
- UDF는 셀 값을 직접 변경 불가 (로딩 표시 제약)
- 비동기 처리 불가능 (동기 HTTP만 지원)
- DoEvents로 UI 업데이트 강제 필요

---

## 7. Out of Scope (v1.0)

❌ 다음 기능은 v1.0에 포함되지 않습니다:
- API Key 설정 UI
- 이미지 입력 지원
- 스트리밍 응답
- 비동기 처리
- 다중 모델 지원
- 응답 히스토리 관리
- 사용량 통계

---

## 8. User Documentation

### 8.1 Installation
1. Excel 열기
2. `Alt + F11` (VBA 편집기)
3. `파일` → `가져오기`
4. `GeminiAI.bas` 선택
5. Excel로 돌아가서 사용

### 8.2 Basic Usage
```excel
=MyAI("서울의 인구는?")
=MyAI("이 데이터를 요약해줘", A1:A10)
=MyAI(A1 & " - 이것을 영어로 번역")
```

### 8.3 Macro Usage
1. 질문 셀 선택
2. `Alt + F8`
3. `MyAI_Macro` 선택
4. 실행

---

## 9. Future Enhancements (v2.0)

### Potential Features:
- 🔹 API Key 설정 UI (사용자 입력)
- 🔹 모델 선택 기능 (Gemini Pro, Flash 등)
- 🔹 비동기 처리 (Application.OnTime 활용)
- 🔹 응답 히스토리 관리
- 🔹 배치 처리 최적화
- 🔹 이미지 분석 지원
- 🔹 사용량 및 비용 추적

---

## 10. Appendix

### 10.1 Related Documents
- Technical Requirements Document (TRD.md)
- Code: GeminiAI.bas

### 10.2 References
- Google Gemini API Documentation
- Excel VBA Reference
- WinHTTP 5.1 Documentation

---

**Document Owner:** Development Team  
**Last Updated:** 2024-11-09  
**Version:** 1.0


